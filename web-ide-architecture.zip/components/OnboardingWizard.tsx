'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  BellOff,
  Check,
  Cloud,
  Code2,
  Cpu,
  Gem,
  GraduationCap,
  Info,
  Loader2,
  Rocket,
  Sparkles,
  Zap,
} from 'lucide-react'
import { getNotificationPermission, requestNotificationPermission } from '@/lib/notifications'
import type {
  ExperienceLevel,
  NotificationPermissionState,
  OnboardingResult,
  ThemeChoice,
} from '@/lib/types'

interface OnboardingWizardProps {
  onComplete: (result: OnboardingResult) => void
}

type StepIndex = 0 | 1 | 2

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 80 : -80,
    opacity: 0,
  }),
  center: { x: 0, opacity: 1 },
  exit: (direction: number) => ({
    x: direction > 0 ? -80 : 80,
    opacity: 0,
  }),
}

const FEATURES = [
  {
    icon: Cloud,
    title: 'Web Compilation',
    description: 'Build APK-ready project trees entirely in the browser sandbox.',
  },
  {
    icon: Zap,
    title: 'Zero Install',
    description: 'No SDK downloads, no Gradle setup. Open a tab and start shipping.',
  },
  {
    icon: Code2,
    title: 'Multi-language Support',
    description: 'First-class Java and Kotlin boilerplate generation engines.',
  },
] as const

const NOTIFICATION_USES = [
  'Build completed',
  'Build failed',
  'Export finished',
  'Long-running tasks',
] as const

const EXPERIENCE_LEVELS: { value: ExperienceLevel; label: string; icon: typeof Rocket; blurb: string }[] = [
  { value: 'beginner', label: 'Beginner', icon: GraduationCap, blurb: 'New to Android. Guide me through everything.' },
  { value: 'intermediate', label: 'Intermediate', icon: Rocket, blurb: 'Shipped a few apps. I know my way around.' },
  { value: 'master', label: 'Master', icon: Cpu, blurb: 'I dream in Gradle DSL. Stay out of my way.' },
]

const THEME_CHOICES: { value: ThemeChoice; label: string; swatch: string; icon: typeof Sparkles }[] = [
  { value: 'neon_cyan', label: 'Neon Cyan', swatch: 'bg-cyan-400', icon: Zap },
  { value: 'cyber_gold', label: 'Cyber Gold', swatch: 'bg-amber-400', icon: Sparkles },
  { value: 'deep_amethyst', label: 'Deep Amethyst', swatch: 'bg-violet-400', icon: Gem },
]

export default function OnboardingWizard({ onComplete }: OnboardingWizardProps) {
  const [step, setStep] = useState<StepIndex>(0)
  const [direction, setDirection] = useState<number>(1)
  const [permission, setPermission] = useState<NotificationPermissionState>(() => getNotificationPermission())
  const [requesting, setRequesting] = useState<boolean>(false)
  const [experience, setExperience] = useState<ExperienceLevel | null>(null)
  const [theme, setTheme] = useState<ThemeChoice | null>(null)
  const [tooltipOpen, setTooltipOpen] = useState<boolean>(false)
  const [finishing, setFinishing] = useState<boolean>(false)

  // Notifications are optional: step 1 never blocks progress.
  const canProceed: boolean = step === 2 ? experience !== null && theme !== null : true

  const handleRequestPermission = async (): Promise<void> => {
    setRequesting(true)
    const result = await requestNotificationPermission()
    setPermission(result)
    setRequesting(false)
  }

  const goNext = () => {
    if (!canProceed) return
    if (step < 2) {
      setDirection(1)
      setStep((prev) => (prev + 1) as StepIndex)
    } else if (experience !== null && theme !== null) {
      setFinishing(true)
      // Simulated environment provisioning before entering the dashboard.
      window.setTimeout(() => {
        onComplete({
          experience,
          theme,
          notificationPermission: permission,
        })
      }, 900)
    }
  }

  const goBack = () => {
    if (step === 0 || finishing) return
    setDirection(-1)
    setStep((prev) => (prev - 1) as StepIndex)
  }

  return (
    <main className="flex min-h-dvh items-center justify-center bg-background p-4">
      {/* Ambient grid backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(var(--color-primary) 1px, transparent 1px), linear-gradient(90deg, var(--color-primary) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative w-full max-w-2xl">
        {/* Glassmorphism card */}
        <div className="overflow-hidden rounded-2xl border border-border bg-card/70 shadow-2xl shadow-primary/10 backdrop-blur-xl">
          {/* Progress rail */}
          <div className="flex items-center gap-2 border-b border-border px-6 py-4">
            <div className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Cpu className="size-4" aria-hidden="true" />
            </div>
            <span className="font-mono text-sm font-semibold tracking-wider text-foreground">SITARA</span>
            <div className="ml-auto flex items-center gap-2" aria-label={`Step ${step + 1} of 3`}>
              {([0, 1, 2] as const).map((index) => (
                <div
                  key={index}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    index === step ? 'w-8 bg-primary' : index < step ? 'w-4 bg-accent' : 'w-4 bg-muted'
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="relative min-h-[420px] px-6 py-8 sm:px-10">
            <AnimatePresence mode="wait" custom={direction}>
              {step === 0 && (
                <motion.section
                  key="step-welcome"
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.32, ease: 'easeOut' }}
                  aria-label="Welcome and setup"
                >
                  <p className="font-mono text-xs uppercase tracking-widest text-accent">Step 01 / Setup</p>
                  <h1 className="mt-3 text-3xl font-bold text-balance text-foreground sm:text-4xl">
                    Build Android apps. <span className="text-primary">Straight from the browser.</span>
                  </h1>
                  <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">
                    Sitara is a fully sandboxed, web-native Android IDE. Configure a project, pick a template, and
                    generate production-grade boilerplate in seconds.
                  </p>
                  <ul className="mt-8 flex flex-col gap-3">
                    {FEATURES.map((feature) => (
                      <li
                        key={feature.title}
                        className="flex items-start gap-4 rounded-xl border border-border bg-secondary/40 p-4"
                      >
                        <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                          <feature.icon className="size-4" aria-hidden="true" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{feature.title}</p>
                          <p className="text-xs leading-relaxed text-muted-foreground">{feature.description}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </motion.section>
              )}

              {step === 1 && (
                <motion.section
                  key="step-notifications"
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.32, ease: 'easeOut' }}
                  aria-label="Optional notifications"
                >
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-xs uppercase tracking-widest text-accent">
                      Step 02 / Notifications (Optional)
                    </p>
                    <div className="relative">
                      <button
                        type="button"
                        aria-label="Why does Sitara ask for notifications?"
                        aria-expanded={tooltipOpen}
                        onClick={() => setTooltipOpen((prev) => !prev)}
                        onBlur={() => setTooltipOpen(false)}
                        className="flex size-5 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-primary"
                      >
                        <Info className="size-4" aria-hidden="true" />
                      </button>
                      <AnimatePresence>
                        {tooltipOpen && (
                          <motion.div
                            initial={{ opacity: 0, y: 4 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 4 }}
                            transition={{ duration: 0.18 }}
                            role="tooltip"
                            className="absolute left-1/2 top-7 z-10 w-64 -translate-x-1/2 rounded-lg border border-border bg-popover p-3 text-xs leading-relaxed text-popover-foreground shadow-xl"
                          >
                            This uses your browser&apos;s real notification permission so Sitara can alert you when
                            builds and exports finish — even if the tab is in the background. It is never used for
                            anything else, and you can change it anytime in Settings.
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                  <h2 className="mt-3 text-2xl font-bold text-balance text-foreground sm:text-3xl">
                    Get notified when builds finish
                  </h2>
                  <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">
                    Entirely optional. Sitara works fully without notifications — you&apos;ll just need to keep an eye
                    on the build panel yourself. Notifications are only ever used for:
                  </p>

                  <ul className="mt-4 grid grid-cols-2 gap-2">
                    {NOTIFICATION_USES.map((use) => (
                      <li
                        key={use}
                        className="flex items-center gap-2 rounded-lg border border-border bg-secondary/40 px-3 py-2"
                      >
                        <Check className="size-3.5 shrink-0 text-accent" aria-hidden="true" />
                        <span className="text-xs text-foreground">{use}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 rounded-xl border border-border bg-secondary/40 p-5">
                    {permission === 'granted' && (
                      <div className="flex items-center gap-3">
                        <div className="flex size-10 items-center justify-center rounded-lg bg-accent/15 text-accent">
                          <Bell className="size-5" aria-hidden="true" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">Notifications enabled</p>
                          <p className="text-xs text-muted-foreground">
                            Your browser granted permission. You can disable this later in Settings.
                          </p>
                        </div>
                      </div>
                    )}
                    {permission === 'denied' && (
                      <div className="flex items-center gap-3">
                        <div className="flex size-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                          <BellOff className="size-5" aria-hidden="true" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">Notifications blocked by the browser</p>
                          <p className="text-xs leading-relaxed text-muted-foreground">
                            No problem — the IDE works fully without them. To enable later, allow notifications for
                            this site in your browser settings.
                          </p>
                        </div>
                      </div>
                    )}
                    {permission === 'unsupported' && (
                      <div className="flex items-center gap-3">
                        <div className="flex size-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                          <BellOff className="size-5" aria-hidden="true" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">Not supported in this browser</p>
                          <p className="text-xs text-muted-foreground">
                            Your browser doesn&apos;t support the Notification API. Everything else works normally.
                          </p>
                        </div>
                      </div>
                    )}
                    {permission === 'default' && (
                      <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
                        <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                          <Bell className="size-5" aria-hidden="true" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold text-foreground">Browser notification permission</p>
                          <p className="text-xs leading-relaxed text-muted-foreground">
                            Your browser will show its own permission prompt.
                          </p>
                        </div>
                        <motion.button
                          type="button"
                          whileHover={{ scale: requesting ? 1 : 1.04 }}
                          whileTap={{ scale: requesting ? 1 : 0.96 }}
                          onClick={() => void handleRequestPermission()}
                          disabled={requesting}
                          className="flex shrink-0 items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 disabled:opacity-60"
                        >
                          {requesting ? (
                            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                          ) : (
                            <Bell className="size-4" aria-hidden="true" />
                          )}
                          Enable notifications
                        </motion.button>
                      </div>
                    )}
                  </div>

                  <p className="mt-4 text-xs text-muted-foreground">
                    You can skip this — hit Next to continue without notifications.
                  </p>
                </motion.section>
              )}

              {step === 2 && (
                <motion.section
                  key="step-persona"
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.32, ease: 'easeOut' }}
                  aria-label="Developer persona and experience"
                >
                  <p className="font-mono text-xs uppercase tracking-widest text-accent">Step 03 / Persona</p>
                  <h2 className="mt-3 text-2xl font-bold text-balance text-foreground sm:text-3xl">
                    Tune the IDE to you
                  </h2>

                  <fieldset className="mt-6">
                    <legend className="text-sm font-semibold text-foreground">Your Android experience level?</legend>
                    <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                      {EXPERIENCE_LEVELS.map((level) => (
                        <motion.button
                          key={level.value}
                          type="button"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setExperience(level.value)}
                          aria-pressed={experience === level.value}
                          className={`rounded-xl border p-4 text-left transition-colors ${
                            experience === level.value
                              ? 'border-primary bg-primary/10'
                              : 'border-border bg-secondary/40 hover:border-primary/40'
                          }`}
                        >
                          <level.icon
                            className={`size-5 ${experience === level.value ? 'text-primary' : 'text-muted-foreground'}`}
                            aria-hidden="true"
                          />
                          <p className="mt-2 text-sm font-semibold text-foreground">{level.label}</p>
                          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{level.blurb}</p>
                        </motion.button>
                      ))}
                    </div>
                  </fieldset>

                  <fieldset className="mt-6">
                    <legend className="text-sm font-semibold text-foreground">Primary theme choice</legend>
                    <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                      {THEME_CHOICES.map((choice) => (
                        <motion.button
                          key={choice.value}
                          type="button"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setTheme(choice.value)}
                          aria-pressed={theme === choice.value}
                          className={`flex items-center gap-3 rounded-xl border p-3 transition-colors ${
                            theme === choice.value
                              ? 'border-primary bg-primary/10'
                              : 'border-border bg-secondary/40 hover:border-primary/40'
                          }`}
                        >
                          <span className={`size-4 shrink-0 rounded-full ${choice.swatch}`} aria-hidden="true" />
                          <span className="text-sm font-semibold text-foreground">{choice.label}</span>
                          {theme === choice.value && (
                            <Check className="ml-auto size-4 text-primary" aria-hidden="true" />
                          )}
                        </motion.button>
                      ))}
                    </div>
                  </fieldset>
                </motion.section>
              )}
            </AnimatePresence>
          </div>

          {/* Navigation footer */}
          <div className="flex items-center justify-between border-t border-border px-6 py-4 sm:px-10">
            <motion.button
              type="button"
              whileHover={{ scale: step === 0 || finishing ? 1 : 1.04 }}
              whileTap={{ scale: step === 0 || finishing ? 1 : 0.96 }}
              onClick={goBack}
              disabled={step === 0 || finishing}
              className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ArrowLeft className="size-4" aria-hidden="true" />
              Back
            </motion.button>

            <motion.button
              type="button"
              whileHover={{ scale: canProceed && !finishing ? 1.04 : 1 }}
              whileTap={{ scale: canProceed && !finishing ? 0.96 : 1 }}
              onClick={goNext}
              disabled={!canProceed || finishing}
              className="flex min-w-32 items-center justify-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
            >
              {finishing ? (
                <>
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                  Provisioning
                </>
              ) : step === 2 ? (
                <>
                  Launch IDE
                  <Rocket className="size-4" aria-hidden="true" />
                </>
              ) : (
                <>
                  {step === 1 && permission !== 'granted' ? 'Skip / Next' : 'Next'}
                  <ArrowRight className="size-4" aria-hidden="true" />
                </>
              )}
            </motion.button>
          </div>
        </div>
      </div>
    </main>
  )
}
