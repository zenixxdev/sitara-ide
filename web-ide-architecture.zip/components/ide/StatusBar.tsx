'use client'

import { useEffect, useState } from 'react'
import { GitBranch, FileCode2, Braces, Bell, BellOff, Save } from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import { onCursorChange, type CursorInfo } from '@/lib/editorBus'

/** Human-readable language label for the status bar, derived from file extension. */
function languageLabel(path: string): string {
  if (path.endsWith('.java')) return 'Java'
  if (path.endsWith('.kt') || path.endsWith('.kts')) return 'Kotlin'
  if (path.endsWith('.xml')) return 'XML'
  if (path.endsWith('.gradle')) return 'Gradle'
  if (path.endsWith('.properties')) return 'Properties'
  if (path.endsWith('.json')) return 'JSON'
  if (path.endsWith('.md')) return 'Markdown'
  return 'Plain Text'
}

export function StatusBar() {
  const activeProjectId = useIdeStore((s) => s.activeProjectId)
  const projects = useIdeStore((s) => s.projects)
  const activePath = useIdeStore((s) => s.activePath)
  const tabs = useIdeStore((s) => s.tabs)
  const settings = useIdeStore((s) => s.settings)
  const setSettingsOpen = useIdeStore((s) => s.setSettingsOpen)

  const [cursor, setCursor] = useState<CursorInfo>({ line: 1, column: 1, selectionChars: 0 })

  useEffect(() => onCursorChange(setCursor), [])

  const project = activeProjectId !== null ? projects[activeProjectId]?.config : undefined
  if (project === undefined) return null

  const activeTab = tabs.find((t) => t.path === activePath)
  const dirtyCount = tabs.filter((t) => t.dirty).length

  return (
    <footer className="flex h-6 shrink-0 items-center gap-3 border-t border-border bg-card/90 px-3 font-mono text-[10px] text-muted-foreground backdrop-blur-md">
      <span className="flex items-center gap-1 text-primary">
        <GitBranch className="h-3 w-3" aria-hidden="true" />
        main
      </span>
      <span className="hidden items-center gap-1 sm:flex">
        <FileCode2 className="h-3 w-3" aria-hidden="true" />
        minSdk {project.minSdk}
      </span>
      {dirtyCount > 0 ? (
        <span className="flex items-center gap-1 text-[oklch(0.8_0.14_85)]">
          <Save className="h-3 w-3" aria-hidden="true" />
          {dirtyCount} unsaved
        </span>
      ) : null}
      <div className="flex-1" />
      {activeTab !== undefined ? (
        <>
          <span>
            Ln {cursor.line}, Col {cursor.column}
            {cursor.selectionChars > 0 ? ` (${cursor.selectionChars} selected)` : ''}
          </span>
          <span className="hidden items-center gap-1 sm:flex">
            <Braces className="h-3 w-3" aria-hidden="true" />
            {languageLabel(activeTab.path)}
          </span>
        </>
      ) : null}
      <span className="hidden sm:inline">UTF-8</span>
      <button
        type="button"
        onClick={() => setSettingsOpen(true)}
        className="flex items-center gap-1 rounded px-1 py-0.5 hover:bg-secondary hover:text-foreground"
        title={settings.notificationsEnabled ? 'Notifications enabled' : 'Notifications disabled'}
        aria-label="Notification settings"
      >
        {settings.notificationsEnabled ? (
          <Bell className="h-3 w-3 text-accent" aria-hidden="true" />
        ) : (
          <BellOff className="h-3 w-3" aria-hidden="true" />
        )}
      </button>
    </footer>
  )
}
