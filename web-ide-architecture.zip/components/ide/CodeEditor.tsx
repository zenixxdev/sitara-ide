'use client'

import { useCallback, useEffect, useMemo, useRef } from 'react'
import CodeMirror, { type ReactCodeMirrorRef } from '@uiw/react-codemirror'
import { EditorView, keymap } from '@codemirror/view'
import { EditorState, type Extension } from '@codemirror/state'
import { redo, toggleComment, undo } from '@codemirror/commands'
import { gotoLine, openSearchPanel, search } from '@codemirror/search'
import { HighlightStyle, StreamLanguage, syntaxHighlighting } from '@codemirror/language'
import { tags } from '@lezer/highlight'
import { java } from '@codemirror/lang-java'
import { xml } from '@codemirror/lang-xml'
import { json } from '@codemirror/lang-json'
import { markdown } from '@codemirror/lang-markdown'
import { kotlin } from '@codemirror/legacy-modes/mode/clike'
import { groovy } from '@codemirror/legacy-modes/mode/groovy'
import { properties } from '@codemirror/legacy-modes/mode/properties'
import { FileCode2 } from 'lucide-react'
import { onEditorCommand, publishCursor, type EditorCommand } from '@/lib/editorBus'
import { formatSource } from '@/lib/formatter'
import { useIdeStore } from '@/lib/ideStore'

/** Resolves the CodeMirror language extension for a file name. */
function languageForFile(fileName: string): Extension | null {
  if (fileName.endsWith('.java')) return java()
  if (fileName.endsWith('.kt') || fileName.endsWith('.kts')) return StreamLanguage.define(kotlin)
  if (fileName.endsWith('.xml')) return xml()
  if (fileName.endsWith('.gradle')) return StreamLanguage.define(groovy)
  if (fileName.endsWith('.properties')) return StreamLanguage.define(properties)
  if (fileName.endsWith('.json')) return json()
  if (fileName.endsWith('.md')) return markdown()
  return null
}

/** Cyber-Tech syntax palette mapped onto the app's design tokens. */
const cyberHighlight = HighlightStyle.define([
  { tag: [tags.keyword, tags.modifier, tags.controlKeyword], color: 'var(--color-primary)' },
  { tag: [tags.string, tags.special(tags.string)], color: 'var(--color-accent)' },
  { tag: [tags.comment, tags.blockComment], color: 'var(--color-muted-foreground)', fontStyle: 'italic' },
  { tag: [tags.number, tags.integer, tags.float], color: 'oklch(0.75 0.16 60)' },
  { tag: [tags.annotation, tags.meta], color: 'oklch(0.85 0.15 95)' },
  { tag: [tags.typeName, tags.className, tags.namespace], color: 'oklch(0.78 0.11 200)' },
  { tag: [tags.function(tags.variableName), tags.function(tags.propertyName)], color: 'oklch(0.8 0.12 230)' },
  { tag: [tags.tagName], color: 'var(--color-primary)' },
  { tag: [tags.attributeName], color: 'oklch(0.78 0.11 200)' },
  { tag: [tags.attributeValue], color: 'var(--color-accent)' },
  { tag: [tags.propertyName], color: 'oklch(0.78 0.11 200)' },
  { tag: [tags.bool, tags.null], color: 'var(--color-primary)' },
  { tag: [tags.operator, tags.punctuation], color: 'var(--color-foreground)' },
])

/** Builds the CodeMirror theme from current settings. */
function buildTheme(fontSize: number, fontFamily: string): Extension {
  return EditorView.theme(
    {
      '&': {
        backgroundColor: 'var(--color-card)',
        color: 'var(--color-foreground)',
        fontSize: `${fontSize}px`,
        height: '100%',
      },
      '.cm-content': { fontFamily, caretColor: 'var(--color-primary)', paddingBottom: '40vh' },
      '.cm-cursor, .cm-dropCursor': { borderLeftColor: 'var(--color-primary)' },
      '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, ::selection': {
        backgroundColor: 'color-mix(in oklch, var(--color-primary) 30%, transparent)',
      },
      '.cm-selectionBackground': {
        backgroundColor: 'color-mix(in oklch, var(--color-primary) 20%, transparent)',
      },
      '.cm-activeLine': { backgroundColor: 'color-mix(in oklch, var(--color-primary) 7%, transparent)' },
      '.cm-activeLineGutter': {
        backgroundColor: 'color-mix(in oklch, var(--color-primary) 12%, transparent)',
        color: 'var(--color-primary)',
      },
      '.cm-gutters': {
        backgroundColor: 'var(--color-background)',
        color: 'var(--color-muted-foreground)',
        border: 'none',
        borderRight: '1px solid var(--color-border)',
        fontFamily,
      },
      '.cm-matchingBracket': {
        backgroundColor: 'color-mix(in oklch, var(--color-accent) 25%, transparent)',
        outline: '1px solid var(--color-accent)',
      },
      '.cm-nonmatchingBracket': {
        backgroundColor: 'color-mix(in oklch, var(--color-destructive) 25%, transparent)',
      },
      '.cm-panels': {
        backgroundColor: 'var(--color-popover)',
        color: 'var(--color-popover-foreground)',
        borderBottom: '1px solid var(--color-border)',
      },
      '.cm-panels input, .cm-panels button, .cm-panels label': {
        fontFamily,
        fontSize: '12px',
      },
      '.cm-textfield': {
        backgroundColor: 'var(--color-background)',
        border: '1px solid var(--color-border)',
        borderRadius: '6px',
        color: 'var(--color-foreground)',
      },
      '.cm-button': {
        backgroundImage: 'none',
        backgroundColor: 'var(--color-secondary)',
        border: '1px solid var(--color-border)',
        borderRadius: '6px',
        color: 'var(--color-foreground)',
      },
      '.cm-searchMatch': {
        backgroundColor: 'color-mix(in oklch, var(--color-accent) 30%, transparent)',
        outline: '1px solid color-mix(in oklch, var(--color-accent) 60%, transparent)',
      },
      '.cm-searchMatch-selected': {
        backgroundColor: 'color-mix(in oklch, var(--color-primary) 40%, transparent)',
      },
      '.cm-scroller': { fontFamily, scrollBehavior: 'smooth' },
      '.cm-tooltip': {
        backgroundColor: 'var(--color-popover)',
        border: '1px solid var(--color-border)',
        borderRadius: '8px',
      },
    },
    { dark: true },
  )
}

export default function CodeEditor() {
  const activePath = useIdeStore((state) => state.activePath)
  const settings = useIdeStore((state) => state.settings)
  const updateDraft = useIdeStore((state) => state.updateDraft)
  const saveFile = useIdeStore((state) => state.saveFile)
  const fileContent = useIdeStore((state) => state.fileContent)
  const editorRef = useRef<ReactCodeMirrorRef | null>(null)

  const fileName = activePath?.split('/').pop() ?? ''
  const content = activePath === null ? '' : fileContent(activePath)

  const fontFamily =
    settings.editorFont === 'geist_mono'
      ? 'var(--font-mono), ui-monospace, monospace'
      : 'ui-monospace, SFMono-Regular, Menlo, monospace'

  const extensions = useMemo<Extension[]>(() => {
    const list: Extension[] = [
      buildTheme(settings.fontSize, fontFamily),
      syntaxHighlighting(cyberHighlight),
      search({ top: true }),
      EditorState.tabSize.of(settings.tabSize),
      keymap.of([
        {
          key: 'Mod-s',
          run: () => {
            if (activePath !== null) saveFile(activePath)
            return true
          },
        },
        { key: 'Mod-/', run: toggleComment },
      ]),
    ]
    if (settings.wordWrap) list.push(EditorView.lineWrapping)
    const lang = languageForFile(fileName)
    if (lang !== null) list.push(lang)
    return list
  }, [settings.fontSize, settings.tabSize, settings.wordWrap, fontFamily, fileName, activePath, saveFile])

  // Command bus: top bar buttons and global shortcuts drive the editor.
  useEffect(() => {
    return onEditorCommand((command: EditorCommand) => {
      const view = editorRef.current?.view
      if (view === undefined) return
      switch (command) {
        case 'undo':
          undo(view)
          break
        case 'redo':
          redo(view)
          break
        case 'find':
        case 'replace':
          openSearchPanel(view)
          break
        case 'gotoLine':
          gotoLine(view)
          break
        case 'toggleComment':
          toggleComment(view)
          break
        case 'selectAll':
          view.dispatch({ selection: { anchor: 0, head: view.state.doc.length } })
          break
        case 'format': {
          if (activePath === null) break
          const formatted = formatSource(view.state.doc.toString(), fileName, settings.tabSize)
          if (formatted !== view.state.doc.toString()) {
            view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: formatted } })
          }
          break
        }
      }
      view.focus()
    })
  }, [activePath, fileName, settings.tabSize])

  const handleChange = useCallback(
    (value: string) => {
      if (activePath !== null) updateDraft(activePath, value)
    },
    [activePath, updateDraft],
  )

  const handleUpdate = useCallback((viewUpdate: { view: EditorView; selectionSet: boolean; docChanged: boolean }) => {
    if (!viewUpdate.selectionSet && !viewUpdate.docChanged) return
    const state = viewUpdate.view.state
    const range = state.selection.main
    const line = state.doc.lineAt(range.head)
    publishCursor({
      line: line.number,
      column: range.head - line.from + 1,
      selectionChars: Math.abs(range.to - range.from),
    })
  }, [])

  if (activePath === null) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 bg-background/60">
        <FileCode2 className="size-10 text-muted-foreground/50" aria-hidden="true" />
        <p className="text-sm text-muted-foreground">Select a file from the explorer to start editing.</p>
        <p className="font-mono text-xs text-muted-foreground/60">Ctrl+Shift+P — search across the project</p>
      </div>
    )
  }

  return (
    <div className="h-full min-h-0 bg-card">
      <CodeMirror
        key={activePath}
        ref={editorRef}
        value={content}
        onChange={handleChange}
        onUpdate={handleUpdate}
        theme="none"
        extensions={extensions}
        height="100%"
        style={{ height: '100%' }}
        basicSetup={{
          lineNumbers: true,
          foldGutter: true,
          highlightActiveLine: true,
          highlightActiveLineGutter: true,
          bracketMatching: true,
          closeBrackets: true,
          autocompletion: false,
          indentOnInput: true,
          history: true,
          drawSelection: true,
          allowMultipleSelections: true,
          searchKeymap: true,
        }}
        aria-label={`Source editor for ${fileName}`}
      />
    </div>
  )
}
