'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Bell, BellOff, RotateCcw, Type, Palette, Hammer, AlertTriangle } from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import type { AccentTheme, EditorFont } from '@/lib/types'
import { requestNotificationPermission, getNotificationPermission } from '@/lib/notifications'

const THEMES: { id: AccentTheme; label: string; swatch: string }[] = [
  { id: 'electric_blue', label: 'Electric Blue', swatch: 'oklch(0.72 0.19 250)' },
  { id: 'neon_cyan', label: 'Neon Cyan', swatch: 'oklch(0.78 0.14 210)' },
  { id: 'cyber_gold', label: 'Cyber Gold', swatch: 'oklch(0.82 0.14 90)' },
  { id: 'deep_amethyst', label: 'Deep Amethyst', swatch: 'oklch(0.62 0.2 300)' },
]

const EDITOR_FONTS: { id: EditorFont; label: string }[] = [
  { id: 'geist_mono', label: 'Geist Mono' },
  { id: 'system_mono', label: 'System Monospace' },
]

function SettingRow({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="font-mono text-xs font-semibold text-foreground">{label}</p>
        {hint !== undefined ? (
          <p className="mt-0.5 text-[11px] leading-relaxed text-muted-foreground">{hint}</p>
        ) : null}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  )
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={`relative h-6 w-11 rounded-full border transition-colors ${
        on ? 'border-primary/60 bg-primary/30' : 'border-border bg-secondary'
      }`}
    >
      <motion.span
        className={`absolute rounded-full ${on ? 'bg-primary' : 'bg-muted-foreground/50'}`}
        style={{ width: 18, height: 18, top: 2 }}
        animate={{ left: on ? 22 : 2 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
      />
    </button>
  )
}

function Stepper({
  value,
  onChange,
  min,
  max,
  step,
  suffix,
  label,
}: {
  value: number
  onChange: (v: number) => void
  min: number
  max: number
  step: number
  suffix?: string
  label: string
}) {
  return (
    <div className="flex items-center gap-1" role="group" aria-label={label}>
      <button
        type="button"
        onClick={() => onChange(Math.max(min, value - step))}
        disabled={value <= min}
        aria-label={`Decrease ${label}`}
        className="flex h-7 w-7 items-center justify-center rounded-md border border-border font-mono text-sm text-muted-foreground hover:bg-secondary disabled:opacity-30"
      >
        −
      </button>
      <span className="w-14 text-center font-mono text-xs text-foreground">
        {value}
        {suffix}
      </span>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, value + step))}
        disabled={value >= max}
        aria-label={`Increase ${label}`}
        className="flex h-7 w-7 items-center justify-center rounded-md border border-border font-mono text-sm text-muted-foreground hover:bg-secondary disabled:opacity-30"
      >
        +
      </button>
    </div>
  )
}

export function SettingsModal() {
  const settingsOpen = useIdeStore((s) => s.settingsOpen)
  const setSettingsOpen = useIdeStore((s) => s.setSettingsOpen)
  const settings = useIdeStore((s) => s.settings)
  const updateSettings = useIdeStore((s) => s.updateSettings)
  const resetSettings = useIdeStore((s) => s.resetSettings)

  const [notifDenied, setNotifDenied] = useState(false)
  const [confirmReset, setConfirmReset] = useState(false)

  const handleNotificationToggle = async (enable: boolean) => {
    if (!enable) {
      updateSettings({ notificationsEnabled: false })
      setNotifDenied(false)
      return
    }
    const permission = await requestNotificationPermission()
    if (permission === 'granted') {
      updateSettings({ notificationsEnabled: true })
      setNotifDenied(false)
    } else {
      updateSettings({ notificationsEnabled: false })
      setNotifDenied(true)
    }
  }

  const resetAll = () => {
    resetSettings()
    setConfirmReset(false)
  }

  return (
    <AnimatePresence>
      {settingsOpen ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          onClick={() => setSettingsOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="IDE Settings"
        >
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.97 }}
            transition={{ duration: 0.2 }}
            className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-xl border border-border bg-popover shadow-2xl shadow-black/50"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex shrink-0 items-center justify-between border-b border-border px-5 py-3.5">
              <h2 className="font-mono text-sm font-bold tracking-wide text-foreground">IDE SETTINGS</h2>
              <button
                type="button"
                onClick={() => setSettingsOpen(false)}
                aria-label="Close settings"
                className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <div className="min-h-0 flex-1 divide-y divide-border overflow-y-auto px-5">
              <section className="py-3">
                <h3 className="flex items-center gap-2 pb-1 font-mono text-[10px] uppercase tracking-widest text-primary">
                  <Palette className="h-3 w-3" aria-hidden="true" /> Appearance
                </h3>
                <SettingRow label="Accent Theme" hint="Primary highlight color across the IDE.">
                  <div className="flex gap-1.5" role="radiogroup" aria-label="Accent theme">
                    {THEMES.map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        role="radio"
                        aria-checked={settings.accentTheme === t.id}
                        aria-label={t.label}
                        title={t.label}
                        onClick={() => updateSettings({ accentTheme: t.id })}
                        className={`h-7 w-7 rounded-full border-2 transition-transform hover:scale-110 ${
                          settings.accentTheme === t.id ? 'border-foreground' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: t.swatch }}
                      />
                    ))}
                  </div>
                </SettingRow>
              </section>

              <section className="py-3">
                <h3 className="flex items-center gap-2 pb-1 font-mono text-[10px] uppercase tracking-widest text-primary">
                  <Type className="h-3 w-3" aria-hidden="true" /> Editor
                </h3>
                <SettingRow label="Font Size">
                  <Stepper
                    value={settings.fontSize}
                    onChange={(v) => updateSettings({ fontSize: v })}
                    min={10}
                    max={24}
                    step={1}
                    suffix="px"
                    label="font size"
                  />
                </SettingRow>
                <SettingRow label="Editor Font">
                  <select
                    value={settings.editorFont}
                    onChange={(e) => updateSettings({ editorFont: e.target.value as EditorFont })}
                    aria-label="Editor font family"
                    className="rounded-md border border-border bg-secondary px-2 py-1.5 font-mono text-xs text-foreground outline-none focus:border-primary/60"
                  >
                    {EDITOR_FONTS.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.label}
                      </option>
                    ))}
                  </select>
                </SettingRow>
                <SettingRow label="Tab Size">
                  <Stepper
                    value={settings.tabSize}
                    onChange={(v) => updateSettings({ tabSize: v })}
                    min={2}
                    max={8}
                    step={2}
                    label="tab size"
                  />
                </SettingRow>
                <SettingRow label="Word Wrap" hint="Wrap long lines instead of horizontal scrolling.">
                  <Toggle on={settings.wordWrap} onChange={(v) => updateSettings({ wordWrap: v })} label="Word wrap" />
                </SettingRow>
                <SettingRow label="Auto Save" hint="Persist changes to the virtual filesystem as you type.">
                  <Toggle on={settings.autoSave} onChange={(v) => updateSettings({ autoSave: v })} label="Auto save" />
                </SettingRow>
              </section>

              <section className="py-3">
                <h3 className="flex items-center gap-2 pb-1 font-mono text-[10px] uppercase tracking-widest text-primary">
                  <Bell className="h-3 w-3" aria-hidden="true" /> Notifications
                </h3>
                <SettingRow
                  label="Build Notifications"
                  hint="Real browser notifications for build completed, build failed, export finished, and long-running tasks. Optional."
                >
                  <Toggle
                    on={settings.notificationsEnabled}
                    onChange={handleNotificationToggle}
                    label="Build notifications"
                  />
                </SettingRow>
                {notifDenied || getNotificationPermission() === 'denied' ? (
                  <div className="mb-2 flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2">
                    <BellOff className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" aria-hidden="true" />
                    <p className="text-[11px] leading-relaxed text-muted-foreground">
                      Notifications are blocked by your browser. Enable them in your browser&apos;s site settings, then
                      toggle again.
                    </p>
                  </div>
                ) : null}
              </section>

              <section className="py-3">
                <h3 className="flex items-center gap-2 pb-1 font-mono text-[10px] uppercase tracking-widest text-primary">
                  <Hammer className="h-3 w-3" aria-hidden="true" /> Build
                </h3>
                <SettingRow label="Verbose Build Logs" hint="Stream detailed gradle-style task logs during builds.">
                  <Toggle
                    on={settings.verboseBuildLogs}
                    onChange={(v) => updateSettings({ verboseBuildLogs: v })}
                    label="Verbose build logs"
                  />
                </SettingRow>
                <SettingRow label="Auto-open Build Panel" hint="Reveal the build console when a build starts.">
                  <Toggle
                    on={settings.autoOpenBuildPanel}
                    onChange={(v) => updateSettings({ autoOpenBuildPanel: v })}
                    label="Auto-open build panel"
                  />
                </SettingRow>
              </section>

              <section className="py-4">
                {confirmReset ? (
                  <div className="flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2.5">
                    <p className="flex items-center gap-2 font-mono text-[11px] text-foreground">
                      <AlertTriangle className="h-3.5 w-3.5 text-destructive" aria-hidden="true" />
                      Reset all settings to defaults?
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setConfirmReset(false)}
                        className="rounded-md px-2.5 py-1 font-mono text-[11px] text-muted-foreground hover:bg-secondary"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={resetAll}
                        className="rounded-md bg-destructive px-2.5 py-1 font-mono text-[11px] font-semibold text-destructive-foreground hover:opacity-90"
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmReset(true)}
                    className="flex items-center gap-2 rounded-md border border-border px-3 py-2 font-mono text-[11px] text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive"
                  >
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                    Reset settings to defaults
                  </button>
                )}
              </section>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
