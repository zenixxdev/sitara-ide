'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ChevronDown,
  ChevronRight,
  ChevronsDownUp,
  ChevronsUpDown,
  Copy,
  FileCode2,
  FileCog,
  FileJson,
  FilePlus2,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  MoreHorizontal,
  Pencil,
  RefreshCw,
  Trash2,
} from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import type { VirtualFile } from '@/lib/types'
import { walkTree } from '@/lib/vfs'

/** Picks an icon component + color class based on the file extension. */
function fileVisual(name: string): { Icon: typeof FileText; colorClass: string } {
  if (name.endsWith('.kt')) return { Icon: FileCode2, colorClass: 'text-violet-400' }
  if (name.endsWith('.java')) return { Icon: FileCode2, colorClass: 'text-orange-400' }
  if (name.endsWith('.xml')) return { Icon: FileCode2, colorClass: 'text-sky-400' }
  if (name.endsWith('.gradle') || name.endsWith('.properties')) return { Icon: FileCog, colorClass: 'text-accent' }
  if (name.endsWith('.json')) return { Icon: FileJson, colorClass: 'text-yellow-400' }
  return { Icon: FileText, colorClass: 'text-muted-foreground' }
}

interface ContextMenuState {
  x: number
  y: number
  node: VirtualFile
}

interface InlineEditState {
  mode: 'create_file' | 'create_folder' | 'rename'
  /** Folder to create in, or path being renamed. */
  targetPath: string
  initialValue: string
}

export default function FileExplorer() {
  const activeTree = useIdeStore((state) =>
    state.activeProjectId === null ? [] : (state.projects[state.activeProjectId]?.tree ?? []),
  )
  const activePath = useIdeStore((state) => state.activePath)
  const openFile = useIdeStore((state) => state.openFile)
  const fsCreateFile = useIdeStore((state) => state.fsCreateFile)
  const fsCreateFolder = useIdeStore((state) => state.fsCreateFolder)
  const fsRename = useIdeStore((state) => state.fsRename)
  const fsDelete = useIdeStore((state) => state.fsDelete)
  const fsDuplicate = useIdeStore((state) => state.fsDuplicate)
  const fsMove = useIdeStore((state) => state.fsMove)

  const allFolderPaths = useMemo(() => {
    const paths: string[] = []
    walkTree(activeTree, (node) => {
      if (node.type === 'folder') paths.push(node.path)
    })
    return paths
  }, [activeTree])

  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(allFolderPaths))
  const [menu, setMenu] = useState<ContextMenuState | null>(null)
  const [inlineEdit, setInlineEdit] = useState<InlineEditState | null>(null)
  const [fsError, setFsError] = useState<string | null>(null)
  const [dragOverPath, setDragOverPath] = useState<string | null>(null)
  const [refreshSpin, setRefreshSpin] = useState<boolean>(false)
  const inputRef = useRef<HTMLInputElement | null>(null)

  // Dismiss the context menu on any outside click.
  useEffect(() => {
    if (menu === null) return
    const close = () => setMenu(null)
    window.addEventListener('click', close)
    return () => window.removeEventListener('click', close)
  }, [menu])

  // Focus the inline edit input when it appears.
  useEffect(() => {
    if (inlineEdit !== null) inputRef.current?.select()
  }, [inlineEdit])

  // Auto-clear filesystem error toasts.
  useEffect(() => {
    if (fsError === null) return
    const timer = window.setTimeout(() => setFsError(null), 3500)
    return () => window.clearTimeout(timer)
  }, [fsError])

  const toggleFolder = useCallback((path: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(path)) next.delete(path)
      else next.add(path)
      return next
    })
  }, [])

  const openContextMenu = useCallback((event: React.MouseEvent, node: VirtualFile) => {
    event.preventDefault()
    event.stopPropagation()
    setMenu({ x: Math.min(event.clientX, window.innerWidth - 190), y: Math.min(event.clientY, window.innerHeight - 260), node })
  }, [])

  const commitInlineEdit = useCallback(
    (value: string) => {
      if (inlineEdit === null) return
      const trimmed = value.trim()
      setInlineEdit(null)
      if (trimmed.length === 0) return
      let error: string | null = null
      if (inlineEdit.mode === 'create_file') error = fsCreateFile(inlineEdit.targetPath, trimmed)
      else if (inlineEdit.mode === 'create_folder') error = fsCreateFolder(inlineEdit.targetPath, trimmed)
      else error = fsRename(inlineEdit.targetPath, trimmed)
      if (error !== null) setFsError(error)
      if (inlineEdit.mode !== 'rename') {
        setExpanded((prev) => new Set(prev).add(inlineEdit.targetPath))
      }
    },
    [inlineEdit, fsCreateFile, fsCreateFolder, fsRename],
  )

  const startCreate = useCallback(
    (mode: 'create_file' | 'create_folder', node: VirtualFile | null) => {
      const target = node === null ? '' : node.type === 'folder' ? node.path : node.path.split('/').slice(0, -1).join('/')
      setInlineEdit({ mode, targetPath: target, initialValue: '' })
      setMenu(null)
    },
    [],
  )

  const handleDrop = useCallback(
    (event: React.DragEvent, destFolder: string) => {
      event.preventDefault()
      event.stopPropagation()
      setDragOverPath(null)
      const sourcePath = event.dataTransfer.getData('application/x-sitara-path')
      if (sourcePath.length === 0) return
      const error = fsMove(sourcePath, destFolder)
      if (error !== null) setFsError(error)
      else setExpanded((prev) => new Set(prev).add(destFolder))
    },
    [fsMove],
  )

  const handleRefresh = useCallback(() => {
    setRefreshSpin(true)
    setExpanded(new Set(allFolderPaths))
    window.setTimeout(() => setRefreshSpin(false), 600)
  }, [allFolderPaths])

  const renderInlineInput = (depth: number): React.ReactNode => (
    <li style={{ paddingLeft: `${depth * 14 + 26}px` }} className="py-0.5 pr-2">
      <input
        ref={inputRef}
        type="text"
        defaultValue={inlineEdit?.initialValue ?? ''}
        aria-label={inlineEdit?.mode === 'rename' ? 'New name' : 'Name'}
        placeholder={inlineEdit?.mode === 'create_folder' ? 'folder-name' : 'FileName.kt'}
        onKeyDown={(event) => {
          if (event.key === 'Enter' && !(event.nativeEvent as KeyboardEvent).isComposing && event.keyCode !== 229) {
            commitInlineEdit((event.target as HTMLInputElement).value)
          }
          if (event.key === 'Escape') setInlineEdit(null)
        }}
        onBlur={(event) => commitInlineEdit(event.target.value)}
        className="w-full rounded border border-primary/60 bg-background px-1.5 py-0.5 font-mono text-xs text-foreground outline-none"
      />
    </li>
  )

  const renderNode = (node: VirtualFile, depth: number): React.ReactNode => {
    const indent = { paddingLeft: `${depth * 14 + 8}px` }
    const isRenaming = inlineEdit?.mode === 'rename' && inlineEdit.targetPath === node.path

    if (isRenaming) {
      return (
        <li key={node.path} style={{ paddingLeft: `${depth * 14 + 8}px` }} className="py-0.5 pr-2">
          <input
            ref={inputRef}
            type="text"
            defaultValue={node.name}
            aria-label={`Rename ${node.name}`}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !(event.nativeEvent as KeyboardEvent).isComposing && event.keyCode !== 229) {
                commitInlineEdit((event.target as HTMLInputElement).value)
              }
              if (event.key === 'Escape') setInlineEdit(null)
            }}
            onBlur={(event) => commitInlineEdit(event.target.value)}
            className="w-full rounded border border-primary/60 bg-background px-1.5 py-0.5 font-mono text-xs text-foreground outline-none"
          />
        </li>
      )
    }

    if (node.type === 'folder') {
      const isExpanded = expanded.has(node.path)
      const FolderIcon = isExpanded ? FolderOpen : Folder
      const Chevron = isExpanded ? ChevronDown : ChevronRight
      const isDragTarget = dragOverPath === node.path
      const creatingHere =
        inlineEdit !== null && inlineEdit.mode !== 'rename' && inlineEdit.targetPath === node.path

      return (
        <li key={node.path}>
          <button
            type="button"
            draggable
            onDragStart={(event) => event.dataTransfer.setData('application/x-sitara-path', node.path)}
            onDragOver={(event) => {
              event.preventDefault()
              setDragOverPath(node.path)
            }}
            onDragLeave={() => setDragOverPath((prev) => (prev === node.path ? null : prev))}
            onDrop={(event) => handleDrop(event, node.path)}
            onClick={() => toggleFolder(node.path)}
            onContextMenu={(event) => openContextMenu(event, node)}
            aria-expanded={isExpanded}
            style={indent}
            className={`group flex w-full items-center gap-1.5 rounded-md py-1 pr-1 text-left text-sm transition-colors ${
              isDragTarget
                ? 'bg-primary/20 text-foreground outline-1 outline-dashed outline-primary'
                : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
            }`}
          >
            <Chevron className="size-3.5 shrink-0" aria-hidden="true" />
            <FolderIcon className="size-4 shrink-0 text-primary/70" aria-hidden="true" />
            <span className="truncate font-mono text-xs">{node.name}</span>
            <span
              role="button"
              tabIndex={-1}
              aria-label={`Actions for ${node.name}`}
              onClick={(event) => openContextMenu(event as React.MouseEvent, node)}
              className="ml-auto rounded p-0.5 opacity-0 transition-opacity hover:bg-muted group-hover:opacity-100"
            >
              <MoreHorizontal className="size-3.5" aria-hidden="true" />
            </span>
          </button>
          <AnimatePresence initial={false}>
            {isExpanded && (
              <motion.ul
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.16 }}
                className="overflow-hidden"
              >
                {creatingHere && renderInlineInput(depth + 1)}
                {(node.children ?? []).map((child) => renderNode(child, depth + 1))}
              </motion.ul>
            )}
          </AnimatePresence>
        </li>
      )
    }

    const { Icon, colorClass } = fileVisual(node.name)
    const isActive = activePath === node.path
    return (
      <li key={node.path}>
        <button
          type="button"
          draggable
          onDragStart={(event) => event.dataTransfer.setData('application/x-sitara-path', node.path)}
          onClick={() => openFile(node.path)}
          onContextMenu={(event) => openContextMenu(event, node)}
          aria-current={isActive ? 'true' : undefined}
          style={indent}
          className={`group flex w-full items-center gap-1.5 rounded-md py-1 pr-1 text-left transition-colors ${
            isActive
              ? 'bg-primary/15 text-foreground'
              : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
          }`}
        >
          <span className="size-3.5 shrink-0" aria-hidden="true" />
          <Icon className={`size-4 shrink-0 ${colorClass}`} aria-hidden="true" />
          <span className="truncate font-mono text-xs">{node.name}</span>
          <span
            role="button"
            tabIndex={-1}
            aria-label={`Actions for ${node.name}`}
            onClick={(event) => openContextMenu(event as React.MouseEvent, node)}
            className="ml-auto rounded p-0.5 opacity-0 transition-opacity hover:bg-muted group-hover:opacity-100"
          >
            <MoreHorizontal className="size-3.5" aria-hidden="true" />
          </span>
        </button>
      </li>
    )
  }

  const creatingAtRoot = inlineEdit !== null && inlineEdit.mode !== 'rename' && inlineEdit.targetPath === ''

  return (
    <nav aria-label="Project files" className="flex h-full min-h-0 flex-col">
      {/* Explorer toolbar */}
      <div className="flex shrink-0 items-center gap-0.5 border-b border-border px-2 py-1.5">
        <p className="mr-auto font-mono text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
          Explorer
        </p>
        <button
          type="button"
          onClick={() => startCreate('create_file', null)}
          aria-label="New file at root"
          title="New File"
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <FilePlus2 className="size-3.5" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => startCreate('create_folder', null)}
          aria-label="New folder at root"
          title="New Folder"
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <FolderPlus className="size-3.5" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={handleRefresh}
          aria-label="Refresh tree"
          title="Refresh"
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <RefreshCw className={`size-3.5 ${refreshSpin ? 'animate-spin' : ''}`} aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => setExpanded(new Set(allFolderPaths))}
          aria-label="Expand all folders"
          title="Expand All"
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <ChevronsUpDown className="size-3.5" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => setExpanded(new Set())}
          aria-label="Collapse all folders"
          title="Collapse All"
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <ChevronsDownUp className="size-3.5" aria-hidden="true" />
        </button>
      </div>

      {/* Tree (root is also a drop target) */}
      <div
        className="min-h-0 flex-1 overflow-y-auto py-1 pr-1"
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => handleDrop(event, '')}
      >
        <ul>
          {creatingAtRoot && renderInlineInput(0)}
          {activeTree.map((node) => renderNode(node, 0))}
        </ul>
      </div>

      {/* Filesystem error toast */}
      <AnimatePresence>
        {fsError !== null && (
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            role="alert"
            className="m-2 rounded-md border border-destructive/40 bg-destructive/10 px-2 py-1.5 text-xs text-destructive"
          >
            {fsError}
          </motion.p>
        )}
      </AnimatePresence>

      {/* Context menu */}
      <AnimatePresence>
        {menu !== null && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.12 }}
            role="menu"
            aria-label={`Actions for ${menu.node.name}`}
            style={{ left: menu.x, top: menu.y }}
            className="fixed z-50 w-44 overflow-hidden rounded-lg border border-border bg-popover py-1 shadow-2xl shadow-black/40"
          >
            {menu.node.type === 'folder' && (
              <>
                <ContextItem icon={FilePlus2} label="New File" onSelect={() => startCreate('create_file', menu.node)} />
                <ContextItem
                  icon={FolderPlus}
                  label="New Folder"
                  onSelect={() => startCreate('create_folder', menu.node)}
                />
                <div className="my-1 h-px bg-border" aria-hidden="true" />
              </>
            )}
            <ContextItem
              icon={Pencil}
              label="Rename"
              onSelect={() => {
                setInlineEdit({ mode: 'rename', targetPath: menu.node.path, initialValue: menu.node.name })
                setMenu(null)
              }}
            />
            <ContextItem
              icon={Copy}
              label="Duplicate"
              onSelect={() => {
                const error = fsDuplicate(menu.node.path)
                if (error !== null) setFsError(error)
                setMenu(null)
              }}
            />
            <div className="my-1 h-px bg-border" aria-hidden="true" />
            <ContextItem
              icon={Trash2}
              label="Delete"
              destructive
              onSelect={() => {
                fsDelete(menu.node.path)
                setMenu(null)
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}

interface ContextItemProps {
  icon: typeof Pencil
  label: string
  destructive?: boolean
  onSelect: () => void
}

function ContextItem({ icon: Icon, label, destructive = false, onSelect }: ContextItemProps) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onSelect}
      className={`flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs transition-colors ${
        destructive
          ? 'text-destructive hover:bg-destructive/10'
          : 'text-popover-foreground hover:bg-secondary'
      }`}
    >
      <Icon className="size-3.5" aria-hidden="true" />
      {label}
    </button>
  )
}
