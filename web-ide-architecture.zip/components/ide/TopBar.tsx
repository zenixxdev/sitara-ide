'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Hammer,
  Play,
  Save,
  Search,
  Undo2,
  Redo2,
  AlignLeft,
  Settings,
  MoreVertical,
  ChevronLeft,
  Loader2,
  CheckCircle2,
  XCircle,
  CircleDashed,
  PanelLeft,
  PanelBottom,
  FolderInput,
  FolderOutput,
  Copy,
  Trash2,
  PencilLine,
  BarChart3,
} from 'lucide-react'
import { useIdeStore, type ProjectAction } from '@/lib/ideStore'
import { dispatchEditorCommand } from '@/lib/editorBus'
import type { BuildStatus } from '@/lib/types'

function buildStatusMeta(status: BuildStatus): {
  icon: React.ReactNode
  label: string
  className: string
} {
  switch (status) {
    case 'queued':
    case 'running':
      return {
        icon: <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />,
        label: status === 'queued' ? 'Queued' : 'Building',
        className: 'text-primary border-primary/40 bg-primary/10',
      }
    case 'success':
      return {
        icon: <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />,
        label: 'Build OK',
        className: 'text-accent border-accent/40 bg-accent/10',
      }
    case 'failed':
      return {
        icon: <XCircle className="h-3.5 w-3.5" aria-hidden="true" />,
        label: 'Build Failed',
        className: 'text-destructive border-destructive/40 bg-destructive/10',
      }
    default:
      return {
        icon: <CircleDashed className="h-3.5 w-3.5" aria-hidden="true" />,
        label: 'Idle',
        className: 'text-muted-foreground border-border bg-secondary/40',
      }
  }
}

interface IconButtonProps {
  label: string
  onClick: () => void
  disabled?: boolean
  children: React.ReactNode
  active?: boolean
}

function IconButton({ label, onClick, disabled, children, active }: IconButtonProps) {
  return (
    <motion.button
      type="button"
      whileHover={disabled ? undefined : { scale: 1.08 }}
      whileTap={disabled ? undefined : { scale: 0.94 }}
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className={`flex h-8 w-8 items-center justify-center rounded-md border transition-colors ${
        active
          ? 'border-primary/50 bg-primary/15 text-primary'
          : 'border-transparent text-muted-foreground hover:border-border hover:bg-secondary hover:text-foreground'
      } disabled:cursor-not-allowed disabled:opacity-35`}
    >
      {children}
    </motion.button>
  )
}

export function TopBar() {
  const activeProjectId = useIdeStore((s) => s.activeProjectId)
  const projects = useIdeStore((s) => s.projects)
  const activePath = useIdeStore((s) => s.activePath)
  const tabs = useIdeStore((s) => s.tabs)
  const buildProgress = useIdeStore((s) => s.buildProgress)
  const sidebarOpen = useIdeStore((s) => s.sidebarOpen)
  const bottomPanelOpen = useIdeStore((s) => s.bottomPanelOpen)
  const toggleSidebar = useIdeStore((s) => s.toggleSidebar)
  const setBottomPanel = useIdeStore((s) => s.setBottomPanel)
  const saveFile = useIdeStore((s) => s.saveFile)
  const saveAll = useIdeStore((s) => s.saveAll)
  const startBuild = useIdeStore((s) => s.startBuild)
  const closeProject = useIdeStore((s) => s.closeProject)
  const setSearchOpen = useIdeStore((s) => s.setSearchOpen)
  const setSettingsOpen = useIdeStore((s) => s.setSettingsOpen)
  const setProjectAction = useIdeStore((s) => s.setProjectAction)

  const [moreOpen, setMoreOpen] = useState(false)
  const moreRef = useRef<HTMLDivElement>(null)

  const project = activeProjectId !== null ? projects[activeProjectId]?.config : undefined
  const activeTab = tabs.find((t) => t.path === activePath)
  const dirtyCount = tabs.filter((t) => t.dirty).length
  const status = buildStatusMeta(buildProgress.status)
  const building = buildProgress.status === 'running' || buildProgress.status === 'queued'

  useEffect(() => {
    if (!moreOpen) return
    const onDown = (e: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
        setMoreOpen(false)
      }
    }
    window.addEventListener('mousedown', onDown)
    return () => window.removeEventListener('mousedown', onDown)
  }, [moreOpen])

  const openProjectAction = useCallback(
    (action: ProjectAction) => {
      setMoreOpen(false)
      setProjectAction(action)
    },
    [setProjectAction],
  )

  if (project === undefined) return null

  return (
    <header className="flex h-12 shrink-0 items-center gap-1.5 border-b border-border bg-card/80 px-2 backdrop-blur-md md:gap-2 md:px-3">
      <IconButton label="Back to Dashboard" onClick={closeProject}>
        <ChevronLeft className="h-4 w-4" aria-hidden="true" />
      </IconButton>

      <IconButton label={sidebarOpen ? 'Hide Explorer' : 'Show Explorer'} onClick={toggleSidebar} active={sidebarOpen}>
        <PanelLeft className="h-4 w-4" aria-hidden="true" />
      </IconButton>

      <div className="mx-1 hidden min-w-0 items-center gap-2 sm:flex">
        <span className="max-w-[140px] truncate font-mono text-sm font-semibold text-foreground lg:max-w-[220px]">
          {project.name}
        </span>
        <span
          className={`rounded border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${
            project.language === 'kotlin'
              ? 'border-[oklch(0.62_0.2_300)]/40 bg-[oklch(0.62_0.2_300)]/10 text-[oklch(0.75_0.15_300)]'
              : 'border-[oklch(0.7_0.17_55)]/40 bg-[oklch(0.7_0.17_55)]/10 text-[oklch(0.75_0.14_55)]'
          }`}
        >
          {project.language}
        </span>
        {activeTab !== undefined ? (
          <span className="hidden max-w-[180px] truncate font-mono text-xs text-muted-foreground md:inline">
            {activeTab.name}
            {activeTab.dirty ? <span className="text-primary"> ●</span> : null}
          </span>
        ) : null}
      </div>

      <div className="flex-1" />

      <div
        className={`hidden items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] sm:flex ${status.className}`}
        role="status"
        aria-live="polite"
      >
        {status.icon}
        <span>{status.label}</span>
      </div>

      <div className="mx-1 h-6 w-px bg-border" aria-hidden="true" />

      <motion.button
        type="button"
        whileHover={building ? undefined : { scale: 1.05 }}
        whileTap={building ? undefined : { scale: 0.95 }}
        onClick={() => startBuild('build')}
        disabled={building}
        className="flex h-8 items-center gap-1.5 rounded-md border border-primary/40 bg-primary/10 px-2.5 font-mono text-xs font-semibold text-primary transition-colors hover:bg-primary/20 disabled:cursor-not-allowed disabled:opacity-40 md:px-3"
        aria-label="Build project"
      >
        {building ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
        ) : (
          <Hammer className="h-3.5 w-3.5" aria-hidden="true" />
        )}
        <span className="hidden md:inline">Build</span>
      </motion.button>

      <motion.button
        type="button"
        whileHover={building ? undefined : { scale: 1.05 }}
        whileTap={building ? undefined : { scale: 0.95 }}
        onClick={() => startBuild('run')}
        disabled={building}
        className="flex h-8 items-center gap-1.5 rounded-md border border-accent/40 bg-accent/10 px-2.5 font-mono text-xs font-semibold text-accent transition-colors hover:bg-accent/20 disabled:cursor-not-allowed disabled:opacity-40 md:px-3"
        aria-label="Run project"
      >
        <Play className="h-3.5 w-3.5" aria-hidden="true" />
        <span className="hidden md:inline">Run</span>
      </motion.button>

      <div className="mx-1 h-6 w-px bg-border" aria-hidden="true" />

      <div className="hidden items-center gap-0.5 md:flex">
        <IconButton
          label={`Save (Ctrl+S)${dirtyCount > 0 ? ` — ${dirtyCount} unsaved` : ''}`}
          onClick={() => {
            if (activePath !== null) saveFile(activePath)
          }}
          disabled={activeTab === undefined || !activeTab.dirty}
        >
          <Save className="h-4 w-4" aria-hidden="true" />
        </IconButton>
        <IconButton label="Search everywhere (Ctrl+Shift+P)" onClick={() => setSearchOpen(true)}>
          <Search className="h-4 w-4" aria-hidden="true" />
        </IconButton>
        <IconButton
          label="Undo (Ctrl+Z)"
          onClick={() => dispatchEditorCommand('undo')}
          disabled={activeTab === undefined}
        >
          <Undo2 className="h-4 w-4" aria-hidden="true" />
        </IconButton>
        <IconButton
          label="Redo (Ctrl+Y)"
          onClick={() => dispatchEditorCommand('redo')}
          disabled={activeTab === undefined}
        >
          <Redo2 className="h-4 w-4" aria-hidden="true" />
        </IconButton>
        <IconButton
          label="Format file"
          onClick={() => dispatchEditorCommand('format')}
          disabled={activeTab === undefined}
        >
          <AlignLeft className="h-4 w-4" aria-hidden="true" />
        </IconButton>
      </div>

      <IconButton
        label={bottomPanelOpen ? 'Hide bottom panel' : 'Show bottom panel'}
        onClick={() => setBottomPanel(!bottomPanelOpen)}
        active={bottomPanelOpen}
      >
        <PanelBottom className="h-4 w-4" aria-hidden="true" />
      </IconButton>

      <IconButton label="Settings" onClick={() => setSettingsOpen(true)}>
        <Settings className="h-4 w-4" aria-hidden="true" />
      </IconButton>

      <div className="relative" ref={moreRef}>
        <IconButton label="More actions" onClick={() => setMoreOpen((o) => !o)} active={moreOpen}>
          <MoreVertical className="h-4 w-4" aria-hidden="true" />
        </IconButton>
        <AnimatePresence>
          {moreOpen ? (
            <motion.div
              initial={{ opacity: 0, y: -6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.96 }}
              transition={{ duration: 0.14 }}
              className="absolute right-0 top-10 z-50 w-56 overflow-hidden rounded-lg border border-border bg-popover shadow-xl shadow-black/40"
              role="menu"
            >
              <div className="border-b border-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                Project Actions
              </div>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMoreOpen(false)
                  saveAll()
                }}
                className="flex w-full items-center gap-2.5 px-3 py-2 text-left font-mono text-xs text-foreground transition-colors hover:bg-secondary"
              >
                <Save className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                Save All
              </button>
              {(
                [
                  { label: 'Rename Project', icon: PencilLine, action: 'rename' },
                  { label: 'Duplicate Project', icon: Copy, action: 'duplicate' },
                  { label: 'Export Project (JSON)', icon: FolderOutput, action: 'export' },
                  { label: 'Import Project', icon: FolderInput, action: 'import' },
                  { label: 'Project Statistics', icon: BarChart3, action: 'stats' },
                  { label: 'Delete Project', icon: Trash2, action: 'delete', danger: true },
                ] as { label: string; icon: typeof Save; action: ProjectAction; danger?: boolean }[]
              ).map((item) => (
                <button
                  key={item.action}
                  type="button"
                  role="menuitem"
                  onClick={() => openProjectAction(item.action)}
                  className={`flex w-full items-center gap-2.5 px-3 py-2 text-left font-mono text-xs transition-colors hover:bg-secondary ${
                    item.danger === true ? 'text-destructive hover:text-destructive' : 'text-foreground'
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  {item.label}
                </button>
              ))}
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </header>
  )
}
