'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { motion } from 'framer-motion'
import {
  Hammer,
  ScrollText,
  AlertTriangle,
  FileOutput,
  TerminalSquare,
  Trash2,
  X,
  Download,
  CheckCircle2,
  XCircle,
  Loader2,
} from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import { BUILD_STEPS } from '@/lib/buildSystem'
import type { BottomPanelTab, LogEntry, LogLevel } from '@/lib/types'

const TAB_DEFS: { id: BottomPanelTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'build', label: 'Build', icon: Hammer },
  { id: 'logs', label: 'Logs', icon: ScrollText },
  { id: 'problems', label: 'Problems', icon: AlertTriangle },
  { id: 'output', label: 'Output', icon: FileOutput },
  { id: 'terminal', label: 'Terminal', icon: TerminalSquare },
]

const LEVEL_STYLES: Record<LogLevel, string> = {
  info: 'text-muted-foreground',
  warning: 'text-[oklch(0.8_0.14_85)]',
  error: 'text-destructive',
  success: 'text-accent',
}

function LogLine({ entry }: { entry: LogEntry }) {
  return (
    <div className="flex gap-2 whitespace-pre-wrap break-all px-3 py-0.5 font-mono text-[11px] leading-5 hover:bg-secondary/40">
      <span className="shrink-0 select-none text-muted-foreground/50">{entry.timestamp}</span>
      <span className={LEVEL_STYLES[entry.level]}>{entry.text}</span>
    </div>
  )
}

function LogView({ entries, emptyText }: { entries: LogEntry[]; emptyText: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current
    if (el !== null) el.scrollTop = el.scrollHeight
  }, [entries.length])

  return (
    <div ref={ref} className="h-full overflow-y-auto py-1" role="log" aria-live="polite">
      {entries.length === 0 ? (
        <p className="px-3 py-2 font-mono text-[11px] text-muted-foreground/60">{emptyText}</p>
      ) : (
        entries.map((e) => <LogLine key={e.id} entry={e} />)
      )}
    </div>
  )
}

function BuildTab() {
  const buildProgress = useIdeStore((s) => s.buildProgress)
  const buildLogs = useIdeStore((s) => s.buildLogs)
  const artifact = useIdeStore((s) => s.artifact)

  const running = buildProgress.status === 'running' || buildProgress.status === 'queued'
  const stepLabel =
    buildProgress.currentStep !== null
      ? (BUILD_STEPS.find((step) => step.id === buildProgress.currentStep)?.label ?? buildProgress.currentStep)
      : buildProgress.status === 'success'
        ? 'Build finished'
        : buildProgress.status === 'failed'
          ? 'Build failed'
          : 'Waiting'
  const durationMs =
    buildProgress.startedAt !== null && buildProgress.finishedAt !== null
      ? buildProgress.finishedAt - buildProgress.startedAt
      : null

  return (
    <div className="flex h-full flex-col">
      {buildProgress.status !== 'idle' ? (
        <div className="shrink-0 border-b border-border px-3 py-2">
          <div className="flex items-center gap-3">
            {running ? (
              <Loader2 className="h-4 w-4 shrink-0 animate-spin text-primary" aria-hidden="true" />
            ) : buildProgress.status === 'success' ? (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 300, damping: 15 }}
              >
                <CheckCircle2 className="h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
              </motion.span>
            ) : (
              <motion.span initial={{ x: 0 }} animate={{ x: [0, -4, 4, -3, 3, 0] }} transition={{ duration: 0.4 }}>
                <XCircle className="h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
              </motion.span>
            )}
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate font-mono text-xs text-foreground">{stepLabel}</span>
                <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                  {running && buildProgress.etaMs !== null
                    ? `~${Math.max(1, Math.round(buildProgress.etaMs / 1000))}s remaining`
                    : running
                      ? 'estimating…'
                      : durationMs !== null
                        ? `${(durationMs / 1000).toFixed(1)}s`
                        : ''}
                </span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-secondary">
                <motion.div
                  className={`h-full rounded-full ${
                    buildProgress.status === 'failed'
                      ? 'bg-destructive'
                      : buildProgress.status === 'success'
                        ? 'bg-accent'
                        : 'bg-primary'
                  }`}
                  animate={{ width: `${Math.round(buildProgress.progress * 100)}%` }}
                  transition={{ ease: 'easeOut', duration: 0.3 }}
                />
              </div>
            </div>
            {buildProgress.status === 'success' && artifact !== null ? (
              <motion.a
                href={artifact.url}
                download={artifact.fileName}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex shrink-0 items-center gap-1.5 rounded-md border border-accent/40 bg-accent/10 px-2.5 py-1.5 font-mono text-[11px] font-semibold text-accent hover:bg-accent/20"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                {artifact.fileName}
              </motion.a>
            ) : null}
          </div>
        </div>
      ) : null}
      <div className="min-h-0 flex-1">
        <LogView entries={buildLogs} emptyText="No build has run yet. Press Build to start the pipeline." />
      </div>
    </div>
  )
}

function ProblemsTab() {
  const problems = useIdeStore((s) => s.problems)
  const openFile = useIdeStore((s) => s.openFile)

  return (
    <div className="h-full overflow-y-auto py-1">
      {problems.length === 0 ? (
        <p className="px-3 py-2 font-mono text-[11px] text-muted-foreground/60">
          No problems detected. Problems appear here after builds validate the project.
        </p>
      ) : (
        problems.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => {
              if (p.filePath.length > 0) openFile(p.filePath)
            }}
            className="flex w-full items-start gap-2 px-3 py-1.5 text-left font-mono text-[11px] leading-5 hover:bg-secondary/50"
          >
            {p.severity === 'error' ? (
              <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" aria-hidden="true" />
            ) : (
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[oklch(0.8_0.14_85)]" aria-hidden="true" />
            )}
            <span className="min-w-0">
              <span className="text-foreground">{p.message}</span>
              {p.filePath.length > 0 ? <span className="ml-2 text-muted-foreground/60">{p.filePath}</span> : null}
            </span>
          </button>
        ))
      )}
    </div>
  )
}

const TERMINAL_LINE_STYLES: Record<'command' | 'output' | 'error', string> = {
  command: 'text-primary',
  output: 'text-muted-foreground',
  error: 'text-destructive',
}

function TerminalTab() {
  const terminalLines = useIdeStore((s) => s.terminalLines)
  const terminalCwd = useIdeStore((s) => s.terminalCwd)
  const runTerminalCommand = useIdeStore((s) => s.runTerminalCommand)
  const terminalHistory = useIdeStore((s) => s.terminalHistory)

  const [input, setInput] = useState('')
  const [historyIdx, setHistoryIdx] = useState<number | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const el = scrollRef.current
    if (el !== null) el.scrollTop = el.scrollHeight
  }, [terminalLines.length])

  const submit = useCallback(() => {
    const cmd = input.trim()
    if (cmd.length === 0) return
    runTerminalCommand(cmd)
    setInput('')
    setHistoryIdx(null)
  }, [input, runTerminalCommand])

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (e.nativeEvent.isComposing || e.keyCode === 229) return
      e.preventDefault()
      submit()
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (terminalHistory.length === 0) return
      const next = historyIdx === null ? terminalHistory.length - 1 : Math.max(0, historyIdx - 1)
      setHistoryIdx(next)
      setInput(terminalHistory[next] ?? '')
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIdx === null) return
      const next = historyIdx + 1
      if (next >= terminalHistory.length) {
        setHistoryIdx(null)
        setInput('')
      } else {
        setHistoryIdx(next)
        setInput(terminalHistory[next] ?? '')
      }
    }
  }

  return (
    <div
      className="flex h-full flex-col"
      onClick={() => inputRef.current?.focus()}
      role="presentation"
    >
      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto py-1" role="log">
        {terminalLines.length === 0 ? (
          <p className="px-3 py-2 font-mono text-[11px] text-muted-foreground/60">
            Sitara virtual shell. Type &apos;help&apos; for available commands.
          </p>
        ) : null}
        {terminalLines.map((line) => (
          <div
            key={line.id}
            className={`whitespace-pre-wrap break-all px-3 font-mono text-[11px] leading-5 ${TERMINAL_LINE_STYLES[line.kind]}`}
          >
            {line.text}
          </div>
        ))}
      </div>
      <div className="flex shrink-0 items-center gap-2 border-t border-border px-3 py-1.5">
        <span className="shrink-0 select-none font-mono text-[11px] text-accent">
          {terminalCwd === '' ? '~' : `~/${terminalCwd}`} $
        </span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          aria-label="Terminal command input"
          placeholder="Type 'help' for available commands"
          className="min-w-0 flex-1 bg-transparent font-mono text-[11px] text-foreground caret-primary outline-none placeholder:text-muted-foreground/40"
        />
      </div>
    </div>
  )
}

export function BottomPanel() {
  const activeTab = useIdeStore((s) => s.bottomPanelTab)
  const setBottomPanel = useIdeStore((s) => s.setBottomPanel)
  const clearPanel = useIdeStore((s) => s.clearPanel)
  const problems = useIdeStore((s) => s.problems)
  const systemLogs = useIdeStore((s) => s.systemLogs)
  const outputLogs = useIdeStore((s) => s.outputLogs)
  const buildProgress = useIdeStore((s) => s.buildProgress)

  const errorCount = problems.filter((p) => p.severity === 'error').length

  return (
    <div className="flex h-full min-h-0 flex-col bg-card/60">
      <div className="flex h-9 shrink-0 items-center border-b border-border px-1">
        <div className="flex items-center gap-0.5" role="tablist" aria-label="Bottom panel tabs">
          {TAB_DEFS.map((tab) => {
            const isActive = tab.id === activeTab
            const showBadge = tab.id === 'problems' && errorCount > 0 && !isActive
            const isBuildRunning = tab.id === 'build' && buildProgress.status === 'running'
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setBottomPanel(true, tab.id)}
                className={`relative flex items-center gap-1.5 rounded-md px-2.5 py-1.5 font-mono text-[11px] transition-colors ${
                  isActive ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <tab.icon
                  className={`h-3.5 w-3.5 ${isBuildRunning ? 'animate-pulse text-primary' : ''}`}
                  aria-hidden="true"
                />
                <span className="hidden sm:inline">{tab.label}</span>
                {showBadge ? (
                  <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[9px] font-bold text-destructive-foreground">
                    {errorCount}
                  </span>
                ) : null}
                {isActive ? (
                  <motion.div
                    layoutId="bottom-tab-underline"
                    className="absolute inset-x-1 -bottom-[5px] h-0.5 rounded-full bg-primary"
                  />
                ) : null}
              </button>
            )
          })}
        </div>
        <div className="flex-1" />
        <button
          type="button"
          onClick={() => clearPanel(activeTab)}
          title="Clear"
          aria-label="Clear current panel"
          className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => setBottomPanel(false)}
          title="Close panel"
          aria-label="Close bottom panel"
          className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <X className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </div>

      <div className="min-h-0 flex-1">
        {activeTab === 'build' ? <BuildTab /> : null}
        {activeTab === 'logs' ? <LogView entries={systemLogs} emptyText="IDE event log is empty." /> : null}
        {activeTab === 'problems' ? <ProblemsTab /> : null}
        {activeTab === 'output' ? <LogView entries={outputLogs} emptyText="Run the project to see output." /> : null}
        {activeTab === 'terminal' ? <TerminalTab /> : null}
      </div>
    </div>
  )
}
