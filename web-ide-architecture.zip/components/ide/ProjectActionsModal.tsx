'use client'

import { useState, useRef, useEffect, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  PencilLine,
  Copy,
  Trash2,
  FolderOutput,
  FolderInput,
  BarChart3,
  AlertTriangle,
  FileCode2,
  FolderTree,
  AlignLeft,
  HardDrive,
} from 'lucide-react'
import { useIdeStore, type ProjectAction } from '@/lib/ideStore'
import { computeStatistics } from '@/lib/vfs'
import { notify } from '@/lib/notifications'
import type { StoredProject } from '@/lib/types'

const TITLES: Record<ProjectAction, { title: string; icon: React.ComponentType<{ className?: string }> }> = {
  rename: { title: 'Rename Project', icon: PencilLine },
  duplicate: { title: 'Duplicate Project', icon: Copy },
  delete: { title: 'Delete Project', icon: Trash2 },
  export: { title: 'Export Project', icon: FolderOutput },
  import: { title: 'Import Project', icon: FolderInput },
  stats: { title: 'Project Statistics', icon: BarChart3 },
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

export function ProjectActionsModal() {
  const projectAction = useIdeStore((s) => s.projectAction)
  const setProjectAction = useIdeStore((s) => s.setProjectAction)
  const activeProjectId = useIdeStore((s) => s.activeProjectId)
  const projects = useIdeStore((s) => s.projects)
  const renameProject = useIdeStore((s) => s.renameProject)
  const duplicateProject = useIdeStore((s) => s.duplicateProject)
  const deleteProject = useIdeStore((s) => s.deleteProject)
  const importProject = useIdeStore((s) => s.importProject)
  const saveAll = useIdeStore((s) => s.saveAll)
  const settings = useIdeStore((s) => s.settings)
  const pushLog = useIdeStore((s) => s.pushLog)

  const [renameValue, setRenameValue] = useState('')
  const [importError, setImportError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const stored: StoredProject | undefined =
    activeProjectId !== null ? projects[activeProjectId] : undefined

  useEffect(() => {
    if (projectAction === 'rename' && stored !== undefined) setRenameValue(stored.config.name)
    if (projectAction !== 'import') setImportError(null)
  }, [projectAction, stored])

  const stats = useMemo(
    () => (projectAction === 'stats' && stored !== undefined ? computeStatistics(stored.tree) : null),
    [projectAction, stored],
  )

  const close = () => setProjectAction(null)

  if (projectAction === null) return null
  const meta = TITLES[projectAction]

  const handleRename = () => {
    if (activeProjectId === null || renameValue.trim().length === 0) return
    renameProject(activeProjectId, renameValue)
    pushLog('system', 'info', `Project renamed to "${renameValue.trim()}"`)
    close()
  }

  const handleDuplicate = () => {
    if (activeProjectId === null) return
    duplicateProject(activeProjectId)
    pushLog('system', 'success', 'Project duplicated')
    close()
  }

  const handleDelete = () => {
    if (activeProjectId === null) return
    deleteProject(activeProjectId)
    close()
  }

  const handleExport = () => {
    if (stored === undefined) return
    saveAll() // Flush drafts so the export contains the latest content.
    const current = useIdeStore.getState()
    const fresh = current.activeProjectId !== null ? current.projects[current.activeProjectId] : stored
    const payload = JSON.stringify(fresh, null, 2)
    const blob = new Blob([payload], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `${stored.config.name.toLowerCase().replace(/\s+/g, '-')}.sitara.json`
    anchor.click()
    URL.revokeObjectURL(url)
    pushLog('system', 'success', `Project exported: ${anchor.download}`)
    notify('export_finished', `${stored.config.name} exported as ${anchor.download}`, settings.notificationsEnabled)
    close()
  }

  const handleImportFile = async (file: File) => {
    try {
      const text = await file.text()
      const data = JSON.parse(text) as StoredProject
      const error = importProject(data)
      if (error !== null) {
        setImportError(error)
        return
      }
      pushLog('system', 'success', `Project imported: ${data.config.name}`)
      close()
    } catch {
      setImportError('Could not parse this file as a Sitara project export.')
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        key="project-action-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.15 }}
        className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        onClick={close}
        role="dialog"
        aria-modal="true"
        aria-label={meta.title}
      >
        <motion.div
          initial={{ opacity: 0, y: 16, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.97 }}
          transition={{ duration: 0.18 }}
          className="w-full max-w-md overflow-hidden rounded-xl border border-border bg-popover shadow-2xl shadow-black/50"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
            <h2 className="flex items-center gap-2 font-mono text-sm font-bold tracking-wide text-foreground">
              <meta.icon className="h-4 w-4 text-primary" aria-hidden="true" />
              {meta.title.toUpperCase()}
            </h2>
            <button
              type="button"
              onClick={close}
              aria-label="Close"
              className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          <div className="px-5 py-4">
            {projectAction === 'rename' && stored !== undefined ? (
              <div className="flex flex-col gap-3">
                <label htmlFor="rename-input" className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                  New project name
                </label>
                <input
                  id="rename-input"
                  type="text"
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      if (e.nativeEvent.isComposing || e.keyCode === 229) return
                      handleRename()
                    }
                  }}
                  className="rounded-lg border border-border bg-background px-3 py-2 font-mono text-sm text-foreground caret-primary outline-none focus:border-primary/60"
                />
                <button
                  type="button"
                  onClick={handleRename}
                  disabled={renameValue.trim().length === 0}
                  className="rounded-lg bg-primary px-4 py-2 font-mono text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
                >
                  Rename
                </button>
              </div>
            ) : null}

            {projectAction === 'duplicate' && stored !== undefined ? (
              <div className="flex flex-col gap-4">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Create a full copy of <span className="font-semibold text-foreground">{stored.config.name}</span>{' '}
                  including its entire virtual file tree. The copy appears on your dashboard.
                </p>
                <button
                  type="button"
                  onClick={handleDuplicate}
                  className="rounded-lg bg-primary px-4 py-2 font-mono text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  Duplicate Project
                </button>
              </div>
            ) : null}

            {projectAction === 'delete' && stored !== undefined ? (
              <div className="flex flex-col gap-4">
                <div className="flex items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-3">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    This permanently deletes{' '}
                    <span className="font-semibold text-foreground">{stored.config.name}</span> and all of its files
                    from the virtual workspace. This cannot be undone.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="rounded-lg bg-destructive px-4 py-2 font-mono text-xs font-semibold text-destructive-foreground transition-opacity hover:opacity-90"
                >
                  Delete Permanently
                </button>
              </div>
            ) : null}

            {projectAction === 'export' && stored !== undefined ? (
              <div className="flex flex-col gap-4">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Download <span className="font-semibold text-foreground">{stored.config.name}</span> as a portable
                  JSON archive containing the project config and full file tree. Unsaved changes are flushed first.
                </p>
                <button
                  type="button"
                  onClick={handleExport}
                  className="rounded-lg bg-primary px-4 py-2 font-mono text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  Export .sitara.json
                </button>
              </div>
            ) : null}

            {projectAction === 'import' ? (
              <div className="flex flex-col gap-4">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Restore a project from a <span className="font-mono text-foreground">.sitara.json</span> export. If a
                  project with the same id exists, the import gets a fresh id.
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/json,.json"
                  className="sr-only"
                  aria-label="Choose project file"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file !== undefined) void handleImportFile(file)
                  }}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-lg border border-dashed border-primary/50 bg-primary/5 px-4 py-6 font-mono text-xs text-primary transition-colors hover:bg-primary/10"
                >
                  Choose a project file…
                </button>
                {importError !== null ? (
                  <p className="flex items-center gap-2 font-mono text-[11px] text-destructive" role="alert">
                    <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
                    {importError}
                  </p>
                ) : null}
              </div>
            ) : null}

            {projectAction === 'stats' && stats !== null && stored !== undefined ? (
              <div className="flex flex-col gap-3">
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: 'Files', value: String(stats.totalFiles), icon: FileCode2 },
                    { label: 'Folders', value: String(stats.totalFolders), icon: FolderTree },
                    { label: 'Lines of code', value: stats.totalLines.toLocaleString(), icon: AlignLeft },
                    { label: 'Total size', value: formatBytes(stats.totalBytes), icon: HardDrive },
                  ].map((item) => (
                    <div key={item.label} className="rounded-lg border border-border bg-card px-3 py-2.5">
                      <p className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                        <item.icon className="h-3 w-3" aria-hidden="true" />
                        {item.label}
                      </p>
                      <p className="mt-1 font-mono text-lg font-bold text-primary">{item.value}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-lg border border-border bg-card px-3 py-2.5">
                  <p className="pb-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    Files by type
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(stats.byExtension)
                      .sort((a, b) => b[1] - a[1])
                      .map(([ext, count]) => (
                        <span
                          key={ext}
                          className="rounded-full border border-border bg-secondary px-2 py-0.5 font-mono text-[10px] text-foreground"
                        >
                          {ext} × {count}
                        </span>
                      ))}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
