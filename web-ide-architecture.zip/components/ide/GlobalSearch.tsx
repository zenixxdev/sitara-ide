'use client'

import { useState, useEffect, useMemo, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, FileCode2, CornerDownLeft, X } from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import type { SearchMatch } from '@/lib/types'

interface GroupedResults {
  filePath: string
  fileName: string
  matches: SearchMatch[]
}

export function GlobalSearch() {
  const searchOpen = useIdeStore((s) => s.searchOpen)
  const setSearchOpen = useIdeStore((s) => s.setSearchOpen)
  const searchProject = useIdeStore((s) => s.searchProject)
  const openFile = useIdeStore((s) => s.openFile)
  // Re-run search when the tree changes.
  const activeProjectId = useIdeStore((s) => s.activeProjectId)
  const projects = useIdeStore((s) => s.projects)

  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (searchOpen) {
      setQuery('')
      const t = setTimeout(() => inputRef.current?.focus(), 60)
      return () => clearTimeout(t)
    }
  }, [searchOpen])

  const tree = activeProjectId !== null ? projects[activeProjectId]?.tree : undefined

  const groups = useMemo<GroupedResults[]>(() => {
    if (query.trim().length < 2 || tree === undefined) return []
    const matches = searchProject(query.trim())
    const byFile = new Map<string, GroupedResults>()
    for (const m of matches) {
      let g = byFile.get(m.filePath)
      if (g === undefined) {
        g = { filePath: m.filePath, fileName: m.fileName, matches: [] }
        byFile.set(m.filePath, g)
      }
      g.matches.push(m)
    }
    return Array.from(byFile.values())
  }, [query, searchProject, tree])

  const totalMatches = groups.reduce((acc, g) => acc + g.matches.length, 0)

  const highlight = (line: string, q: string) => {
    const idx = line.toLowerCase().indexOf(q.toLowerCase())
    if (idx === -1) return <span>{line}</span>
    return (
      <span>
        {line.slice(0, idx)}
        <mark className="rounded-sm bg-primary/30 px-0.5 text-foreground">{line.slice(idx, idx + q.length)}</mark>
        {line.slice(idx + q.length)}
      </span>
    )
  }

  const openResult = (match: SearchMatch) => {
    openFile(match.filePath)
    setSearchOpen(false)
  }

  return (
    <AnimatePresence>
      {searchOpen ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-[80] flex items-start justify-center bg-black/60 p-4 pt-[10vh] backdrop-blur-sm"
          onClick={() => setSearchOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Global search"
        >
          <motion.div
            initial={{ opacity: 0, y: -16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.98 }}
            transition={{ duration: 0.18 }}
            className="flex max-h-[70vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-border bg-popover shadow-2xl shadow-black/50"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex shrink-0 items-center gap-2.5 border-b border-border px-4 py-3">
              <Search className="h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setSearchOpen(false)
                  if (e.key === 'Enter' && groups.length > 0) {
                    if (e.nativeEvent.isComposing || e.keyCode === 229) return
                    openResult(groups[0].matches[0])
                  }
                }}
                placeholder="Search across all project files…"
                spellCheck={false}
                aria-label="Search query"
                className="min-w-0 flex-1 bg-transparent font-mono text-sm text-foreground caret-primary outline-none placeholder:text-muted-foreground/50"
              />
              {query.trim().length >= 2 ? (
                <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                  {totalMatches} match{totalMatches === 1 ? '' : 'es'}
                </span>
              ) : null}
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                aria-label="Close search"
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-secondary hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto">
              {query.trim().length < 2 ? (
                <p className="px-4 py-6 text-center font-mono text-xs text-muted-foreground/60">
                  Type at least 2 characters to search the virtual filesystem.
                </p>
              ) : groups.length === 0 ? (
                <p className="px-4 py-6 text-center font-mono text-xs text-muted-foreground/60">
                  No results for &quot;{query}&quot;
                </p>
              ) : (
                groups.map((group) => (
                  <div key={group.filePath}>
                    <div className="sticky top-0 flex items-center gap-2 border-b border-border/50 bg-popover/95 px-4 py-1.5 backdrop-blur-sm">
                      <FileCode2 className="h-3.5 w-3.5 shrink-0 text-primary" aria-hidden="true" />
                      <span className="truncate font-mono text-xs font-semibold text-foreground">{group.fileName}</span>
                      <span className="truncate font-mono text-[10px] text-muted-foreground/60">{group.filePath}</span>
                      <span className="ml-auto shrink-0 rounded-full bg-secondary px-1.5 py-0.5 font-mono text-[9px] text-muted-foreground">
                        {group.matches.length}
                      </span>
                    </div>
                    {group.matches.map((m, i) => (
                      <button
                        key={`${m.filePath}-${m.line}-${i}`}
                        type="button"
                        onClick={() => openResult(m)}
                        className="flex w-full items-center gap-3 px-4 py-1.5 text-left hover:bg-secondary/60"
                      >
                        <span className="w-8 shrink-0 text-right font-mono text-[10px] text-muted-foreground/50">
                          {m.line}
                        </span>
                        <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-muted-foreground">
                          {highlight(m.lineText, query.trim())}
                        </span>
                        <CornerDownLeft className="h-3 w-3 shrink-0 text-muted-foreground/30" aria-hidden="true" />
                      </button>
                    ))}
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
