'use client'

import { AnimatePresence, motion } from 'framer-motion'
import { History, Pin, PinOff, X } from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'

export default function EditorTabs() {
  const tabs = useIdeStore((state) => state.tabs)
  const activePath = useIdeStore((state) => state.activePath)
  const recentFiles = useIdeStore((state) => state.recentFiles)
  const setActivePath = useIdeStore((state) => state.setActivePath)
  const closeTab = useIdeStore((state) => state.closeTab)
  const togglePin = useIdeStore((state) => state.togglePin)
  const openFile = useIdeStore((state) => state.openFile)

  // Recent files that aren't currently open as tabs.
  const recentClosed = recentFiles.filter((path) => !tabs.some((tab) => tab.path === path)).slice(0, 5)

  return (
    <div className="flex shrink-0 flex-col border-b border-border bg-background/80">
      {/* Recent files rail */}
      {recentClosed.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-border/60 px-2 py-1">
          <History className="size-3 shrink-0 text-muted-foreground/60" aria-hidden="true" />
          <span className="shrink-0 font-mono text-[10px] uppercase tracking-wider text-muted-foreground/60">
            Recent
          </span>
          {recentClosed.map((path) => (
            <button
              key={path}
              type="button"
              onClick={() => openFile(path)}
              className="shrink-0 rounded-md bg-secondary/60 px-2 py-0.5 font-mono text-[10px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {path.split('/').pop()}
            </button>
          ))}
        </div>
      )}

      {/* Tab strip */}
      <div role="tablist" aria-label="Open files" className="flex items-end gap-0.5 overflow-x-auto px-1 pt-1">
        <AnimatePresence initial={false}>
          {tabs.map((tab) => {
            const isActive = tab.path === activePath
            return (
              <motion.div
                key={tab.path}
                layout
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, width: 0 }}
                transition={{ duration: 0.15 }}
                className={`group flex shrink-0 items-center rounded-t-md border border-b-0 ${
                  isActive ? 'border-border bg-card' : 'border-transparent bg-transparent hover:bg-secondary/60'
                }`}
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  title={tab.path}
                  onClick={() => setActivePath(tab.path)}
                  className={`flex items-center gap-1.5 py-1.5 pl-3 pr-1 font-mono text-xs ${
                    isActive ? 'text-foreground' : 'text-muted-foreground'
                  }`}
                >
                  {tab.pinned && <Pin className="size-3 text-primary" aria-label="Pinned" />}
                  {tab.dirty && (
                    <span className="size-1.5 rounded-full bg-accent" aria-label="Unsaved changes" />
                  )}
                  <span className="max-w-40 truncate">{tab.name}</span>
                </button>
                <button
                  type="button"
                  onClick={() => togglePin(tab.path)}
                  aria-label={tab.pinned ? `Unpin ${tab.name}` : `Pin ${tab.name}`}
                  className="rounded p-0.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100"
                >
                  {tab.pinned ? (
                    <PinOff className="size-3" aria-hidden="true" />
                  ) : (
                    <Pin className="size-3" aria-hidden="true" />
                  )}
                </button>
                {!tab.pinned && (
                  <button
                    type="button"
                    onClick={() => closeTab(tab.path)}
                    aria-label={`Close ${tab.name}`}
                    className="mr-1 rounded p-0.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100"
                  >
                    <X className="size-3" aria-hidden="true" />
                  </button>
                )}
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </div>
  )
}
