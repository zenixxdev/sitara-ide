'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { PanelLeftClose } from 'lucide-react'
import { useIdeStore } from '@/lib/ideStore'
import { dispatchEditorCommand } from '@/lib/editorBus'
import { TopBar } from '@/components/ide/TopBar'
import FileExplorer from '@/components/ide/FileExplorer'
import EditorTabs from '@/components/ide/EditorTabs'
import CodeEditor from '@/components/ide/CodeEditor'
import { BottomPanel } from '@/components/ide/BottomPanel'
import { StatusBar } from '@/components/ide/StatusBar'
import { GlobalSearch } from '@/components/ide/GlobalSearch'
import { SettingsModal } from '@/components/ide/SettingsModal'
import { ProjectActionsModal } from '@/components/ide/ProjectActionsModal'

const MIN_SIDEBAR_W = 180
const MAX_SIDEBAR_W = 420
const MIN_PANEL_H = 120
const MAX_PANEL_H_RATIO = 0.7

/**
 * The full IDE shell. All state lives in the unified zustand store;
 * this component only wires layout, drag-resizing, and keyboard shortcuts.
 */
export default function IdeWorkspace() {
  const sidebarOpen = useIdeStore((s) => s.sidebarOpen)
  const bottomPanelOpen = useIdeStore((s) => s.bottomPanelOpen)
  const toggleSidebar = useIdeStore((s) => s.toggleSidebar)
  const setBottomPanel = useIdeStore((s) => s.setBottomPanel)
  const setSearchOpen = useIdeStore((s) => s.setSearchOpen)
  const setSettingsOpen = useIdeStore((s) => s.setSettingsOpen)
  const saveFile = useIdeStore((s) => s.saveFile)
  const saveAll = useIdeStore((s) => s.saveAll)
  const startBuild = useIdeStore((s) => s.startBuild)
  const activePath = useIdeStore((s) => s.activePath)
  const buildStatus = useIdeStore((s) => s.buildProgress.status)

  const [sidebarWidth, setSidebarWidth] = useState<number>(248)
  const [panelHeight, setPanelHeight] = useState<number>(224)
  const shellRef = useRef<HTMLDivElement>(null)
  const dragRef = useRef<{ kind: 'sidebar' | 'panel'; startPos: number; startSize: number } | null>(null)

  /* ---------------- drag resizing ---------------- */

  const beginDrag = useCallback(
    (kind: 'sidebar' | 'panel') => (event: React.PointerEvent<HTMLDivElement>) => {
      event.preventDefault()
      dragRef.current = {
        kind,
        startPos: kind === 'sidebar' ? event.clientX : event.clientY,
        startSize: kind === 'sidebar' ? sidebarWidth : panelHeight,
      }
      const onMove = (e: PointerEvent) => {
        const drag = dragRef.current
        if (drag === null) return
        if (drag.kind === 'sidebar') {
          const next = drag.startSize + (e.clientX - drag.startPos)
          setSidebarWidth(Math.min(MAX_SIDEBAR_W, Math.max(MIN_SIDEBAR_W, next)))
        } else {
          const shellH = shellRef.current?.clientHeight ?? 800
          const next = drag.startSize - (e.clientY - drag.startPos)
          setPanelHeight(Math.min(shellH * MAX_PANEL_H_RATIO, Math.max(MIN_PANEL_H, next)))
        }
      }
      const onUp = () => {
        dragRef.current = null
        window.removeEventListener('pointermove', onMove)
        window.removeEventListener('pointerup', onUp)
      }
      window.addEventListener('pointermove', onMove)
      window.addEventListener('pointerup', onUp)
    },
    [sidebarWidth, panelHeight],
  )

  /* ---------------- keyboard shortcuts ---------------- */

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const mod = event.ctrlKey || event.metaKey
      if (!mod) return
      const key = event.key.toLowerCase()

      if (key === 's') {
        event.preventDefault()
        if (event.shiftKey) saveAll()
        else if (activePath !== null) saveFile(activePath)
      } else if (key === 'f' && !event.shiftKey) {
        // Let CodeMirror handle Ctrl+F when the editor has focus.
        const active = document.activeElement
        if (active === null || active.closest('.cm-editor') === null) {
          event.preventDefault()
          dispatchEditorCommand('find')
        }
      } else if (key === 'h') {
        event.preventDefault()
        dispatchEditorCommand('replace')
      } else if (key === 'p' && event.shiftKey) {
        event.preventDefault()
        setSearchOpen(true)
      } else if (key === ',') {
        event.preventDefault()
        setSettingsOpen(true)
      } else if (key === 'b' && !event.shiftKey) {
        event.preventDefault()
        toggleSidebar()
      } else if (key === 'j') {
        event.preventDefault()
        setBottomPanel(!bottomPanelOpen)
      } else if (key === 'g' && event.shiftKey) {
        event.preventDefault()
        dispatchEditorCommand('gotoLine')
      } else if (key === 'enter' && event.shiftKey && buildStatus !== 'running') {
        event.preventDefault()
        startBuild('build')
      }
      // Ctrl+Z / Ctrl+Y / Ctrl+/ are handled natively by CodeMirror keymaps.
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [
    activePath,
    bottomPanelOpen,
    buildStatus,
    saveAll,
    saveFile,
    setBottomPanel,
    setSearchOpen,
    setSettingsOpen,
    startBuild,
    toggleSidebar,
  ])

  return (
    <motion.main
      initial={{ opacity: 0, scale: 0.995 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="flex h-dvh flex-col overflow-hidden bg-background"
    >
      <TopBar />

      <div ref={shellRef} className="flex min-h-0 flex-1">
        {/* Sidebar */}
        <AnimatePresence initial={false}>
          {sidebarOpen && (
            <motion.aside
              key="sidebar"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: sidebarWidth, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: 'easeInOut' }}
              className="relative shrink-0 overflow-hidden border-r border-border bg-card/40 backdrop-blur-sm max-md:absolute max-md:inset-y-0 max-md:left-0 max-md:z-30 max-md:h-full max-md:border-r max-md:bg-card"
              style={{ width: sidebarWidth }}
            >
              <div className="flex h-full flex-col" style={{ width: sidebarWidth }}>
                <div className="flex items-center justify-between border-b border-border px-3 py-2 md:hidden">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    Explorer
                  </span>
                  <button
                    type="button"
                    onClick={toggleSidebar}
                    aria-label="Close explorer"
                    className="rounded-md p-1 text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    <PanelLeftClose className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
                <div className="min-h-0 flex-1">
                  <FileExplorer />
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Sidebar resize handle (desktop) */}
        {sidebarOpen && (
          <div
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize explorer"
            onPointerDown={beginDrag('sidebar')}
            className="hidden w-1 shrink-0 cursor-col-resize bg-transparent transition-colors hover:bg-primary/40 active:bg-primary/60 md:block"
          />
        )}

        {/* Editor column */}
        <div className="flex min-w-0 flex-1 flex-col">
          <EditorTabs />
          <div className="min-h-0 flex-1">
            <CodeEditor />
          </div>

          {/* Bottom panel resize handle */}
          {bottomPanelOpen && (
            <div
              role="separator"
              aria-orientation="horizontal"
              aria-label="Resize bottom panel"
              onPointerDown={beginDrag('panel')}
              className="h-1 shrink-0 cursor-row-resize bg-transparent transition-colors hover:bg-primary/40 active:bg-primary/60"
            />
          )}

          <AnimatePresence initial={false}>
            {bottomPanelOpen && (
              <motion.div
                key="bottom-panel"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: panelHeight, opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="shrink-0 overflow-hidden border-t border-border"
              >
                <div style={{ height: panelHeight }}>
                  <BottomPanel />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <StatusBar />

      {/* Overlays */}
      <GlobalSearch />
      <SettingsModal />
      <ProjectActionsModal />
    </motion.main>
  )
}
