'use client'

import { motion } from 'framer-motion'
import { Clock, Cpu, FolderGit2, Plus, Smartphone, Star } from 'lucide-react'
import type { StoredProject, TemplateType } from '@/lib/types'

interface DashboardProps {
  projects: StoredProject[]
  onNewProject: () => void
  onOpenProject: (id: string) => void
  onToggleFavorite: (id: string) => void
}

const TEMPLATE_LABELS: Record<TemplateType, string> = {
  blank: 'Blank Project',
  empty_activity: 'Empty Activity',
  bottom_nav: 'Bottom Navigation',
  login_activity: 'Login Activity',
}

const LOGO_GRADIENTS: string[] = [
  'from-blue-500 to-cyan-400',
  'from-emerald-500 to-lime-400',
  'from-orange-500 to-amber-400',
  'from-fuchsia-500 to-pink-400',
  'from-sky-500 to-indigo-400',
]

/** Formats an ISO timestamp into a human-readable relative time string. */
function formatRelativeTime(isoDate: string): string {
  const then = new Date(isoDate).getTime()
  const now = Date.now()
  const diffSeconds = Math.max(0, Math.floor((now - then) / 1000))

  if (diffSeconds < 60) return 'just now'
  const diffMinutes = Math.floor(diffSeconds / 60)
  if (diffMinutes < 60) return `${diffMinutes} min${diffMinutes === 1 ? '' : 's'} ago`
  const diffHours = Math.floor(diffMinutes / 60)
  if (diffHours < 24) return `${diffHours} hour${diffHours === 1 ? '' : 's'} ago`
  const diffDays = Math.floor(diffHours / 24)
  if (diffDays < 30) return `${diffDays} day${diffDays === 1 ? '' : 's'} ago`
  const diffMonths = Math.floor(diffDays / 30)
  return `${diffMonths} month${diffMonths === 1 ? '' : 's'} ago`
}

/** Derives 1-2 letter initials from a project name for the logo badge. */
function projectInitials(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean)
  if (words.length === 0) return 'AP'
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase()
  return (words[0][0] + words[1][0]).toUpperCase()
}

interface ProjectCardProps {
  stored: StoredProject
  index: number
  onOpen: (id: string) => void
  onToggleFavorite: (id: string) => void
}

function ProjectCard({ stored, index, onOpen, onToggleFavorite }: ProjectCardProps) {
  const project = stored.config
  const gradient = LOGO_GRADIENTS[index % LOGO_GRADIENTS.length]
  const languageLabel = project.language === 'kotlin' ? 'Kotlin' : 'Java'

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.06 }}
      whileHover={{ y: -4 }}
      className="group relative flex flex-col rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/50"
    >
      <button
        type="button"
        onClick={() => onOpen(project.id)}
        className="absolute inset-0 z-0 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
        aria-label={`Open project ${project.name}`}
      />
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation()
          onToggleFavorite(project.id)
        }}
        aria-label={stored.favorite ? `Unfavorite ${project.name}` : `Favorite ${project.name}`}
        aria-pressed={stored.favorite}
        className="absolute right-3 top-3 z-10 rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <Star
          className={`size-4 ${stored.favorite ? 'fill-accent text-accent' : ''}`}
          aria-hidden="true"
        />
      </button>

      <div className="pointer-events-none flex items-start gap-4">
        <div
          className={`flex size-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-sm font-bold text-white shadow-lg`}
          aria-hidden="true"
        >
          {projectInitials(project.name)}
        </div>
        <div className="min-w-0 pr-8">
          <h3 className="truncate text-base font-semibold text-foreground">{project.name}</h3>
          <p className="truncate font-mono text-xs text-muted-foreground">{project.packageName}</p>
        </div>
      </div>

      <div className="pointer-events-none mt-4 flex flex-wrap gap-2">
        <span
          className={`rounded-md px-2 py-1 font-mono text-xs font-medium ${
            project.language === 'kotlin' ? 'bg-violet-500/15 text-violet-300' : 'bg-orange-500/15 text-orange-300'
          }`}
        >
          {languageLabel}
        </span>
        <span className="rounded-md bg-primary/15 px-2 py-1 font-mono text-xs font-medium text-primary">
          SDK {project.minSdk}
        </span>
        <span className="rounded-md bg-accent/15 px-2 py-1 font-mono text-xs font-medium text-accent">
          {TEMPLATE_LABELS[project.template]}
        </span>
      </div>

      <div className="pointer-events-none mt-4 flex items-center gap-1.5 border-t border-border pt-3 text-xs text-muted-foreground">
        <Clock className="size-3.5" aria-hidden="true" />
        <span>Last opened {formatRelativeTime(stored.lastOpenedAt)}</span>
      </div>
    </motion.article>
  )
}

export default function Dashboard({ projects, onNewProject, onOpenProject, onToggleFavorite }: DashboardProps) {
  const sorted = [...projects].sort((a, b) => {
    if (a.favorite !== b.favorite) return a.favorite ? -1 : 1
    return new Date(b.lastOpenedAt).getTime() - new Date(a.lastOpenedAt).getTime()
  })

  return (
    <main className="min-h-dvh bg-background">
      {/* Top bar */}
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-4 sm:px-6">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <Cpu className="size-5" aria-hidden="true" />
          </div>
          <div>
            <p className="font-mono text-sm font-bold tracking-wider text-foreground">SITARA</p>
            <p className="text-xs text-muted-foreground">Web Android IDE</p>
          </div>
          <div className="ml-auto flex items-center gap-2 rounded-full border border-border px-3 py-1.5">
            <span className="size-2 rounded-full bg-accent" aria-hidden="true" />
            <span className="font-mono text-xs text-muted-foreground">Sandbox ready</span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        {/* Hero: New Project */}
        <motion.button
          type="button"
          onClick={onNewProject}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          className="group relative flex w-full flex-col items-center justify-center gap-4 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 px-6 py-14 transition-colors hover:border-primary/70 hover:bg-primary/10 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring"
        >
          {/* Glow halo */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 shadow-[0_0_80px_-12px_var(--color-primary)] transition-opacity duration-500 group-hover:opacity-60"
          />
          <motion.div
            animate={{ scale: [1, 1.08, 1] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
            className="flex size-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-xl shadow-primary/30"
          >
            <Plus className="size-10 text-primary-foreground" aria-hidden="true" />
          </motion.div>
          <div className="text-center">
            <p className="text-xl font-bold text-foreground">New Project</p>
            <p className="mt-1 text-sm text-muted-foreground">Bootstrap a new Android Application instantly</p>
          </div>
        </motion.button>

        {/* Recent projects */}
        <section className="mt-12" aria-label="Recent projects">
          <div className="flex items-center gap-2">
            <FolderGit2 className="size-5 text-primary" aria-hidden="true" />
            <h2 className="text-lg font-semibold text-foreground">Recent Projects</h2>
            <span className="ml-1 rounded-full bg-muted px-2 py-0.5 font-mono text-xs text-muted-foreground">
              {projects.length}
            </span>
          </div>

          {projects.length === 0 ? (
            <div className="mt-6 flex flex-col items-center gap-3 rounded-xl border border-border bg-card p-10 text-center">
              <Smartphone className="size-8 text-muted-foreground" aria-hidden="true" />
              <p className="text-sm text-muted-foreground">
                No projects yet. Hit &quot;New Project&quot; above to bootstrap your first app.
              </p>
            </div>
          ) : (
            <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {sorted.map((stored, index) => (
                <ProjectCard
                  key={stored.config.id}
                  stored={stored}
                  index={index}
                  onOpen={onOpenProject}
                  onToggleFavorite={onToggleFavorite}
                />
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  )
}
