'use client'

import { useCallback, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  Coffee,
  FileCode2,
  Layers,
  LayoutTemplate,
  LockKeyhole,
  Package,
  Rocket,
  Square,
  UploadCloud,
  X,
  Zap,
} from 'lucide-react'
import { SDK_OPTIONS, type Language, type ProjectConfig, type TemplateType } from '@/lib/types'

interface NewProjectModalProps {
  open: boolean
  onClose: () => void
  onCreate: (config: ProjectConfig) => void
}

type ModalScreen = 'config' | 'template'

const PRESET_LOGOS: { id: string; label: string; gradient: string }[] = [
  { id: 'preset-azure', label: 'Azure Pulse', gradient: 'from-blue-500 to-cyan-400' },
  { id: 'preset-mint', label: 'Mint Circuit', gradient: 'from-emerald-500 to-lime-400' },
  { id: 'preset-ember', label: 'Ember Core', gradient: 'from-orange-500 to-amber-400' },
  { id: 'preset-nova', label: 'Nova Bloom', gradient: 'from-fuchsia-500 to-pink-400' },
  { id: 'preset-void', label: 'Void Drift', gradient: 'from-sky-500 to-indigo-400' },
]

interface TemplateOption {
  value: TemplateType
  title: string
  summary: string
  details: string[]
  icon: typeof Square
}

const TEMPLATE_OPTIONS: TemplateOption[] = [
  {
    value: 'blank',
    title: 'Blank Project',
    summary: 'Absolute skeleton code with a single main directory.',
    details: ['Manifest + root Gradle only', 'No activities preconfigured', 'Full manual control'],
    icon: Square,
  },
  {
    value: 'empty_activity',
    title: 'Empty Activity',
    summary: 'Standard MainActivity with a single blank view file.',
    details: ['MainActivity boilerplate', 'activity_main.xml layout', 'AppCompat theme wired'],
    icon: FileCode2,
  },
  {
    value: 'bottom_nav',
    title: 'Bottom Navigation App',
    summary: 'Multi-fragment boilerplate with a bottom bar layout preset.',
    details: ['3 fragment destinations', 'BottomNavigationView preset', 'Navigation graph stub'],
    icon: Layers,
  },
  {
    value: 'login_activity',
    title: 'Login Activity App',
    summary: 'Auth activity class with validation and biometric layouts.',
    details: ['Input validation layouts', 'LoginActivity class', 'Biometric prompt template'],
    icon: LockKeyhole,
  },
]

const PROJECT_NAME_REGEX = /^[A-Za-z][A-Za-z0-9 ]*$/
const PACKAGE_NAME_REGEX = /^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$/

/** Capitalizes the first character of the given string. */
function capitalizeFirst(value: string): string {
  if (value.length === 0) return value
  return value.charAt(0).toUpperCase() + value.slice(1)
}

/** Derives a package suffix from a project name (lowercase, alphanumeric only). */
function packageSuffixFromName(name: string): string {
  const cleaned = name.toLowerCase().replace(/[^a-z0-9]/g, '')
  return cleaned.length > 0 ? cleaned : 'app'
}

export default function NewProjectModal({ open, onClose, onCreate }: NewProjectModalProps) {
  const [screen, setScreen] = useState<ModalScreen>('config')
  const [projectName, setProjectName] = useState<string>('')
  const [packageName, setPackageName] = useState<string>('com.sitara.app')
  const [packageManuallyEdited, setPackageManuallyEdited] = useState<boolean>(false)
  const [minSdk, setMinSdk] = useState<string>('24')
  const [sdkMenuOpen, setSdkMenuOpen] = useState<boolean>(false)
  const [selectedLogo, setSelectedLogo] = useState<string | null>(null)
  const [dragActive, setDragActive] = useState<boolean>(false)
  const [language, setLanguage] = useState<Language>('kotlin')
  const [template, setTemplate] = useState<TemplateType>('empty_activity')
  const [creating, setCreating] = useState<boolean>(false)

  const nameError: string | null = useMemo(() => {
    if (projectName.length === 0) return 'Project name is required.'
    if (!PROJECT_NAME_REGEX.test(projectName)) {
      return 'Only letters, numbers and spaces allowed. Must start with a letter.'
    }
    return null
  }, [projectName])

  const packageError: string | null = useMemo(() => {
    if (packageName.length === 0) return 'Package name is required.'
    if (!PACKAGE_NAME_REGEX.test(packageName)) {
      return 'Must be reverse-domain format, e.g. com.domain.app (lowercase, dot-separated).'
    }
    return null
  }, [packageName])

  const configValid: boolean = nameError === null && packageError === null

  const selectedSdk = SDK_OPTIONS.find((option) => option.value === minSdk) ?? SDK_OPTIONS[1]

  const handleNameChange = useCallback(
    (raw: string) => {
      const next = capitalizeFirst(raw)
      setProjectName(next)
      if (!packageManuallyEdited) {
        setPackageName(`com.sitara.${packageSuffixFromName(next)}`)
      }
    },
    [packageManuallyEdited],
  )

  const handlePackageChange = useCallback((raw: string) => {
    setPackageManuallyEdited(true)
    setPackageName(raw.toLowerCase().replace(/\s/g, ''))
  }, [])

  const resetAndClose = useCallback(() => {
    setScreen('config')
    setProjectName('')
    setPackageName('com.sitara.app')
    setPackageManuallyEdited(false)
    setMinSdk('24')
    setSdkMenuOpen(false)
    setSelectedLogo(null)
    setDragActive(false)
    setLanguage('kotlin')
    setTemplate('empty_activity')
    setCreating(false)
    onClose()
  }, [onClose])

  const handleCreate = useCallback(() => {
    if (!configValid || creating) return
    setCreating(true)
    const config: ProjectConfig = {
      id: `proj_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
      name: projectName.trim(),
      packageName,
      minSdk,
      logoUrl: selectedLogo,
      language,
      template,
      createdAt: new Date().toISOString(),
    }
    // Simulated project provisioning delay for the loading micro-interaction.
    window.setTimeout(() => {
      onCreate(config)
      setCreating(false)
      setScreen('config')
      setProjectName('')
      setPackageName('com.sitara.app')
      setPackageManuallyEdited(false)
      setSelectedLogo(null)
      setLanguage('kotlin')
      setTemplate('empty_activity')
    }, 700)
  }, [configValid, creating, projectName, packageName, minSdk, selectedLogo, language, template, onCreate])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="New project configuration"
          onClick={(event) => {
            if (event.target === event.currentTarget && !creating) resetAndClose()
          }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 16 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="flex max-h-[90dvh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl shadow-primary/10"
          >
            {/* Modal header */}
            <div className="flex items-center gap-3 border-b border-border px-6 py-4">
              <div className="flex size-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
                {screen === 'config' ? (
                  <Package className="size-5" aria-hidden="true" />
                ) : (
                  <LayoutTemplate className="size-5" aria-hidden="true" />
                )}
              </div>
              <div>
                <h2 className="text-base font-semibold text-foreground">
                  {screen === 'config' ? 'App Configurations' : 'Template Selection'}
                </h2>
                <p className="font-mono text-xs text-muted-foreground">
                  {screen === 'config' ? 'Screen A / 2' : 'Screen B / 2'}
                </p>
              </div>
              <button
                type="button"
                onClick={resetAndClose}
                disabled={creating}
                aria-label="Close modal"
                className="ml-auto flex size-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-40"
              >
                <X className="size-4" aria-hidden="true" />
              </button>
            </div>

            {/* Modal body */}
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <AnimatePresence mode="wait">
                {screen === 'config' && (
                  <motion.div
                    key="screen-config"
                    initial={{ opacity: 0, x: -24 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -24 }}
                    transition={{ duration: 0.22 }}
                    className="flex flex-col gap-6"
                  >
                    {/* Project name */}
                    <div>
                      <label htmlFor="project-name" className="text-sm font-semibold text-foreground">
                        Project Name
                      </label>
                      <input
                        id="project-name"
                        type="text"
                        value={projectName}
                        onChange={(event) => handleNameChange(event.target.value)}
                        placeholder="My Awesome App"
                        aria-invalid={projectName.length > 0 && nameError !== null}
                        className={`mt-2 w-full rounded-lg border bg-secondary/40 px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-2 focus:outline-offset-1 focus:outline-ring ${
                          projectName.length > 0 && nameError !== null ? 'border-destructive' : 'border-border'
                        }`}
                      />
                      {projectName.length > 0 && nameError !== null && (
                        <p className="mt-1.5 text-xs text-destructive">{nameError}</p>
                      )}
                    </div>

                    {/* Package name */}
                    <div>
                      <label htmlFor="package-name" className="text-sm font-semibold text-foreground">
                        Package Name
                      </label>
                      <input
                        id="package-name"
                        type="text"
                        value={packageName}
                        onChange={(event) => handlePackageChange(event.target.value)}
                        placeholder="com.domain.app"
                        aria-invalid={packageError !== null}
                        className={`mt-2 w-full rounded-lg border bg-secondary/40 px-4 py-2.5 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-2 focus:outline-offset-1 focus:outline-ring ${
                          packageError !== null ? 'border-destructive' : 'border-border'
                        }`}
                      />
                      {packageError !== null ? (
                        <p className="mt-1.5 text-xs text-destructive">{packageError}</p>
                      ) : (
                        <p className="mt-1.5 text-xs text-muted-foreground">
                          {packageManuallyEdited ? 'Manually edited.' : 'Auto-synced from project name.'}
                        </p>
                      )}
                    </div>

                    {/* Min SDK dropdown */}
                    <div className="relative">
                      <span id="min-sdk-label" className="text-sm font-semibold text-foreground">
                        Minimum SDK
                      </span>
                      <button
                        type="button"
                        aria-labelledby="min-sdk-label"
                        aria-expanded={sdkMenuOpen}
                        aria-haspopup="listbox"
                        onClick={() => setSdkMenuOpen((prev) => !prev)}
                        className="mt-2 flex w-full items-center justify-between rounded-lg border border-border bg-secondary/40 px-4 py-2.5 text-sm text-foreground transition-colors hover:border-primary/50 focus:outline-2 focus:outline-offset-1 focus:outline-ring"
                      >
                        <span>
                          <span className="font-mono font-semibold">{selectedSdk.label}</span>
                          <span className="ml-2 text-muted-foreground">{selectedSdk.codename}</span>
                        </span>
                        <ChevronDown
                          className={`size-4 text-muted-foreground transition-transform ${sdkMenuOpen ? 'rotate-180' : ''}`}
                          aria-hidden="true"
                        />
                      </button>
                      <AnimatePresence>
                        {sdkMenuOpen && (
                          <motion.ul
                            initial={{ opacity: 0, y: -6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -6 }}
                            transition={{ duration: 0.16 }}
                            role="listbox"
                            aria-labelledby="min-sdk-label"
                            className="absolute z-20 mt-2 w-full overflow-hidden rounded-lg border border-border bg-popover shadow-xl"
                          >
                            {SDK_OPTIONS.map((option) => (
                              <li key={option.value} role="option" aria-selected={option.value === minSdk}>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMinSdk(option.value)
                                    setSdkMenuOpen(false)
                                  }}
                                  className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-sm transition-colors hover:bg-primary/10 ${
                                    option.value === minSdk ? 'bg-primary/15 text-primary' : 'text-foreground'
                                  }`}
                                >
                                  <span>
                                    <span className="font-mono font-semibold">{option.label}</span>
                                    <span className="ml-2 text-muted-foreground">{option.codename}</span>
                                  </span>
                                  {option.value === minSdk && <Check className="size-4" aria-hidden="true" />}
                                </button>
                              </li>
                            ))}
                          </motion.ul>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Logo picker */}
                    <div>
                      <span className="text-sm font-semibold text-foreground">App Logo</span>
                      <div
                        onDragOver={(event) => {
                          event.preventDefault()
                          setDragActive(true)
                        }}
                        onDragLeave={() => setDragActive(false)}
                        onDrop={(event) => {
                          event.preventDefault()
                          setDragActive(false)
                          // Simulated drop: virtual builds use preset icons; select the first preset.
                          setSelectedLogo(PRESET_LOGOS[0].id)
                        }}
                        className={`mt-2 flex flex-col items-center gap-2 rounded-lg border-2 border-dashed px-4 py-6 text-center transition-colors ${
                          dragActive ? 'border-primary bg-primary/10' : 'border-border bg-secondary/30'
                        }`}
                      >
                        <UploadCloud className="size-6 text-muted-foreground" aria-hidden="true" />
                        <p className="text-xs text-muted-foreground">
                          Drag &amp; drop a logo here, or pick a preset icon below
                        </p>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-3" role="radiogroup" aria-label="Preset app icons">
                        {PRESET_LOGOS.map((logo) => (
                          <motion.button
                            key={logo.id}
                            type="button"
                            role="radio"
                            aria-checked={selectedLogo === logo.id}
                            aria-label={logo.label}
                            whileHover={{ scale: 1.08 }}
                            whileTap={{ scale: 0.94 }}
                            onClick={() => setSelectedLogo(selectedLogo === logo.id ? null : logo.id)}
                            className={`relative flex size-12 items-center justify-center rounded-xl bg-gradient-to-br ${logo.gradient} shadow-lg transition-shadow ${
                              selectedLogo === logo.id ? 'ring-2 ring-ring ring-offset-2 ring-offset-card' : ''
                            }`}
                          >
                            {selectedLogo === logo.id && (
                              <span className="flex size-5 items-center justify-center rounded-full bg-card">
                                <Check className="size-3 text-accent" aria-hidden="true" />
                              </span>
                            )}
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    {/* Language selector */}
                    <div>
                      <span className="text-sm font-semibold text-foreground">Language</span>
                      <div className="mt-2 grid grid-cols-2 gap-3" role="radiogroup" aria-label="Project language">
                        <motion.button
                          type="button"
                          role="radio"
                          aria-checked={language === 'java'}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setLanguage('java')}
                          className={`flex items-center gap-3 rounded-xl border-2 p-4 transition-all ${
                            language === 'java'
                              ? 'border-orange-500 bg-orange-500/10 shadow-lg shadow-orange-500/20'
                              : 'border-border bg-secondary/40 hover:border-orange-500/40'
                          }`}
                        >
                          <Coffee
                            className={`size-6 ${language === 'java' ? 'text-orange-400' : 'text-muted-foreground'}`}
                            aria-hidden="true"
                          />
                          <div className="text-left">
                            <p className="text-sm font-bold text-foreground">Java</p>
                            <p className="font-mono text-xs text-muted-foreground">.java sources</p>
                          </div>
                        </motion.button>
                        <motion.button
                          type="button"
                          role="radio"
                          aria-checked={language === 'kotlin'}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setLanguage('kotlin')}
                          className={`flex items-center gap-3 rounded-xl border-2 p-4 transition-all ${
                            language === 'kotlin'
                              ? 'border-violet-500 bg-violet-500/10 shadow-lg shadow-violet-500/20'
                              : 'border-border bg-secondary/40 hover:border-violet-500/40'
                          }`}
                        >
                          <Zap
                            className={`size-6 ${language === 'kotlin' ? 'text-violet-400' : 'text-muted-foreground'}`}
                            aria-hidden="true"
                          />
                          <div className="text-left">
                            <p className="text-sm font-bold text-foreground">Kotlin</p>
                            <p className="font-mono text-xs text-muted-foreground">.kt sources</p>
                          </div>
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                )}

                {screen === 'template' && (
                  <motion.div
                    key="screen-template"
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 24 }}
                    transition={{ duration: 0.22 }}
                    className="grid grid-cols-1 gap-4 sm:grid-cols-2"
                    role="radiogroup"
                    aria-label="Project template"
                  >
                    {TEMPLATE_OPTIONS.map((option) => (
                      <motion.button
                        key={option.value}
                        type="button"
                        role="radio"
                        aria-checked={template === option.value}
                        whileHover={{ y: -3 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setTemplate(option.value)}
                        className={`flex flex-col rounded-xl border-2 p-5 text-left transition-colors ${
                          template === option.value
                            ? 'border-primary bg-primary/10'
                            : 'border-border bg-secondary/40 hover:border-primary/40'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`flex size-10 items-center justify-center rounded-lg ${
                              template === option.value ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
                            }`}
                          >
                            <option.icon className="size-5" aria-hidden="true" />
                          </div>
                          <p className="text-sm font-bold text-foreground">{option.title}</p>
                          {template === option.value && (
                            <Check className="ml-auto size-4 text-primary" aria-hidden="true" />
                          )}
                        </div>
                        <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{option.summary}</p>
                        <ul className="mt-3 flex flex-col gap-1.5 border-t border-border pt-3">
                          {option.details.map((detail) => (
                            <li key={detail} className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
                              <span
                                className={`size-1.5 rounded-full ${template === option.value ? 'bg-accent' : 'bg-muted-foreground'}`}
                                aria-hidden="true"
                              />
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Modal footer */}
            <div className="flex items-center justify-between border-t border-border px-6 py-4">
              {screen === 'template' ? (
                <motion.button
                  type="button"
                  whileHover={{ scale: creating ? 1 : 1.04 }}
                  whileTap={{ scale: creating ? 1 : 0.96 }}
                  onClick={() => setScreen('config')}
                  disabled={creating}
                  className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
                >
                  <ArrowLeft className="size-4" aria-hidden="true" />
                  Configurations
                </motion.button>
              ) : (
                <span className="text-xs text-muted-foreground">
                  {configValid ? 'Configuration valid.' : 'Complete required fields to continue.'}
                </span>
              )}

              {screen === 'config' ? (
                <motion.button
                  type="button"
                  whileHover={{ scale: configValid ? 1.04 : 1 }}
                  whileTap={{ scale: configValid ? 0.96 : 1 }}
                  onClick={() => configValid && setScreen('template')}
                  disabled={!configValid}
                  className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Choose Template
                  <ArrowRight className="size-4" aria-hidden="true" />
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileHover={{ scale: creating ? 1 : 1.04 }}
                  whileTap={{ scale: creating ? 1 : 0.96 }}
                  onClick={handleCreate}
                  disabled={creating}
                  className="flex min-w-40 items-center justify-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 disabled:opacity-60"
                >
                  {creating ? (
                    <>
                      <motion.span
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        className="size-4 rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground"
                        aria-hidden="true"
                      />
                      Generating
                    </>
                  ) : (
                    <>
                      Create Project
                      <Rocket className="size-4" aria-hidden="true" />
                    </>
                  )}
                </motion.button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
