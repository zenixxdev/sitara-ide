'use client'

import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CheckCircle2 } from 'lucide-react'
import Dashboard from '@/components/Dashboard'
import IdeWorkspace from '@/components/ide/IdeWorkspace'
import NewProjectModal from '@/components/NewProjectModal'
import OnboardingWizard from '@/components/OnboardingWizard'
import { countFiles, generateAndroidBoilerplate } from '@/lib/boilerplateEngine'
import { useIdeStore } from '@/lib/ideStore'
import {
  ONBOARDING_STORAGE_KEY,
  type OnboardingResult,
  type ProjectConfig,
  type StoredProject,
  type VirtualFile,
} from '@/lib/types'

const HOUR_MS = 60 * 60 * 1000
const DAY_MS = 24 * HOUR_MS

/** Seed configs for first-run demo projects. Only inserted when the store is empty. */
function buildSeedConfigs(): ProjectConfig[] {
  const now = Date.now()
  return [
    {
      id: 'proj_mock_pulsetrack',
      name: 'Pulse Track',
      packageName: 'com.sitara.pulsetrack',
      minSdk: '33',
      logoUrl: null,
      language: 'kotlin',
      template: 'bottom_nav',
      createdAt: new Date(now - 3 * HOUR_MS).toISOString(),
    },
    {
      id: 'proj_mock_ledgerly',
      name: 'Ledgerly',
      packageName: 'com.sitara.ledgerly',
      minSdk: '24',
      logoUrl: null,
      language: 'java',
      template: 'login_activity',
      createdAt: new Date(now - 2 * DAY_MS).toISOString(),
    },
    {
      id: 'proj_mock_orbitnotes',
      name: 'Orbit Notes',
      packageName: 'com.sitara.orbitnotes',
      minSdk: '29',
      logoUrl: null,
      language: 'kotlin',
      template: 'empty_activity',
      createdAt: new Date(now - 9 * DAY_MS).toISOString(),
    },
  ]
}

interface CreationToast {
  projectName: string
  fileCount: number
}

export default function Home() {
  const [hydrated, setHydrated] = useState<boolean>(false)
  const [onboardingDone, setOnboardingDone] = useState<boolean>(false)
  const [modalOpen, setModalOpen] = useState<boolean>(false)
  const [toast, setToast] = useState<CreationToast | null>(null)

  const projects = useIdeStore((s) => s.projects)
  const activeProjectId = useIdeStore((s) => s.activeProjectId)
  const upsertProject = useIdeStore((s) => s.upsertProject)
  const openProject = useIdeStore((s) => s.openProject)
  const toggleFavorite = useIdeStore((s) => s.toggleFavorite)

  // Read persisted onboarding state after mount to avoid hydration mismatches,
  // and seed demo projects into the persisted store on first run.
  useEffect(() => {
    setOnboardingDone(window.localStorage.getItem(ONBOARDING_STORAGE_KEY) === 'true')
    const state = useIdeStore.getState()
    if (Object.keys(state.projects).length === 0) {
      for (const config of buildSeedConfigs()) {
        state.upsertProject(config, generateAndroidBoilerplate(config))
      }
    }
    setHydrated(true)
  }, [])

  // Auto-dismiss the creation toast.
  useEffect(() => {
    if (toast === null) return
    const timer = window.setTimeout(() => setToast(null), 4000)
    return () => window.clearTimeout(timer)
  }, [toast])

  const handleOnboardingComplete = useCallback((_result: OnboardingResult) => {
    window.localStorage.setItem(ONBOARDING_STORAGE_KEY, 'true')
    setOnboardingDone(true)
  }, [])

  const handleCreateProject = useCallback(
    (config: ProjectConfig) => {
      const virtualTree: VirtualFile[] = generateAndroidBoilerplate(config)
      upsertProject(config, virtualTree)
      setModalOpen(false)
      setToast({ projectName: config.name, fileCount: countFiles(virtualTree) })
      openProject(config.id)
    },
    [upsertProject, openProject],
  )

  if (!hydrated) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-background" aria-busy="true">
        <div className="flex items-center gap-3">
          <span className="size-2 animate-pulse rounded-full bg-primary" aria-hidden="true" />
          <span className="font-mono text-sm text-muted-foreground">Booting Sitara sandbox…</span>
        </div>
      </main>
    )
  }

  if (!onboardingDone) {
    return <OnboardingWizard onComplete={handleOnboardingComplete} />
  }

  if (activeProjectId !== null && projects[activeProjectId] !== undefined) {
    return <IdeWorkspace />
  }

  const projectList: StoredProject[] = Object.values(projects)

  return (
    <>
      <Dashboard
        projects={projectList}
        onNewProject={() => setModalOpen(true)}
        onOpenProject={openProject}
        onToggleFavorite={toggleFavorite}
      />
      <NewProjectModal open={modalOpen} onClose={() => setModalOpen(false)} onCreate={handleCreateProject} />

      {/* Boilerplate generation toast */}
      <AnimatePresence>
        {toast !== null && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 24 }}
            transition={{ duration: 0.25 }}
            role="status"
            className="fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-xl border border-accent/40 bg-card px-5 py-3 shadow-2xl shadow-accent/10"
          >
            <CheckCircle2 className="size-5 text-accent" aria-hidden="true" />
            <p className="text-sm text-foreground">
              <span className="font-semibold">{toast.projectName}</span> created —{' '}
              <span className="font-mono text-accent">{toast.fileCount} files</span> generated in the virtual tree.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
