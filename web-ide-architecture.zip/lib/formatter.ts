/**
 * Deterministic source formatter for the Sitara IDE.
 * Brace-based re-indentation for Java/Kotlin/Gradle/JSON, tag-based for XML.
 */

export type FormatDialect = 'braces' | 'xml' | 'json' | 'none'

/** Chooses the formatting strategy for a file name. */
export function formatDialectForFile(fileName: string): FormatDialect {
  if (fileName.endsWith('.json')) return 'json'
  if (fileName.endsWith('.xml')) return 'xml'
  if (
    fileName.endsWith('.java') ||
    fileName.endsWith('.kt') ||
    fileName.endsWith('.gradle') ||
    fileName.endsWith('.kts')
  ) {
    return 'braces'
  }
  return 'none'
}

function indentOf(depth: number, tabSize: number): string {
  return ' '.repeat(Math.max(0, depth) * tabSize)
}

/** Re-indents brace-delimited source. Preserves blank lines and inline content. */
function formatBraces(source: string, tabSize: number): string {
  let depth = 0
  const result: string[] = []
  for (const rawLine of source.split('\n')) {
    const line = rawLine.trim()
    if (line.length === 0) {
      result.push('')
      continue
    }
    // Lines starting with closers dedent before printing.
    const leadingClosers = line.match(/^[)\]}]+/)?.[0].length ?? 0
    const printDepth = depth - leadingClosers
    result.push(indentOf(printDepth, tabSize) + line)
    // Net depth change for subsequent lines (ignoring string contents crudely).
    const stripped = line.replace(/"(?:[^"\\]|\\.)*"/g, '').replace(/\/\/.*$/, '')
    const opens = (stripped.match(/[({[]/g) ?? []).length
    const closes = (stripped.match(/[)}\]]/g) ?? []).length
    depth = Math.max(0, depth + opens - closes)
  }
  return result.join('\n')
}

/** Re-indents XML by tag depth. */
function formatXml(source: string, tabSize: number): string {
  let depth = 0
  const result: string[] = []
  for (const rawLine of source.split('\n')) {
    const line = rawLine.trim()
    if (line.length === 0) {
      result.push('')
      continue
    }
    const isClosing = line.startsWith('</')
    const printDepth = isClosing ? depth - 1 : depth
    result.push(indentOf(printDepth, tabSize) + line)
    // Compute depth delta: count opening tags minus closing/self-closing.
    const openTags = (line.match(/<[A-Za-z][^>]*[^/]>|<[A-Za-z][A-Za-z0-9_.:-]*>/g) ?? []).filter(
      (tag) => !tag.startsWith('<?') && !tag.startsWith('<!'),
    ).length
    const closeTags = (line.match(/<\/[A-Za-z]/g) ?? []).length
    const selfClosing = (line.match(/\/>/g) ?? []).length
    depth = Math.max(0, depth + openTags - closeTags - selfClosing)
  }
  return result.join('\n')
}

/**
 * Formats a source string. Returns the original text unchanged if the
 * dialect is 'none' or JSON parsing fails.
 */
export function formatSource(source: string, fileName: string, tabSize: number): string {
  const dialect = formatDialectForFile(fileName)
  if (dialect === 'json') {
    try {
      return JSON.stringify(JSON.parse(source), null, tabSize)
    } catch {
      return source
    }
  }
  if (dialect === 'xml') return formatXml(source, tabSize)
  if (dialect === 'braces') return formatBraces(source, tabSize)
  return source
}
