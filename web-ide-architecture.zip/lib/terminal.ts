/**
 * Virtual terminal command interpreter for the Sitara IDE.
 * Commands operate directly on the project's virtual filesystem.
 */

import type { VirtualFile } from '@/lib/types'
import {
  createFile,
  createFolder,
  findNode,
  listChildren,
  renderAsciiTree,
  resolvePath,
} from '@/lib/vfs'

export interface TerminalResult {
  /** Output lines to print. */
  output: string[]
  /** Whether the output is an error. */
  isError: boolean
  /** New working directory ('' = root), if changed. */
  cwd: string
  /** New tree if the command mutated the filesystem. */
  tree: VirtualFile[] | null
  /** Special effect requests handled by the UI layer. */
  effect: 'clear' | null
}

const HELP_TEXT: string[] = [
  'Sitara virtual shell — available commands:',
  '  ls [path]        List directory contents',
  '  cd <path>        Change working directory (.. supported)',
  '  pwd              Print working directory',
  '  mkdir <name>     Create a folder in the current directory',
  '  touch <name>     Create an empty file in the current directory',
  '  cat <file>       Print file contents',
  '  tree [path]      Render the directory tree',
  '  echo <text>      Print text',
  '  history          Show command history',
  '  clear            Clear the terminal',
  '  help             Show this help',
]

function ok(cwd: string, output: string[] = [], tree: VirtualFile[] | null = null): TerminalResult {
  return { output, isError: false, cwd, tree, effect: null }
}

function fail(cwd: string, message: string): TerminalResult {
  return { output: [message], isError: true, cwd, tree: null, effect: null }
}

/**
 * Executes a single shell line against the virtual filesystem.
 * Pure function: returns the new tree instead of mutating.
 */
export function executeCommand(
  line: string,
  tree: VirtualFile[],
  cwd: string,
  history: string[],
): TerminalResult {
  const trimmed = line.trim()
  if (trimmed.length === 0) return ok(cwd)

  const [command, ...args] = trimmed.split(/\s+/)
  const arg = args.join(' ')

  switch (command) {
    case 'help':
      return ok(cwd, HELP_TEXT)

    case 'clear':
      return { output: [], isError: false, cwd, tree: null, effect: 'clear' }

    case 'pwd':
      return ok(cwd, [`/${cwd}`])

    case 'echo':
      return ok(cwd, [arg])

    case 'history':
      return ok(
        cwd,
        history.map((entry, index) => `${String(index + 1).padStart(4)}  ${entry}`),
      )

    case 'ls': {
      const target = arg.length > 0 ? resolvePath(cwd, arg) : cwd
      const children = listChildren(tree, target)
      if (children === null) return fail(cwd, `ls: no such directory: ${arg}`)
      if (children.length === 0) return ok(cwd, ['(empty)'])
      return ok(
        cwd,
        children.map((node) => (node.type === 'folder' ? `${node.name}/` : node.name)),
      )
    }

    case 'cd': {
      if (arg.length === 0 || arg === '/') return ok('')
      const target = resolvePath(cwd, arg)
      if (target === '') return ok('')
      const node = findNode(tree, target)
      if (node === null || node.type !== 'folder') return fail(cwd, `cd: no such directory: ${arg}`)
      return ok(target)
    }

    case 'cat': {
      if (arg.length === 0) return fail(cwd, 'cat: missing file operand')
      const target = resolvePath(cwd, arg)
      const node = findNode(tree, target)
      if (node === null || node.type !== 'file') return fail(cwd, `cat: no such file: ${arg}`)
      return ok(cwd, node.content.length === 0 ? ['(empty file)'] : node.content.split('\n'))
    }

    case 'mkdir': {
      if (arg.length === 0) return fail(cwd, 'mkdir: missing operand')
      if (!/^[A-Za-z0-9._-]+$/.test(arg)) return fail(cwd, `mkdir: invalid name: ${arg}`)
      const result = createFolder(tree, cwd, arg)
      if (result.error !== null) return fail(cwd, `mkdir: ${result.error}`)
      return ok(cwd, [`created folder ${arg}/`], result.tree)
    }

    case 'touch': {
      if (arg.length === 0) return fail(cwd, 'touch: missing file operand')
      if (!/^[A-Za-z0-9._-]+$/.test(arg)) return fail(cwd, `touch: invalid name: ${arg}`)
      const result = createFile(tree, cwd, arg)
      if (result.error !== null) return fail(cwd, `touch: ${result.error}`)
      return ok(cwd, [`created ${arg}`], result.tree)
    }

    case 'tree': {
      const target = arg.length > 0 ? resolvePath(cwd, arg) : cwd
      const children = listChildren(tree, target)
      if (children === null) return fail(cwd, `tree: no such directory: ${arg}`)
      const root = target === '' ? '.' : target.split('/').pop() ?? '.'
      return ok(cwd, [root + '/', ...renderAsciiTree(children)])
    }

    default:
      return fail(cwd, `${command}: command not found. Type "help" for a list of commands.`)
  }
}
