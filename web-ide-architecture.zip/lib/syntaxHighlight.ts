/**
 * Lightweight, dependency-free syntax highlighter for the Sitara IDE.
 * Produces typed token streams for Java, Kotlin, XML, and Gradle sources.
 */

export type TokenKind =
  | 'keyword'
  | 'string'
  | 'comment'
  | 'annotation'
  | 'number'
  | 'tag'
  | 'attribute'
  | 'plain'

export interface Token {
  kind: TokenKind
  text: string
}

export type SourceDialect = 'java' | 'kotlin' | 'xml' | 'gradle' | 'plain'

/** Infers the highlighting dialect from a virtual file name. */
export function dialectForFile(fileName: string): SourceDialect {
  if (fileName.endsWith('.java')) return 'java'
  if (fileName.endsWith('.kt')) return 'kotlin'
  if (fileName.endsWith('.xml')) return 'xml'
  if (fileName.endsWith('.gradle') || fileName === 'settings.gradle') return 'gradle'
  return 'plain'
}

const JAVA_KEYWORDS = new Set<string>([
  'package', 'import', 'public', 'private', 'protected', 'class', 'interface',
  'extends', 'implements', 'static', 'final', 'void', 'int', 'boolean', 'new',
  'return', 'if', 'else', 'super', 'this', 'null', 'true', 'false', 'throws',
])

const KOTLIN_KEYWORDS = new Set<string>([
  'package', 'import', 'class', 'interface', 'object', 'fun', 'val', 'var',
  'override', 'private', 'internal', 'super', 'this', 'null', 'true', 'false',
  'return', 'if', 'else', 'when', 'lateinit', 'companion', 'const',
])

const GRADLE_KEYWORDS = new Set<string>([
  'plugins', 'id', 'apply', 'dependencies', 'implementation', 'android',
  'namespace', 'compileSdk', 'minSdk', 'targetSdk', 'defaultConfig',
  'buildTypes', 'release', 'debug', 'repositories', 'version', 'true', 'false',
])

const WORD_RE = /^[A-Za-z_$][A-Za-z0-9_$]*/
const NUMBER_RE = /^\d[\d._]*/

function keywordSetFor(dialect: SourceDialect): Set<string> {
  if (dialect === 'java') return JAVA_KEYWORDS
  if (dialect === 'kotlin') return KOTLIN_KEYWORDS
  if (dialect === 'gradle') return GRADLE_KEYWORDS
  return new Set<string>()
}

/** Tokenizes a single line of Java / Kotlin / Gradle code. */
function tokenizeCodeLine(line: string, keywords: Set<string>): Token[] {
  const tokens: Token[] = []
  let rest = line
  let plainBuffer = ''

  const flushPlain = (): void => {
    if (plainBuffer.length > 0) {
      tokens.push({ kind: 'plain', text: plainBuffer })
      plainBuffer = ''
    }
  }

  while (rest.length > 0) {
    // Line comment: consume through end of line.
    if (rest.startsWith('//')) {
      flushPlain()
      tokens.push({ kind: 'comment', text: rest })
      break
    }
    // String literal.
    if (rest[0] === '"') {
      flushPlain()
      let end = 1
      while (end < rest.length && rest[end] !== '"') {
        end = rest[end] === '\\' ? end + 2 : end + 1
      }
      const text = rest.slice(0, Math.min(end + 1, rest.length))
      tokens.push({ kind: 'string', text })
      rest = rest.slice(text.length)
      continue
    }
    // Annotation.
    if (rest[0] === '@') {
      const word = rest.slice(1).match(WORD_RE)
      if (word !== null) {
        flushPlain()
        tokens.push({ kind: 'annotation', text: `@${word[0]}` })
        rest = rest.slice(word[0].length + 1)
        continue
      }
    }
    // Number literal.
    const num = rest.match(NUMBER_RE)
    if (num !== null && (plainBuffer.length === 0 || !/[A-Za-z0-9_$]$/.test(plainBuffer))) {
      flushPlain()
      tokens.push({ kind: 'number', text: num[0] })
      rest = rest.slice(num[0].length)
      continue
    }
    // Identifier / keyword.
    const word = rest.match(WORD_RE)
    if (word !== null) {
      if (keywords.has(word[0])) {
        flushPlain()
        tokens.push({ kind: 'keyword', text: word[0] })
      } else {
        plainBuffer += word[0]
      }
      rest = rest.slice(word[0].length)
      continue
    }
    plainBuffer += rest[0]
    rest = rest.slice(1)
  }

  flushPlain()
  return tokens
}

/** Tokenizes a single line of XML markup. */
function tokenizeXmlLine(line: string): Token[] {
  const tokens: Token[] = []
  let rest = line

  while (rest.length > 0) {
    if (rest.startsWith('<!--')) {
      tokens.push({ kind: 'comment', text: rest })
      break
    }
    if (rest[0] === '<') {
      // Tag opener: <name, </name, <?xml
      const tag = rest.match(/^<\/?\??[A-Za-z][A-Za-z0-9_.:-]*/)
      if (tag !== null) {
        tokens.push({ kind: 'tag', text: tag[0] })
        rest = rest.slice(tag[0].length)
        continue
      }
    }
    if (rest[0] === '"') {
      let end = 1
      while (end < rest.length && rest[end] !== '"') end += 1
      const text = rest.slice(0, Math.min(end + 1, rest.length))
      tokens.push({ kind: 'string', text })
      rest = rest.slice(text.length)
      continue
    }
    const attr = rest.match(/^[A-Za-z_][A-Za-z0-9_.:-]*(?==)/)
    if (attr !== null) {
      tokens.push({ kind: 'attribute', text: attr[0] })
      rest = rest.slice(attr[0].length)
      continue
    }
    // Consume one char as plain (merge with previous plain token when possible).
    const last = tokens[tokens.length - 1]
    if (last !== undefined && last.kind === 'plain') {
      last.text += rest[0]
    } else {
      tokens.push({ kind: 'plain', text: rest[0] })
    }
    rest = rest.slice(1)
  }

  return tokens
}

/** Tokenizes full source content into per-line token arrays. */
export function tokenizeSource(content: string, dialect: SourceDialect): Token[][] {
  const lines = content.split('\n')
  if (dialect === 'xml') {
    return lines.map(tokenizeXmlLine)
  }
  if (dialect === 'plain') {
    return lines.map((line) => (line.length > 0 ? [{ kind: 'plain' as const, text: line }] : []))
  }
  const keywords = keywordSetFor(dialect)
  return lines.map((line) => tokenizeCodeLine(line, keywords))
}

/** Maps token kinds to Tailwind text color classes for the editor theme. */
export const TOKEN_CLASS: Record<TokenKind, string> = {
  keyword: 'text-primary',
  string: 'text-accent',
  comment: 'text-muted-foreground italic',
  annotation: 'text-yellow-400',
  number: 'text-orange-400',
  tag: 'text-primary',
  attribute: 'text-sky-300',
  plain: 'text-foreground',
}
