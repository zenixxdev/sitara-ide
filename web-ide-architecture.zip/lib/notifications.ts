/**
 * Real browser Notification API wrapper.
 * Notifications are strictly optional and only used for:
 * build completed, build failed, export finished, and long-running tasks.
 */

import type { NotificationPermissionState } from '@/lib/types'

/** Returns the current browser notification permission state. */
export function getNotificationPermission(): NotificationPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported'
  return Notification.permission
}

/**
 * Requests the real browser notification permission.
 * Resolves with the resulting state; never throws.
 */
export async function requestNotificationPermission(): Promise<NotificationPermissionState> {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported'
  if (Notification.permission === 'granted' || Notification.permission === 'denied') {
    return Notification.permission
  }
  try {
    return await Notification.requestPermission()
  } catch {
    return 'denied'
  }
}

export type IdeNotificationKind = 'build_success' | 'build_failed' | 'export_finished' | 'long_task'

const NOTIFICATION_COPY: Record<IdeNotificationKind, { title: string; icon: string }> = {
  build_success: { title: 'Build completed', icon: '✅' },
  build_failed: { title: 'Build failed', icon: '❌' },
  export_finished: { title: 'Export finished', icon: '📦' },
  long_task: { title: 'Task finished', icon: '⏱' },
}

/**
 * Fires a real system notification if (and only if) the user enabled them in
 * settings AND the browser permission is granted. Silently no-ops otherwise.
 */
export function notify(kind: IdeNotificationKind, body: string, enabledInSettings: boolean): void {
  if (!enabledInSettings) return
  if (getNotificationPermission() !== 'granted') return
  try {
    const copy = NOTIFICATION_COPY[kind]
    // eslint-disable-next-line no-new -- Notification constructor displays as a side effect
    new Notification(`${copy.icon} Sitara — ${copy.title}`, { body, tag: `sitara-${kind}` })
  } catch {
    // Some browsers (mobile) require a ServiceWorker; fail silently.
  }
}
