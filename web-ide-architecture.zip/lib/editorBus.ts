'use client'

/**
 * Tiny typed event bus connecting the top bar / keyboard shortcuts to the
 * active CodeMirror instance, and the editor's cursor back to the status bar.
 */

export type EditorCommand =
  | 'undo'
  | 'redo'
  | 'find'
  | 'replace'
  | 'gotoLine'
  | 'format'
  | 'toggleComment'
  | 'selectAll'

export interface CursorInfo {
  line: number
  column: number
  selectionChars: number
}

type CommandListener = (command: EditorCommand) => void
type CursorListener = (info: CursorInfo) => void

const commandListeners = new Set<CommandListener>()
const cursorListeners = new Set<CursorListener>()

export function dispatchEditorCommand(command: EditorCommand): void {
  for (const listener of commandListeners) listener(command)
}

export function onEditorCommand(listener: CommandListener): () => void {
  commandListeners.add(listener)
  return () => commandListeners.delete(listener)
}

export function publishCursor(info: CursorInfo): void {
  for (const listener of cursorListeners) listener(info)
}

export function onCursorChange(listener: CursorListener): () => void {
  cursorListeners.add(listener)
  return () => cursorListeners.delete(listener)
}
