/**
 * Virtual filesystem utilities for the Sitara IDE.
 * All operations are immutable: they return a new tree, never mutate the input.
 */

import type { ProjectStatistics, VirtualFile } from '@/lib/types'

/* ------------------------------------------------------------------ */
/* Lookup                                                              */
/* ------------------------------------------------------------------ */

/** Depth-first search for a node by exact path. */
export function findNode(tree: VirtualFile[], path: string): VirtualFile | null {
  for (const node of tree) {
    if (node.path === path) return node
    if (node.children !== undefined) {
      const found = findNode(node.children, path)
      if (found !== null) return found
    }
  }
  return null
}

/** Returns the parent folder path of a given path ('' for root-level nodes). */
export function parentPath(path: string): string {
  const index = path.lastIndexOf('/')
  return index === -1 ? '' : path.slice(0, index)
}

/** Lists the children at a folder path. Path '' means the tree root. */
export function listChildren(tree: VirtualFile[], folderPath: string): VirtualFile[] | null {
  if (folderPath === '') return tree
  const node = findNode(tree, folderPath)
  if (node === null || node.type !== 'folder') return null
  return node.children ?? []
}

/** Visits every node in the tree. */
export function walkTree(tree: VirtualFile[], visit: (node: VirtualFile) => void): void {
  for (const node of tree) {
    visit(node)
    if (node.children !== undefined) walkTree(node.children, visit)
  }
}

/** Collects all file (non-folder) nodes. */
export function collectFiles(tree: VirtualFile[]): VirtualFile[] {
  const files: VirtualFile[] = []
  walkTree(tree, (node) => {
    if (node.type === 'file') files.push(node)
  })
  return files
}

/* ------------------------------------------------------------------ */
/* Mutation (immutable)                                                */
/* ------------------------------------------------------------------ */

/** Maps over the tree, replacing nodes via the transform. Return null to delete. */
function transformTree(
  tree: VirtualFile[],
  transform: (node: VirtualFile) => VirtualFile | null,
): VirtualFile[] {
  const result: VirtualFile[] = []
  for (const node of tree) {
    const next = transform(node)
    if (next === null) continue
    if (next.children !== undefined) {
      result.push({ ...next, children: transformTree(next.children, transform) })
    } else {
      result.push(next)
    }
  }
  return result
}

/** Replaces the content of a file node. */
export function updateFileContent(tree: VirtualFile[], path: string, content: string): VirtualFile[] {
  return transformTree(tree, (node) => (node.path === path && node.type === 'file' ? { ...node, content } : node))
}

/** Sorts children folders-first, then alphabetically. */
function sortNodes(nodes: VirtualFile[]): VirtualFile[] {
  return [...nodes].sort((a, b) => {
    if (a.type !== b.type) return a.type === 'folder' ? -1 : 1
    return a.name.localeCompare(b.name)
  })
}

/** Inserts a node under folderPath ('' = root). Fails if a sibling name collides. */
export function insertNode(
  tree: VirtualFile[],
  folderPath: string,
  node: VirtualFile,
): { tree: VirtualFile[]; error: string | null } {
  const siblings = listChildren(tree, folderPath)
  if (siblings === null) return { tree, error: `Folder not found: ${folderPath}` }
  if (siblings.some((sibling) => sibling.name === node.name)) {
    return { tree, error: `"${node.name}" already exists in ${folderPath === '' ? 'root' : folderPath}` }
  }
  if (folderPath === '') return { tree: sortNodes([...tree, node]), error: null }
  const next = transformTree(tree, (candidate) =>
    candidate.path === folderPath && candidate.type === 'folder'
      ? { ...candidate, children: sortNodes([...(candidate.children ?? []), node]) }
      : candidate,
  )
  return { tree: next, error: null }
}

/** Creates an empty file under folderPath. */
export function createFile(
  tree: VirtualFile[],
  folderPath: string,
  name: string,
): { tree: VirtualFile[]; error: string | null; path: string } {
  const path = folderPath === '' ? name : `${folderPath}/${name}`
  const result = insertNode(tree, folderPath, { name, path, content: '', type: 'file' })
  return { ...result, path }
}

/** Creates an empty folder under folderPath. */
export function createFolder(
  tree: VirtualFile[],
  folderPath: string,
  name: string,
): { tree: VirtualFile[]; error: string | null; path: string } {
  const path = folderPath === '' ? name : `${folderPath}/${name}`
  const result = insertNode(tree, folderPath, { name, path, content: '', type: 'folder', children: [] })
  return { ...result, path }
}

/** Recursively rewrites paths after a subtree is renamed/moved. */
function rebasePaths(node: VirtualFile, oldPrefix: string, newPrefix: string): VirtualFile {
  const path = node.path === oldPrefix ? newPrefix : newPrefix + node.path.slice(oldPrefix.length)
  return {
    ...node,
    path,
    children: node.children?.map((child) => rebasePaths(child, oldPrefix, newPrefix)),
  }
}

/** Renames a node (file or folder), rebasing all descendant paths. */
export function renameNode(
  tree: VirtualFile[],
  path: string,
  newName: string,
): { tree: VirtualFile[]; error: string | null; newPath: string } {
  const node = findNode(tree, path)
  if (node === null) return { tree, error: `Not found: ${path}`, newPath: path }
  const parent = parentPath(path)
  const siblings = listChildren(tree, parent) ?? []
  if (siblings.some((sibling) => sibling.path !== path && sibling.name === newName)) {
    return { tree, error: `"${newName}" already exists here`, newPath: path }
  }
  const newPath = parent === '' ? newName : `${parent}/${newName}`
  const next = transformTree(tree, (candidate) =>
    candidate.path === path ? rebasePaths({ ...candidate, name: newName }, path, newPath) : candidate,
  )
  return { tree: next, error: null, newPath }
}

/** Deletes a node and its descendants. */
export function deleteNode(tree: VirtualFile[], path: string): VirtualFile[] {
  return transformTree(tree, (node) => (node.path === path ? null : node))
}

/** Duplicates a node as a sibling with a "_copy" suffix (before extension for files). */
export function duplicateNode(
  tree: VirtualFile[],
  path: string,
): { tree: VirtualFile[]; error: string | null; newPath: string } {
  const node = findNode(tree, path)
  if (node === null) return { tree, error: `Not found: ${path}`, newPath: path }
  const parent = parentPath(path)
  const dot = node.type === 'file' ? node.name.lastIndexOf('.') : -1
  const copyName =
    dot > 0 ? `${node.name.slice(0, dot)}_copy${node.name.slice(dot)}` : `${node.name}_copy`
  const newPath = parent === '' ? copyName : `${parent}/${copyName}`
  const clone = rebasePaths({ ...node, name: copyName }, path, newPath)
  return { ...insertNode(tree, parent, clone), newPath }
}

/** Moves a node into a destination folder ('' = root), rebasing descendant paths. */
export function moveNode(
  tree: VirtualFile[],
  path: string,
  destFolderPath: string,
): { tree: VirtualFile[]; error: string | null } {
  const node = findNode(tree, path)
  if (node === null) return { tree, error: `Not found: ${path}` }
  if (destFolderPath === path || destFolderPath.startsWith(`${path}/`)) {
    return { tree, error: 'Cannot move a folder into itself' }
  }
  if (parentPath(path) === destFolderPath) return { tree, error: null }
  const dest = destFolderPath === '' ? null : findNode(tree, destFolderPath)
  if (destFolderPath !== '' && (dest === null || dest.type !== 'folder')) {
    return { tree, error: `Destination folder not found: ${destFolderPath}` }
  }
  const removed = deleteNode(tree, path)
  const newPath = destFolderPath === '' ? node.name : `${destFolderPath}/${node.name}`
  return insertNode(removed, destFolderPath, rebasePaths(node, path, newPath))
}

/* ------------------------------------------------------------------ */
/* Analysis                                                            */
/* ------------------------------------------------------------------ */

/** Computes aggregate statistics for a project tree. */
export function computeStatistics(tree: VirtualFile[]): ProjectStatistics {
  const stats: ProjectStatistics = {
    totalFiles: 0,
    totalFolders: 0,
    totalLines: 0,
    totalBytes: 0,
    byExtension: {},
  }
  walkTree(tree, (node) => {
    if (node.type === 'folder') {
      stats.totalFolders += 1
      return
    }
    stats.totalFiles += 1
    stats.totalLines += node.content.length === 0 ? 0 : node.content.split('\n').length
    stats.totalBytes += new TextEncoder().encode(node.content).length
    const dot = node.name.lastIndexOf('.')
    const ext = dot > 0 ? node.name.slice(dot) : '(none)'
    stats.byExtension[ext] = (stats.byExtension[ext] ?? 0) + 1
  })
  return stats
}

/** Renders an ASCII tree (used by the terminal `tree` command). */
export function renderAsciiTree(nodes: VirtualFile[], prefix = ''): string[] {
  const lines: string[] = []
  nodes.forEach((node, index) => {
    const isLast = index === nodes.length - 1
    const connector = isLast ? '└── ' : '├── '
    lines.push(`${prefix}${connector}${node.name}${node.type === 'folder' ? '/' : ''}`)
    if (node.children !== undefined && node.children.length > 0) {
      lines.push(...renderAsciiTree(node.children, prefix + (isLast ? '    ' : '│   ')))
    }
  })
  return lines
}

/** Resolves a relative or absolute path string against a cwd ('' = root). */
export function resolvePath(cwd: string, input: string): string {
  const base = input.startsWith('/') ? [] : cwd === '' ? [] : cwd.split('/')
  const segments = input.split('/').filter((segment) => segment.length > 0 && segment !== '.')
  const stack = [...base]
  for (const segment of segments) {
    if (segment === '..') {
      stack.pop()
    } else {
      stack.push(segment)
    }
  }
  return stack.join('/')
}
