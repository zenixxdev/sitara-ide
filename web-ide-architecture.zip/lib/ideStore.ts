'use client'

/**
 * Unified state architecture for the Sitara IDE.
 * A single zustand store synchronizes: projects, the virtual filesystem,
 * editor tabs, recent files, explorer, bottom panel, terminal, build
 * pipeline, search, and settings. Projects + settings persist to localStorage.
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import {
  BuildManager,
  VirtualCompiler,
  type BuildOutcome,
  type BuildRequest,
} from '@/lib/buildSystem'
import { notify } from '@/lib/notifications'
import { executeCommand } from '@/lib/terminal'
import {
  DEFAULT_IDE_SETTINGS,
  type BottomPanelTab,
  type BuildArtifact,
  type BuildProgressState,
  type EditorTabState,
  type IdeSettings,
  type LogEntry,
  type LogLevel,
  type ProblemEntry,
  type ProjectConfig,
  type SearchMatch,
  type StoredProject,
  type TerminalLine,
  type VirtualFile,
} from '@/lib/types'
import {
  collectFiles,
  createFile,
  createFolder,
  deleteNode,
  duplicateNode,
  findNode,
  moveNode,
  renameNode,
  updateFileContent,
} from '@/lib/vfs'

export type ProjectAction = 'rename' | 'duplicate' | 'delete' | 'export' | 'import' | 'stats'

const IDLE_PROGRESS: BuildProgressState = {
  status: 'idle',
  currentStep: null,
  progress: 0,
  etaMs: null,
  startedAt: null,
  finishedAt: null,
  buildId: 0,
}

function timeStamp(): string {
  return new Date().toLocaleTimeString('en-US', { hour12: false })
}

let logId = 0
let terminalLineId = 0

export interface IdeState {
  /* ---- persisted ---- */
  projects: Record<string, StoredProject>
  settings: IdeSettings

  /* ---- session ---- */
  activeProjectId: string | null
  tabs: EditorTabState[]
  activePath: string | null
  recentFiles: string[]
  /** Buffered (unsaved) contents keyed by path. */
  drafts: Record<string, string>

  sidebarOpen: boolean
  bottomPanelOpen: boolean
  bottomPanelTab: BottomPanelTab
  settingsOpen: boolean
  searchOpen: boolean
  /** Which project-level action modal is open (rename/delete/export/…). */
  projectAction: ProjectAction | null
  /** Editor caret position for the status bar. */
  cursor: { line: number; col: number }

  buildProgress: BuildProgressState
  buildLogs: LogEntry[]
  systemLogs: LogEntry[]
  outputLogs: LogEntry[]
  problems: ProblemEntry[]
  artifact: BuildArtifact | null

  terminalLines: TerminalLine[]
  terminalCwd: string
  terminalHistory: string[]

  /* ---- project lifecycle ---- */
  upsertProject: (config: ProjectConfig, tree: VirtualFile[]) => void
  openProject: (id: string) => void
  closeProject: () => void
  renameProject: (id: string, name: string) => void
  deleteProject: (id: string) => void
  duplicateProject: (id: string) => void
  toggleFavorite: (id: string) => void
  importProject: (data: StoredProject) => string | null

  /* ---- filesystem ---- */
  activeTree: () => VirtualFile[]
  setTree: (tree: VirtualFile[]) => void
  fsCreateFile: (folderPath: string, name: string) => string | null
  fsCreateFolder: (folderPath: string, name: string) => string | null
  fsRename: (path: string, newName: string) => string | null
  fsDelete: (path: string) => void
  fsDuplicate: (path: string) => string | null
  fsMove: (path: string, destFolder: string) => string | null

  /* ---- editor ---- */
  openFile: (path: string) => void
  closeTab: (path: string) => void
  togglePin: (path: string) => void
  setActivePath: (path: string) => void
  updateDraft: (path: string, content: string) => void
  saveFile: (path: string) => void
  saveAll: () => void
  fileContent: (path: string) => string

  /* ---- ui ---- */
  toggleSidebar: () => void
  setBottomPanel: (open: boolean, tab?: BottomPanelTab) => void
  setSettingsOpen: (open: boolean) => void
  setSearchOpen: (open: boolean) => void
  setProjectAction: (action: ProjectAction | null) => void
  setCursor: (line: number, col: number) => void
  /** Clears the content of a bottom panel tab. */
  clearPanel: (tab: BottomPanelTab) => void
  updateSettings: (patch: Partial<IdeSettings>) => void
  resetSettings: () => void

  /* ---- build ---- */
  startBuild: (mode: 'build' | 'run') => void
  clearBuildLogs: () => void
  pushLog: (target: 'build' | 'system' | 'output', level: LogLevel, text: string) => void

  /* ---- terminal ---- */
  runTerminalCommand: (line: string) => void
  clearTerminal: () => void

  /* ---- search ---- */
  searchProject: (query: string) => SearchMatch[]
}

export const useIdeStore = create<IdeState>()(
  persist(
    (set, get) => {
      /** Applies a tree update to the active project and bumps lastOpenedAt. */
      const withActiveProject = (updater: (project: StoredProject) => StoredProject): void => {
        const { activeProjectId, projects } = get()
        if (activeProjectId === null) return
        const project = projects[activeProjectId]
        if (project === undefined) return
        set({ projects: { ...projects, [activeProjectId]: updater(project) } })
      }

      const makeLog = (source: LogEntry['source'], level: LogLevel, text: string): LogEntry => {
        logId += 1
        return { id: logId, level, text, timestamp: timeStamp(), source }
      }

      /* ---- BuildManager wiring (module singleton, backend-agnostic) ---- */
      const manager = new BuildManager(
        new VirtualCompiler(),
        {
          log: (level, text) =>
            set((state) => ({ buildLogs: [...state.buildLogs, makeLog('build', level, text)] })),
        },
        {
          update: (patch) => set((state) => ({ buildProgress: { ...state.buildProgress, ...patch } })),
        },
        {
          buildSucceeded: (projectName, artifactName) =>
            notify('build_success', `${projectName}: ${artifactName} assembled`, get().settings.notificationsEnabled),
          buildFailed: (projectName, reason) =>
            notify('build_failed', `${projectName}: ${reason}`, get().settings.notificationsEnabled),
          exportFinished: (artifactName) =>
            notify('export_finished', `${artifactName} is ready to download`, get().settings.notificationsEnabled),
        },
        (outcome: BuildOutcome, request: BuildRequest) => {
          set({ problems: outcome.problems })
          if (outcome.artifact !== null) {
            const previous = get().artifact
            if (previous !== null) URL.revokeObjectURL(previous.url)
            set({
              artifact: {
                fileName: outcome.artifact.fileName,
                sizeBytes: outcome.artifact.blob.size,
                url: URL.createObjectURL(outcome.artifact.blob),
                createdAt: new Date().toISOString(),
              },
            })
          }
          get().pushLog(
            'output',
            outcome.success ? 'success' : 'error',
            outcome.success
              ? `assembleDebug finished for ${request.config.name}`
              : `assembleDebug failed for ${request.config.name}`,
          )
        },
      )

      return {
        projects: {},
        settings: DEFAULT_IDE_SETTINGS,

        activeProjectId: null,
        tabs: [],
        activePath: null,
        recentFiles: [],
        drafts: {},

        sidebarOpen: true,
        bottomPanelOpen: true,
        bottomPanelTab: 'build',
        settingsOpen: false,
        searchOpen: false,
        projectAction: null,
        cursor: { line: 1, col: 1 },

        buildProgress: IDLE_PROGRESS,
        buildLogs: [],
        systemLogs: [],
        outputLogs: [],
        problems: [],
        artifact: null,

        terminalLines: [],
        terminalCwd: '',
        terminalHistory: [],

        /* ---------------- project lifecycle ---------------- */

        upsertProject: (config, tree) => {
          const { projects } = get()
          const existing = projects[config.id]
          set({
            projects: {
              ...projects,
              [config.id]: {
                config,
                tree,
                lastOpenedAt: new Date().toISOString(),
                favorite: existing?.favorite ?? false,
              },
            },
          })
        },

        openProject: (id) => {
          const project = get().projects[id]
          if (project === undefined) return
          set({
            activeProjectId: id,
            tabs: [],
            activePath: null,
            recentFiles: [],
            drafts: {},
            buildLogs: [],
            problems: [],
            buildProgress: IDLE_PROGRESS,
            terminalLines: [],
            terminalCwd: '',
            terminalHistory: [],
            bottomPanelTab: 'build',
            projects: {
              ...get().projects,
              [id]: { ...project, lastOpenedAt: new Date().toISOString() },
            },
          })
          get().pushLog('system', 'info', `Workspace loaded: ${project.config.name}`)
          // Auto-open MainActivity (or the first file).
          const files = collectFiles(project.tree)
          const main = files.find((file) => file.name.startsWith('MainActivity')) ?? files[0]
          if (main !== undefined) get().openFile(main.path)
        },

        closeProject: () => set({ activeProjectId: null, tabs: [], activePath: null, drafts: {} }),

        renameProject: (id, name) => {
          const { projects } = get()
          const project = projects[id]
          if (project === undefined || name.trim().length === 0) return
          set({
            projects: {
              ...projects,
              [id]: { ...project, config: { ...project.config, name: name.trim() } },
            },
          })
        },

        deleteProject: (id) => {
          const { projects, activeProjectId } = get()
          const next = { ...projects }
          delete next[id]
          set({ projects: next, ...(activeProjectId === id ? { activeProjectId: null, tabs: [], activePath: null } : {}) })
        },

        duplicateProject: (id) => {
          const project = get().projects[id]
          if (project === undefined) return
          const newId = `proj_${Date.now().toString(36)}`
          const config: ProjectConfig = {
            ...project.config,
            id: newId,
            name: `${project.config.name} Copy`,
            createdAt: new Date().toISOString(),
          }
          get().upsertProject(config, project.tree)
        },

        toggleFavorite: (id) => {
          const { projects } = get()
          const project = projects[id]
          if (project === undefined) return
          set({ projects: { ...projects, [id]: { ...project, favorite: !project.favorite } } })
        },

        importProject: (data) => {
          if (typeof data?.config?.id !== 'string' || !Array.isArray(data.tree)) {
            return 'Invalid project file: missing config or tree'
          }
          const id = get().projects[data.config.id] !== undefined ? `proj_${Date.now().toString(36)}` : data.config.id
          get().upsertProject({ ...data.config, id }, data.tree)
          return null
        },

        /* ---------------- filesystem ---------------- */

        activeTree: () => {
          const { activeProjectId, projects } = get()
          if (activeProjectId === null) return []
          return projects[activeProjectId]?.tree ?? []
        },

        setTree: (tree) => withActiveProject((project) => ({ ...project, tree })),

        fsCreateFile: (folderPath, name) => {
          const result = createFile(get().activeTree(), folderPath, name)
          if (result.error !== null) return result.error
          get().setTree(result.tree)
          get().openFile(result.path)
          return null
        },

        fsCreateFolder: (folderPath, name) => {
          const result = createFolder(get().activeTree(), folderPath, name)
          if (result.error !== null) return result.error
          get().setTree(result.tree)
          return null
        },

        fsRename: (path, newName) => {
          const result = renameNode(get().activeTree(), path, newName)
          if (result.error !== null) return result.error
          get().setTree(result.tree)
          // Rebase open tabs / recents / drafts pointing at the old path.
          const rebase = (candidate: string): string =>
            candidate === path
              ? result.newPath
              : candidate.startsWith(`${path}/`)
                ? result.newPath + candidate.slice(path.length)
                : candidate
          set((state) => ({
            tabs: state.tabs.map((tab) => ({
              ...tab,
              path: rebase(tab.path),
              name: rebase(tab.path).split('/').pop() ?? tab.name,
            })),
            activePath: state.activePath === null ? null : rebase(state.activePath),
            recentFiles: state.recentFiles.map(rebase),
            drafts: Object.fromEntries(Object.entries(state.drafts).map(([key, value]) => [rebase(key), value])),
          }))
          return null
        },

        fsDelete: (path) => {
          get().setTree(deleteNode(get().activeTree(), path))
          set((state) => {
            const tabs = state.tabs.filter((tab) => tab.path !== path && !tab.path.startsWith(`${path}/`))
            const activePath =
              state.activePath !== null && (state.activePath === path || state.activePath.startsWith(`${path}/`))
                ? (tabs[tabs.length - 1]?.path ?? null)
                : state.activePath
            return {
              tabs,
              activePath,
              recentFiles: state.recentFiles.filter((entry) => entry !== path && !entry.startsWith(`${path}/`)),
            }
          })
        },

        fsDuplicate: (path) => {
          const result = duplicateNode(get().activeTree(), path)
          if (result.error !== null) return result.error
          get().setTree(result.tree)
          return null
        },

        fsMove: (path, destFolder) => {
          const result = moveNode(get().activeTree(), path, destFolder)
          if (result.error !== null) return result.error
          get().setTree(result.tree)
          return null
        },

        /* ---------------- editor ---------------- */

        fileContent: (path) => {
          const draft = get().drafts[path]
          if (draft !== undefined) return draft
          const node = findNode(get().activeTree(), path)
          return node?.content ?? ''
        },

        openFile: (path) => {
          const node = findNode(get().activeTree(), path)
          if (node === null || node.type !== 'file') return
          set((state) => ({
            tabs: state.tabs.some((tab) => tab.path === path)
              ? state.tabs
              : [...state.tabs, { path, name: node.name, pinned: false, dirty: false }],
            activePath: path,
            recentFiles: [path, ...state.recentFiles.filter((entry) => entry !== path)].slice(0, 8),
          }))
        },

        closeTab: (path) => {
          set((state) => {
            const tabs = state.tabs.filter((tab) => tab.path !== path)
            const drafts = { ...state.drafts }
            delete drafts[path]
            return {
              tabs,
              drafts,
              activePath:
                state.activePath === path ? (tabs[tabs.length - 1]?.path ?? null) : state.activePath,
            }
          })
        },

        togglePin: (path) => {
          set((state) => {
            const tabs = state.tabs.map((tab) => (tab.path === path ? { ...tab, pinned: !tab.pinned } : tab))
            // Pinned tabs stay grouped at the front.
            return { tabs: [...tabs.filter((tab) => tab.pinned), ...tabs.filter((tab) => !tab.pinned)] }
          })
        },

        setActivePath: (path) => {
          set((state) => ({
            activePath: path,
            recentFiles: [path, ...state.recentFiles.filter((entry) => entry !== path)].slice(0, 8),
          }))
        },

        updateDraft: (path, content) => {
          set((state) => ({
            drafts: { ...state.drafts, [path]: content },
            tabs: state.tabs.map((tab) => (tab.path === path ? { ...tab, dirty: true } : tab)),
          }))
          if (get().settings.autoSave) get().saveFile(path)
        },

        saveFile: (path) => {
          const draft = get().drafts[path]
          if (draft === undefined) return
          get().setTree(updateFileContent(get().activeTree(), path, draft))
          set((state) => {
            const drafts = { ...state.drafts }
            delete drafts[path]
            return {
              drafts,
              tabs: state.tabs.map((tab) => (tab.path === path ? { ...tab, dirty: false } : tab)),
            }
          })
        },

        saveAll: () => {
          for (const path of Object.keys(get().drafts)) get().saveFile(path)
        },

        /* ---------------- ui ---------------- */

        toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
        setBottomPanel: (open, tab) =>
          set((state) => ({ bottomPanelOpen: open, bottomPanelTab: tab ?? state.bottomPanelTab })),
        setSettingsOpen: (open) => set({ settingsOpen: open }),
        setSearchOpen: (open) => set({ searchOpen: open }),
        setProjectAction: (action) => set({ projectAction: action }),
        setCursor: (line, col) => set({ cursor: { line, col } }),
        clearPanel: (tab) => {
          if (tab === 'build') set({ buildLogs: [] })
          else if (tab === 'logs') set({ systemLogs: [] })
          else if (tab === 'output') set({ outputLogs: [] })
          else if (tab === 'problems') set({ problems: [] })
          else set({ terminalLines: [] })
        },
        updateSettings: (patch) => set((state) => ({ settings: { ...state.settings, ...patch } })),
        resetSettings: () => set({ settings: DEFAULT_IDE_SETTINGS }),

        /* ---------------- build ---------------- */

        pushLog: (target, level, text) => {
          const entry = makeLog(target, level, text)
          if (target === 'build') set((state) => ({ buildLogs: [...state.buildLogs, entry] }))
          else if (target === 'system') set((state) => ({ systemLogs: [...state.systemLogs, entry] }))
          else set((state) => ({ outputLogs: [...state.outputLogs, entry] }))
        },

        startBuild: (mode) => {
          const { activeProjectId, projects, settings } = get()
          if (activeProjectId === null) return
          get().saveAll() // Step 1 of the pipeline: persist everything first.
          const project = projects[activeProjectId]
          if (project === undefined) return
          if (settings.autoOpenBuildPanel) get().setBottomPanel(true, 'build')
          set({ buildLogs: [], problems: [] })
          manager.request({ config: project.config, tree: get().activeTree(), mode })
        },

        clearBuildLogs: () => set({ buildLogs: [] }),

        /* ---------------- terminal ---------------- */

        runTerminalCommand: (line) => {
          const state = get()
          terminalLineId += 1
          const commandLine: TerminalLine = {
            id: terminalLineId,
            kind: 'command',
            text: `sitara:/${state.terminalCwd}$ ${line}`,
          }
          const result = executeCommand(line, state.activeTree(), state.terminalCwd, state.terminalHistory)
          if (result.effect === 'clear') {
            set({ terminalLines: [], terminalHistory: [...state.terminalHistory, line], terminalCwd: result.cwd })
            return
          }
          if (result.tree !== null) get().setTree(result.tree)
          const outputLines: TerminalLine[] = result.output.map((text) => {
            terminalLineId += 1
            return { id: terminalLineId, kind: result.isError ? 'error' : 'output', text }
          })
          set((current) => ({
            terminalLines: [...current.terminalLines, commandLine, ...outputLines],
            terminalHistory: line.trim().length > 0 ? [...current.terminalHistory, line] : current.terminalHistory,
            terminalCwd: result.cwd,
          }))
        },

        clearTerminal: () => set({ terminalLines: [] }),

        /* ---------------- search ---------------- */

        searchProject: (query) => {
          if (query.trim().length < 2) return []
          const needle = query.toLowerCase()
          const matches: SearchMatch[] = []
          for (const file of collectFiles(get().activeTree())) {
            const content = get().drafts[file.path] ?? file.content
            const lines = content.split('\n')
            for (let index = 0; index < lines.length; index += 1) {
              const column = lines[index].toLowerCase().indexOf(needle)
              if (column !== -1) {
                matches.push({
                  filePath: file.path,
                  fileName: file.name,
                  line: index + 1,
                  lineText: lines[index].trim().slice(0, 160),
                  column,
                })
                if (matches.length >= 200) return matches
              }
            }
          }
          return matches
        },
      }
    },
    {
      name: 'sitara_ide_state',
      partialize: (state) => ({ projects: state.projects, settings: state.settings }),
    },
  ),
)
