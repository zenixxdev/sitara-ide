/**
 * RealPackagingEngine — assembles a structurally valid, installable APK.
 *
 * Pipeline (all real, no simulation):
 *   1. Binary AndroidManifest.xml (AXML) generated from the project config.
 *   2. Every res/layout/*.xml compiled to AXML.
 *   3. resources.arsc built with layout entries (activity_main = 0x7f010000).
 *   4. classes.dex — genuine d8 output (precompiled Sitara runtime shell).
 *   5. Aligned zip + v1/v2 signing via the SigningEngine.
 *
 * Browser limitation, stated honestly: user Java/Kotlin sources are validated
 * but NOT compiled to dex in the browser (no javac/kotlinc/d8 in JS). The
 * installed app launches the runtime shell activity which renders the user's
 * compiled activity_main layout. A server-side dex compiler can replace
 * `DexProvider` without touching packaging or signing.
 */

import type { ProjectConfig } from '@/lib/types'
import { compileAxml, type AxmlWarning } from '@/lib/apk/axml'
import { buildArsc } from '@/lib/apk/arsc'
import { getDebugKeystore, packageAndSign } from '@/lib/apk/signer'
import { runtimeDexBytes } from '@/lib/apk/runtimeDex'
import type { ZipEntrySpec } from '@/lib/apk/zip'

export const RUNTIME_ACTIVITY = 'app.sitara.runtime.MainActivity'

/** Pluggable dex backend. The default returns the precompiled runtime dex. */
export interface DexProvider {
  readonly name: string
  getDex: (config: ProjectConfig, sources: Array<{ path: string; content: string }>) => Promise<Uint8Array>
}

export class PrecompiledRuntimeDexProvider implements DexProvider {
  readonly name = 'sitara-runtime-dex (d8 8.3.37, minApi 21)'

  async getDex(): Promise<Uint8Array> {
    const dex = runtimeDexBytes()
    // Genuine dex sanity: magic "dex\n035\0"
    const magic = [0x64, 0x65, 0x78, 0x0a, 0x30, 0x33, 0x35, 0x00]
    for (let i = 0; i < magic.length; i += 1) {
      if (dex[i] !== magic[i]) throw new Error('Runtime dex is corrupted (bad magic)')
    }
    return dex
  }
}

export interface PackagingInput {
  config: ProjectConfig
  layouts: Array<{ name: string; path: string; content: string }>
}

export interface PackagingResult {
  apkBytes: Uint8Array
  certSha256: string
  warnings: Array<{ file: string; message: string; line: number }>
  entryNames: string[]
}

function buildManifestXml(config: ProjectConfig): string {
  const minSdk = Number.parseInt(config.minSdk, 10)
  const targetSdk = Math.max(28, minSdk)
  return [
    '<?xml version="1.0" encoding="utf-8"?>',
    '<manifest xmlns:android="http://schemas.android.com/apk/res/android"',
    `    package="${config.packageName}"`,
    '    android:versionCode="1"',
    '    android:versionName="1.0">',
    `    <uses-sdk android:minSdkVersion="${minSdk}" android:targetSdkVersion="${targetSdk}" />`,
    `    <application android:label="${config.name.replace(/"/g, '')}" android:allowBackup="true">`,
    `        <activity android:name="${RUNTIME_ACTIVITY}" android:exported="true">`,
    '            <intent-filter>',
    '                <action android:name="android.intent.action.MAIN" />',
    '                <category android:name="android.intent.category.LAUNCHER" />',
    '            </intent-filter>',
    '        </activity>',
    '    </application>',
    '</manifest>',
  ].join('\n')
}

/**
 * Builds and signs the final APK. Throws with a descriptive error if any
 * stage produces invalid output.
 */
export async function packageApk(
  input: PackagingInput,
  dexProvider: DexProvider,
  log: (text: string) => void,
): Promise<PackagingResult> {
  const { config, layouts } = input
  const warnings: PackagingResult['warnings'] = []
  const collect = (file: string, axmlWarnings: AxmlWarning[]): void => {
    for (const warning of axmlWarnings) warnings.push({ file, message: warning.message, line: warning.line })
  }

  // 1. Manifest → AXML
  const manifestXml = buildManifestXml(config)
  const manifest = compileAxml(manifestXml)
  collect('AndroidManifest.xml', manifest.warnings)
  log(`aapt-web: AndroidManifest.xml → binary AXML (${manifest.bytes.length} bytes, launcher=${RUNTIME_ACTIVITY})`)

  // 2. Layouts → AXML
  const compiledLayouts: Array<{ name: string; apkPath: string; bytes: Uint8Array }> = []
  for (const layout of layouts) {
    const compiled = compileAxml(layout.content)
    collect(layout.path, compiled.warnings)
    const apkPath = `res/layout/${layout.name}.xml`
    compiledLayouts.push({ name: layout.name, apkPath, bytes: compiled.bytes })
    log(`aapt-web: ${layout.path} → ${apkPath} (${compiled.bytes.length} bytes)`)
  }

  // 3. resources.arsc
  const arsc = buildArsc(
    config.packageName,
    compiledLayouts.map((layout) => ({ name: layout.name, apkPath: layout.apkPath })),
  )
  log(`aapt-web: resources.arsc built (${arsc.bytes.length} bytes, ${compiledLayouts.length} layout entries, activity_main=0x${arsc.ids.activity_main.toString(16)})`)
  if (arsc.ids.activity_main !== 0x7f010000) {
    throw new Error(`Resource id contract broken: activity_main=0x${arsc.ids.activity_main.toString(16)}, runtime dex expects 0x7f010000`)
  }

  // 4. classes.dex
  const dex = await dexProvider.getDex(config, [])
  log(`dex: classes.dex ready (${dex.length} bytes, provider: ${dexProvider.name})`)

  // 5. Package + sign
  const entries: ZipEntrySpec[] = [
    { name: 'AndroidManifest.xml', data: manifest.bytes },
    { name: 'resources.arsc', data: arsc.bytes, align: 4 },
    { name: 'classes.dex', data: dex },
    ...compiledLayouts.map((layout) => ({ name: layout.apkPath, data: layout.bytes })),
  ]
  const keystore = getDebugKeystore(log)
  const signed = await packageAndSign(entries, keystore, log)
  log(`package: ${signed.bytes.length} bytes, ${entries.length + 3} zip entries, cert SHA-256 ${signed.certSha256.slice(0, 23)}…`)

  return {
    apkBytes: signed.bytes,
    certSha256: signed.certSha256,
    warnings,
    entryNames: [...entries.map((entry) => entry.name), 'META-INF/MANIFEST.MF', 'META-INF/CERT.SF', 'META-INF/CERT.RSA'],
  }
}
