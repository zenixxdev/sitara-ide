/**
 * Minimal, strict XML parser for Android source files (manifest + layouts).
 * Deterministic, dependency-free, and usable in both the browser and Node
 * (DOMParser is not available in workers/Node, and we need identical behavior
 * in the build verifier test-bench and the browser packager).
 */

export interface XmlElement {
  tag: string
  attrs: Record<string, string>
  children: XmlElement[]
  /** Concatenated text content directly inside this element. */
  text: string
  /** 1-based line where the element starts (for diagnostics). */
  line: number
}

export class XmlParseError extends Error {
  constructor(
    message: string,
    public line: number,
  ) {
    super(message)
  }
}

interface Cursor {
  src: string
  pos: number
}

function lineAt(src: string, pos: number): number {
  let line = 1
  for (let i = 0; i < pos && i < src.length; i += 1) {
    if (src[i] === '\n') line += 1
  }
  return line
}

function skipWhitespace(c: Cursor): void {
  while (c.pos < c.src.length && /\s/.test(c.src[c.pos])) c.pos += 1
}

function skipMisc(c: Cursor): void {
  // Skips whitespace, XML declarations, comments, and DOCTYPE (rejected later if malformed).
  for (;;) {
    skipWhitespace(c)
    if (c.src.startsWith('<?', c.pos)) {
      const end = c.src.indexOf('?>', c.pos)
      if (end === -1) throw new XmlParseError('Unterminated XML declaration', lineAt(c.src, c.pos))
      c.pos = end + 2
      continue
    }
    if (c.src.startsWith('<!--', c.pos)) {
      const end = c.src.indexOf('-->', c.pos)
      if (end === -1) throw new XmlParseError('Unterminated comment', lineAt(c.src, c.pos))
      c.pos = end + 3
      continue
    }
    return
  }
}

const NAME_RE = /^[A-Za-z_][A-Za-z0-9_.:-]*/

function decodeEntities(value: string): string {
  return value
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 10)))
    .replace(/&#x([0-9A-Fa-f]+);/g, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&amp;/g, '&')
}

function parseElement(c: Cursor): XmlElement {
  if (c.src[c.pos] !== '<') {
    throw new XmlParseError('Expected element start', lineAt(c.src, c.pos))
  }
  const startLine = lineAt(c.src, c.pos)
  c.pos += 1
  const nameMatch = NAME_RE.exec(c.src.slice(c.pos))
  if (nameMatch === null) throw new XmlParseError('Invalid element name', startLine)
  const tag = nameMatch[0]
  c.pos += tag.length

  const attrs: Record<string, string> = {}
  for (;;) {
    skipWhitespace(c)
    if (c.src.startsWith('/>', c.pos)) {
      c.pos += 2
      return { tag, attrs, children: [], text: '', line: startLine }
    }
    if (c.src[c.pos] === '>') {
      c.pos += 1
      break
    }
    const attrMatch = NAME_RE.exec(c.src.slice(c.pos))
    if (attrMatch === null) {
      throw new XmlParseError(`Malformed attribute in <${tag}>`, lineAt(c.src, c.pos))
    }
    const attrName = attrMatch[0]
    c.pos += attrName.length
    skipWhitespace(c)
    if (c.src[c.pos] !== '=') {
      throw new XmlParseError(`Attribute "${attrName}" is missing a value`, lineAt(c.src, c.pos))
    }
    c.pos += 1
    skipWhitespace(c)
    const quote = c.src[c.pos]
    if (quote !== '"' && quote !== "'") {
      throw new XmlParseError(`Attribute "${attrName}" value must be quoted`, lineAt(c.src, c.pos))
    }
    c.pos += 1
    const end = c.src.indexOf(quote, c.pos)
    if (end === -1) {
      throw new XmlParseError(`Unterminated value for attribute "${attrName}"`, lineAt(c.src, c.pos))
    }
    attrs[attrName] = decodeEntities(c.src.slice(c.pos, end))
    c.pos = end + 1
  }

  // Parse children / text until the matching close tag.
  const children: XmlElement[] = []
  let text = ''
  for (;;) {
    if (c.pos >= c.src.length) {
      throw new XmlParseError(`Unclosed element <${tag}>`, startLine)
    }
    if (c.src.startsWith('<!--', c.pos)) {
      const end = c.src.indexOf('-->', c.pos)
      if (end === -1) throw new XmlParseError('Unterminated comment', lineAt(c.src, c.pos))
      c.pos = end + 3
      continue
    }
    if (c.src.startsWith('</', c.pos)) {
      const end = c.src.indexOf('>', c.pos)
      if (end === -1) throw new XmlParseError('Malformed closing tag', lineAt(c.src, c.pos))
      const closeName = c.src.slice(c.pos + 2, end).trim()
      if (closeName !== tag) {
        throw new XmlParseError(`Mismatched closing tag: expected </${tag}>, found </${closeName}>`, lineAt(c.src, c.pos))
      }
      c.pos = end + 1
      return { tag, attrs, children, text: text.trim(), line: startLine }
    }
    if (c.src[c.pos] === '<') {
      children.push(parseElement(c))
      continue
    }
    const nextTag = c.src.indexOf('<', c.pos)
    const chunk = nextTag === -1 ? c.src.slice(c.pos) : c.src.slice(c.pos, nextTag)
    text += decodeEntities(chunk)
    c.pos = nextTag === -1 ? c.src.length : nextTag
  }
}

/** Parses an XML document and returns its root element. Throws XmlParseError with line info. */
export function parseXml(source: string): XmlElement {
  const cursor: Cursor = { src: source, pos: 0 }
  skipMisc(cursor)
  if (cursor.pos >= source.length) throw new XmlParseError('Document has no root element', 1)
  const root = parseElement(cursor)
  skipMisc(cursor)
  if (cursor.pos < source.length && source.slice(cursor.pos).trim().length > 0) {
    throw new XmlParseError('Unexpected content after root element', lineAt(source, cursor.pos))
  }
  return root
}
