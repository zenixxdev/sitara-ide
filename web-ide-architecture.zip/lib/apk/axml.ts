/**
 * Android binary XML (AXML) compiler.
 *
 * Compiles text XML (manifest, layouts) into the ResXMLTree format that the
 * Android framework parses at runtime. This is the same wire format produced
 * by aapt2 — chunk-for-chunk: string pool, resource map, namespace records,
 * and element records with typed attribute values.
 */

import { parseXml, type XmlElement } from '@/lib/apk/xmlParse'

/* ---------------------------------------------------------------- */
/* Android attribute resource ids (from android.R.attr, frozen API)  */
/* ---------------------------------------------------------------- */

const ANDROID_NS = 'http://schemas.android.com/apk/res/android'

export const ANDROID_ATTR_IDS: Record<string, number> = {
  theme: 0x01010000,
  label: 0x01010001,
  icon: 0x01010002,
  name: 0x01010003,
  permission: 0x01010006,
  debuggable: 0x0101000f,
  exported: 0x01010010,
  textSize: 0x01010095,
  textStyle: 0x01010097,
  textColor: 0x01010098,
  textColorHint: 0x01010099,
  ellipsize: 0x010100ab,
  gravity: 0x010100af,
  layout_gravity: 0x010100b3,
  orientation: 0x010100c4,
  id: 0x010100d0,
  background: 0x010100d4,
  padding: 0x010100d5,
  paddingLeft: 0x010100d6,
  paddingTop: 0x010100d7,
  paddingRight: 0x010100d8,
  paddingBottom: 0x010100d9,
  focusable: 0x010100da,
  visibility: 0x010100dc,
  layout_width: 0x010100f4,
  layout_height: 0x010100f5,
  layout_margin: 0x010100f6,
  layout_marginLeft: 0x010100f7,
  layout_marginTop: 0x010100f8,
  layout_marginRight: 0x010100f9,
  layout_marginBottom: 0x010100fa,
  maxLines: 0x01010154,
  minHeight: 0x01010140,
  minWidth: 0x0101013f,
  text: 0x0101014f,
  hint: 0x01010150,
  singleLine: 0x0101015d,
  layout_weight: 0x01010181,
  versionCode: 0x0101021b,
  versionName: 0x0101021c,
  minSdkVersion: 0x0101020c,
  inputType: 0x01010220,
  targetSdkVersion: 0x01010270,
  allowBackup: 0x01010280,
  lineSpacingExtra: 0x01010217,
  textAllCaps: 0x0101038c,
  letterSpacing: 0x01010165,
  alpha: 0x0101031f,
  enabled: 0x0101000e,
  clickable: 0x010100e5,
  scaleType: 0x010100fd,
  src: 0x01010119,
  contentDescription: 0x01010351,
  checked: 0x01010106,
}

/* ---------------------------------------------------------------- */
/* Typed values                                                      */
/* ---------------------------------------------------------------- */

const TYPE_REFERENCE = 0x01
const TYPE_STRING = 0x03
const TYPE_FLOAT = 0x04
const TYPE_DIMENSION = 0x05
const TYPE_INT_DEC = 0x10
const TYPE_INT_HEX = 0x11
const TYPE_INT_BOOLEAN = 0x12
const TYPE_INT_COLOR_ARGB8 = 0x1c
const TYPE_INT_COLOR_RGB8 = 0x1d

const UNIT_PX = 0
const UNIT_DIP = 1
const UNIT_SP = 2

/** Enum/flag values for common android attributes whose XML form is symbolic. */
const ENUM_VALUES: Record<string, Record<string, number>> = {
  orientation: { horizontal: 0, vertical: 1 },
  visibility: { visible: 0, invisible: 4, gone: 8 },
  textStyle: { normal: 0, bold: 1, italic: 2, 'bold|italic': 3 },
  gravity: {
    top: 0x30, bottom: 0x50, left: 0x03, right: 0x05, center_vertical: 0x10,
    center_horizontal: 0x01, center: 0x11, fill: 0x77, start: 0x00800003, end: 0x00800005,
  },
  layout_gravity: {
    top: 0x30, bottom: 0x50, left: 0x03, right: 0x05, center_vertical: 0x10,
    center_horizontal: 0x01, center: 0x11, fill: 0x77, start: 0x00800003, end: 0x00800005,
  },
  inputType: {
    none: 0, text: 0x1, textPassword: 0x81, textEmailAddress: 0x21,
    number: 0x2, phone: 0x3, textMultiLine: 0x20001, textPersonName: 0x61,
  },
  scaleType: { matrix: 0, fitXY: 1, fitStart: 2, fitCenter: 3, fitEnd: 4, center: 5, centerCrop: 6, centerInside: 7 },
  ellipsize: { none: 0, start: 1, middle: 2, end: 3, marquee: 4 },
}

interface TypedValue {
  dataType: number
  data: number
  /** Set when the raw string must also live in the string pool (TYPE_STRING). */
  stringValue: string | null
}

export interface AxmlWarning {
  message: string
  line: number
}

function encodeDimension(value: number, unit: number): number {
  // Integer mantissa, radix 23p0.
  return ((value & 0xffffff) << 8) | unit
}

function floatBits(value: number): number {
  const buf = new ArrayBuffer(4)
  new DataView(buf).setFloat32(0, value, true)
  return new DataView(buf).getUint32(0, true)
}

function parseTypedValue(attrName: string, raw: string, warnings: AxmlWarning[], line: number): TypedValue {
  // Symbolic enums for this attribute
  const enums = ENUM_VALUES[attrName]
  if (enums !== undefined) {
    if (raw in enums) return { dataType: TYPE_INT_DEC, data: enums[raw], stringValue: null }
    if (raw.includes('|')) {
      let combined = 0
      let ok = true
      for (const part of raw.split('|')) {
        const bit = enums[part.trim()]
        if (bit === undefined) { ok = false; break }
        combined |= bit
      }
      if (ok) return { dataType: TYPE_INT_HEX, data: combined >>> 0, stringValue: null }
    }
  }

  if (raw === 'match_parent' || raw === 'fill_parent') return { dataType: TYPE_INT_DEC, data: -1 >>> 0, stringValue: null }
  if (raw === 'wrap_content') return { dataType: TYPE_INT_DEC, data: -2 >>> 0, stringValue: null }
  if (raw === 'true') return { dataType: TYPE_INT_BOOLEAN, data: 0xffffffff, stringValue: null }
  if (raw === 'false') return { dataType: TYPE_INT_BOOLEAN, data: 0, stringValue: null }

  const dimMatch = /^(-?\d+(?:\.\d+)?)(dp|dip|sp|px)$/.exec(raw)
  if (dimMatch !== null) {
    const num = Math.round(Number.parseFloat(dimMatch[1]))
    const unit = dimMatch[2] === 'sp' ? UNIT_SP : dimMatch[2] === 'px' ? UNIT_PX : UNIT_DIP
    return { dataType: TYPE_DIMENSION, data: encodeDimension(num, unit), stringValue: null }
  }

  const colorMatch = /^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.exec(raw)
  if (colorMatch !== null) {
    const hex = colorMatch[1]
    if (hex.length === 6) {
      return { dataType: TYPE_INT_COLOR_RGB8, data: (0xff000000 | Number.parseInt(hex, 16)) >>> 0, stringValue: null }
    }
    return { dataType: TYPE_INT_COLOR_ARGB8, data: Number.parseInt(hex, 16) >>> 0, stringValue: null }
  }

  if (raw.startsWith('@id/') || raw.startsWith('@+id/')) {
    // Local view ids are not needed by the runtime shell; encode a stable
    // reference into the app id space so the XML stays structurally valid.
    warnings.push({ message: `View id "${raw}" encoded as raw reference (no R.id table in web build)`, line })
    return { dataType: TYPE_REFERENCE, data: 0x7f0f0000 + hashName(raw), stringValue: null }
  }
  if (raw.startsWith('@')) {
    warnings.push({ message: `Resource reference "${raw}" is not resolvable in the web build; encoded as string`, line })
    return { dataType: TYPE_STRING, data: -1, stringValue: raw }
  }

  const intMatch = /^-?\d+$/.exec(raw)
  if (intMatch !== null && attrName !== 'versionName' && attrName !== 'text' && attrName !== 'label') {
    return { dataType: TYPE_INT_DEC, data: Number.parseInt(raw, 10) >>> 0, stringValue: null }
  }
  const floatMatch = /^-?\d+\.\d+$/.exec(raw)
  if (floatMatch !== null) {
    return { dataType: TYPE_FLOAT, data: floatBits(Number.parseFloat(raw)), stringValue: null }
  }

  return { dataType: TYPE_STRING, data: -1, stringValue: raw }
}

function hashName(name: string): number {
  let hash = 0
  for (let i = 0; i < name.length; i += 1) hash = (hash * 31 + name.charCodeAt(i)) & 0xfff
  return hash
}

/* ---------------------------------------------------------------- */
/* String pool                                                       */
/* ---------------------------------------------------------------- */

class StringPool {
  private strings: string[] = []
  private index = new Map<string, number>()

  /** Adds a string (idempotent) and returns its index. */
  add(value: string): number {
    const existing = this.index.get(value)
    if (existing !== undefined) return existing
    const idx = this.strings.length
    this.strings.push(value)
    this.index.set(value, idx)
    return idx
  }

  get(value: string): number {
    const idx = this.index.get(value)
    if (idx === undefined) throw new Error(`String not in pool: ${value}`)
    return idx
  }

  get count(): number {
    return this.strings.length
  }

  /** Serializes as a UTF-16 ResStringPool chunk. */
  toChunk(): Uint8Array {
    const encoded: Uint8Array[] = []
    const offsets: number[] = []
    let dataLen = 0
    for (const value of this.strings) {
      offsets.push(dataLen)
      const units = value.length
      const bytes = new Uint8Array(4 + units * 2)
      const view = new DataView(bytes.buffer)
      view.setUint16(0, units, true)
      for (let i = 0; i < units; i += 1) view.setUint16(2 + i * 2, value.charCodeAt(i), true)
      view.setUint16(2 + units * 2, 0, true)
      encoded.push(bytes)
      dataLen += bytes.length
    }
    const padding = (4 - (dataLen % 4)) % 4
    dataLen += padding

    const headerSize = 28
    const offsetsSize = this.strings.length * 4
    const total = headerSize + offsetsSize + dataLen
    const out = new Uint8Array(total)
    const view = new DataView(out.buffer)
    view.setUint16(0, 0x0001, true) // RES_STRING_POOL_TYPE
    view.setUint16(2, headerSize, true)
    view.setUint32(4, total, true)
    view.setUint32(8, this.strings.length, true)
    view.setUint32(12, 0, true) // styleCount
    view.setUint32(16, 0, true) // flags: UTF-16
    view.setUint32(20, headerSize + offsetsSize, true) // stringsStart
    view.setUint32(24, 0, true) // stylesStart
    for (let i = 0; i < offsets.length; i += 1) view.setUint32(headerSize + i * 4, offsets[i], true)
    let cursor = headerSize + offsetsSize
    for (const bytes of encoded) {
      out.set(bytes, cursor)
      cursor += bytes.length
    }
    return out
  }
}

/* ---------------------------------------------------------------- */
/* AXML serialization                                                */
/* ---------------------------------------------------------------- */

interface AttrRecord {
  nsIdx: number
  nameIdx: number
  rawIdx: number
  dataType: number
  data: number
  resourceId: number
}

interface ElementNode {
  nameIdx: number
  attrs: AttrRecord[]
  children: ElementNode[]
  line: number
}

export interface AxmlResult {
  bytes: Uint8Array
  warnings: AxmlWarning[]
}

/**
 * Compiles XML text into Android binary XML.
 * Unknown android: attributes are dropped with a warning (aapt2 would reject
 * them; the web toolchain degrades gracefully but reports every drop).
 */
export function compileAxml(xmlSource: string): AxmlResult {
  const root = parseXml(xmlSource)
  const warnings: AxmlWarning[] = []
  const pool = new StringPool()

  // Pass 1: collect android attribute names actually used, in stable resource-id
  // order. These MUST be the first pool entries, mirrored by the resource map.
  const usedAndroidAttrs = new Set<string>()
  collectAndroidAttrs(root, usedAndroidAttrs, warnings)
  const sortedAttrNames = [...usedAndroidAttrs].sort((a, b) => ANDROID_ATTR_IDS[a] - ANDROID_ATTR_IDS[b])
  for (const name of sortedAttrNames) pool.add(name)
  const resourceMap = sortedAttrNames.map((name) => ANDROID_ATTR_IDS[name])

  const nsUriIdx = pool.add(ANDROID_NS)
  const nsPrefixIdx = pool.add('android')

  // Pass 2: build element tree with typed values, interning remaining strings.
  const rootNode = buildElement(root, pool, warnings)

  // Serialize chunks.
  const chunks: Uint8Array[] = []
  chunks.push(pool.toChunk())
  chunks.push(resourceMapChunk(resourceMap))
  chunks.push(namespaceChunk(0x0100, nsPrefixIdx, nsUriIdx))
  serializeElement(rootNode, nsUriIdx, chunks)
  chunks.push(namespaceChunk(0x0101, nsPrefixIdx, nsUriIdx))

  let bodyLen = 0
  for (const chunk of chunks) bodyLen += chunk.length
  const out = new Uint8Array(8 + bodyLen)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0003, true) // RES_XML_TYPE
  view.setUint16(2, 8, true)
  view.setUint32(4, out.length, true)
  let cursor = 8
  for (const chunk of chunks) {
    out.set(chunk, cursor)
    cursor += chunk.length
  }
  return { bytes: out, warnings }

  function buildElement(el: XmlElement, sp: StringPool, warns: AxmlWarning[]): ElementNode {
    const attrs: AttrRecord[] = []
    for (const [key, raw] of Object.entries(el.attrs)) {
      if (key.startsWith('xmlns')) continue
      if (key.startsWith('android:')) {
        const short = key.slice('android:'.length)
        const resId = ANDROID_ATTR_IDS[short]
        if (resId === undefined) continue // already warned in pass 1
        const typed = parseTypedValue(short, raw, warns, el.line)
        const rawIdx = typed.stringValue !== null ? sp.add(typed.stringValue) : -1
        attrs.push({
          nsIdx: nsUriIdx,
          nameIdx: sp.get(short),
          rawIdx,
          dataType: typed.dataType,
          data: typed.stringValue !== null ? rawIdx : typed.data,
          resourceId: resId,
        })
      } else if (!key.includes(':')) {
        // Non-namespaced attribute (e.g. package, platformBuildVersionCode)
        const typed = parseTypedValue(key, raw, warns, el.line)
        const nameIdx = sp.add(key)
        const rawIdx = typed.stringValue !== null ? sp.add(typed.stringValue) : -1
        attrs.push({
          nsIdx: -1,
          nameIdx,
          rawIdx,
          dataType: typed.dataType,
          data: typed.stringValue !== null ? rawIdx : typed.data,
          resourceId: 0,
        })
      } else {
        warns.push({ message: `Attribute "${key}" uses an unsupported namespace and was dropped`, line: el.line })
      }
    }
    // Framework requires android attributes sorted by resource id.
    attrs.sort((a, b) => {
      if (a.resourceId !== 0 && b.resourceId !== 0) return a.resourceId - b.resourceId
      if (a.resourceId !== 0) return -1
      if (b.resourceId !== 0) return 1
      return a.nameIdx - b.nameIdx
    })
    const nameIdx = sp.add(el.tag)
    return { nameIdx, attrs, children: el.children.map((child) => buildElement(child, sp, warns)), line: el.line }
  }

  function serializeElement(node: ElementNode, _nsIdx: number, sink: Uint8Array[]): void {
    sink.push(startElementChunk(node))
    for (const child of node.children) serializeElement(child, _nsIdx, sink)
    sink.push(endElementChunk(node.nameIdx))
  }
}

function collectAndroidAttrs(el: XmlElement, out: Set<string>, warnings: AxmlWarning[]): void {
  for (const key of Object.keys(el.attrs)) {
    if (key.startsWith('android:')) {
      const short = key.slice('android:'.length)
      if (ANDROID_ATTR_IDS[short] !== undefined) out.add(short)
      else warnings.push({ message: `Unknown android attribute "android:${short}" was dropped`, line: el.line })
    }
  }
  for (const child of el.children) collectAndroidAttrs(child, out, warnings)
}

function resourceMapChunk(ids: number[]): Uint8Array {
  const out = new Uint8Array(8 + ids.length * 4)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0180, true) // RES_XML_RESOURCE_MAP_TYPE
  view.setUint16(2, 8, true)
  view.setUint32(4, out.length, true)
  for (let i = 0; i < ids.length; i += 1) view.setUint32(8 + i * 4, ids[i], true)
  return out
}

function namespaceChunk(type: number, prefixIdx: number, uriIdx: number): Uint8Array {
  const out = new Uint8Array(24)
  const view = new DataView(out.buffer)
  view.setUint16(0, type, true)
  view.setUint16(2, 16, true)
  view.setUint32(4, 24, true)
  view.setUint32(8, 1, true) // line number
  view.setInt32(12, -1, true) // comment
  view.setUint32(16, prefixIdx, true)
  view.setUint32(20, uriIdx, true)
  return out
}

function startElementChunk(node: ElementNode): Uint8Array {
  const attrCount = node.attrs.length
  const out = new Uint8Array(36 + attrCount * 20)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0102, true) // RES_XML_START_ELEMENT_TYPE
  view.setUint16(2, 16, true)
  view.setUint32(4, out.length, true)
  view.setUint32(8, node.line, true)
  view.setInt32(12, -1, true) // comment
  view.setInt32(16, -1, true) // ns (element itself is unqualified)
  view.setUint32(20, node.nameIdx, true)
  view.setUint16(24, 20, true) // attributeStart
  view.setUint16(26, 20, true) // attributeSize
  view.setUint16(28, attrCount, true)
  view.setUint16(30, 0, true) // idIndex
  view.setUint16(32, 0, true) // classIndex
  view.setUint16(34, 0, true) // styleIndex
  let cursor = 36
  for (const attr of node.attrs) {
    view.setInt32(cursor, attr.nsIdx, true)
    view.setUint32(cursor + 4, attr.nameIdx, true)
    view.setInt32(cursor + 8, attr.rawIdx, true)
    view.setUint16(cursor + 12, 8, true) // typedValue size
    view.setUint8(cursor + 14, 0) // res0
    view.setUint8(cursor + 15, attr.dataType)
    view.setUint32(cursor + 16, attr.data >>> 0, true)
    cursor += 20
  }
  return out
}

function endElementChunk(nameIdx: number): Uint8Array {
  const out = new Uint8Array(24)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0103, true) // RES_XML_END_ELEMENT_TYPE
  view.setUint16(2, 16, true)
  view.setUint32(4, 24, true)
  view.setUint32(8, 1, true)
  view.setInt32(12, -1, true)
  view.setInt32(16, -1, true)
  view.setUint32(20, nameIdx, true)
  return out
}
