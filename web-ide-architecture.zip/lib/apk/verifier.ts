/**
 * FinalAPKVerifier — structural verification of the signed APK before export.
 *
 * Re-parses the finished archive from raw bytes (not from the builder's
 * in-memory state) so a packaging bug cannot self-certify. Checks:
 *   - zip central directory integrity + per-entry CRC32
 *   - required entries present (manifest, arsc, dex, layout, META-INF/*)
 *   - AndroidManifest.xml is binary AXML (magic 0x00080003)
 *   - resources.arsc is a resource table (magic 0x0002) and 4-byte aligned
 *   - classes.dex has the dex magic and its declared file size matches
 *   - APK Signing Block v2 present between contents and central directory
 *   - overall size sanity
 */

import { readZip, crc32 } from '@/lib/apk/zip'

export interface VerifyCheck {
  id: string
  label: string
  ok: boolean
  detail: string
}

export interface VerifyResult {
  ok: boolean
  checks: VerifyCheck[]
}

const REQUIRED_ENTRIES = [
  'AndroidManifest.xml',
  'resources.arsc',
  'classes.dex',
  'res/layout/activity_main.xml',
  'META-INF/MANIFEST.MF',
  'META-INF/CERT.SF',
  'META-INF/CERT.RSA',
]

const DEX_MAGIC = [0x64, 0x65, 0x78, 0x0a, 0x30, 0x33, 0x35, 0x00]

function readU32le(bytes: Uint8Array, offset: number): number {
  return new DataView(bytes.buffer, bytes.byteOffset + offset, 4).getUint32(0, true)
}

function readU16le(bytes: Uint8Array, offset: number): number {
  return new DataView(bytes.buffer, bytes.byteOffset + offset, 2).getUint16(0, true)
}

/** Verifies the final APK from raw bytes. Never throws — reports failed checks. */
export function verifyApk(apkBytes: Uint8Array): VerifyResult {
  const checks: VerifyCheck[] = []
  const push = (id: string, label: string, ok: boolean, detail: string): void => {
    checks.push({ id, label, ok, detail })
  }

  // 0. Size sanity
  push(
    'size',
    'APK size sanity',
    apkBytes.length >= 4096,
    `${(apkBytes.length / 1024).toFixed(1)} KiB (${apkBytes.length} bytes)`,
  )

  // 1. Parse zip
  let entries: ReturnType<typeof readZip>['entries'] = []
  let centralDirOffset = 0
  try {
    const parsed = readZip(apkBytes)
    entries = parsed.entries
    centralDirOffset = parsed.centralDirOffset
    push('zip', 'ZIP central directory', true, `${entries.length} entries`)
  } catch (error) {
    push('zip', 'ZIP central directory', false, error instanceof Error ? error.message : String(error))
    return { ok: false, checks }
  }

  const byName = new Map(entries.map((entry) => [entry.name, entry]))

  // 2. Required entries
  for (const name of REQUIRED_ENTRIES) {
    const entry = byName.get(name)
    push(
      `entry:${name}`,
      `Entry ${name}`,
      entry !== undefined,
      entry ? `${entry.size} bytes @ ${entry.dataOffset}` : 'missing',
    )
  }

  // 3. CRC integrity of every entry (all entries are STORED)
  let crcFailures = 0
  for (const entry of entries) {
    if (entry.method !== 0) continue
    if (crc32(entry.data) !== entry.crc) crcFailures += 1
  }
  push('crc', 'Entry CRC32 integrity', crcFailures === 0, crcFailures === 0 ? `${entries.length} entries verified` : `${crcFailures} corrupt entries`)

  // 4. Manifest is binary AXML
  const manifest = byName.get('AndroidManifest.xml')
  if (manifest && manifest.data.length >= 8) {
    const magic = readU32le(manifest.data, 0)
    const declaredSize = readU32le(manifest.data, 4)
    const ok = magic === 0x00080003 && declaredSize === manifest.data.length
    push('axml', 'Manifest binary AXML', ok, ok ? `magic 0x00080003, ${manifest.data.length} bytes` : `magic 0x${magic.toString(16)}, declared ${declaredSize} vs actual ${manifest.data.length}`)
  } else {
    push('axml', 'Manifest binary AXML', false, 'manifest missing or truncated')
  }

  // 5. resources.arsc: table magic + 4-byte alignment (required for stored arsc)
  const arsc = byName.get('resources.arsc')
  if (arsc && arsc.data.length >= 8) {
    const type = readU16le(arsc.data, 0)
    const declaredSize = readU32le(arsc.data, 4)
    const aligned = arsc.dataOffset % 4 === 0
    const ok = type === 0x0002 && declaredSize === arsc.data.length && aligned
    push('arsc', 'Resource table + alignment', ok, ok ? `RES_TABLE, offset ${arsc.dataOffset} (4-aligned)` : `type 0x${type.toString(16)}, offset ${arsc.dataOffset}${aligned ? '' : ' (MISALIGNED)'}, declared ${declaredSize} vs ${arsc.data.length}`)
  } else {
    push('arsc', 'Resource table + alignment', false, 'resources.arsc missing or truncated')
  }

  // 6. classes.dex: magic + declared file size
  const dex = byName.get('classes.dex')
  if (dex && dex.data.length >= 0x70) {
    const magicOk = DEX_MAGIC.every((byte, i) => dex.data[i] === byte)
    const declaredSize = readU32le(dex.data, 32) // file_size field in dex header
    const ok = magicOk && declaredSize === dex.data.length
    push('dex', 'Valid dex header', ok, ok ? `dex035, ${dex.data.length} bytes` : `magicOk=${magicOk}, declared ${declaredSize} vs actual ${dex.data.length}`)
  } else {
    push('dex', 'Valid dex header', false, 'classes.dex missing or truncated')
  }

  // 7. Layout AXML entries
  for (const entry of entries) {
    if (!entry.name.startsWith('res/layout/')) continue
    const magic = entry.data.length >= 4 ? readU32le(entry.data, 0) : 0
    push(`layout:${entry.name}`, `Layout AXML ${entry.name}`, magic === 0x00080003, magic === 0x00080003 ? `${entry.data.length} bytes` : `bad magic 0x${magic.toString(16)}`)
  }

  // 8. APK Signing Block v2 directly before central directory
  let v2Found = false
  let v2Detail = 'not found before central directory'
  if (centralDirOffset >= 24) {
    // Trailer: uint64 size + magic "APK Sig Block 42" (16 bytes) ends at centralDirOffset
    const magicStart = centralDirOffset - 16
    const magicText = new TextDecoder().decode(apkBytes.subarray(magicStart, centralDirOffset))
    if (magicText === 'APK Sig Block 42') {
      const sizeLo = readU32le(apkBytes, magicStart - 8)
      const blockSize = sizeLo // block sizes here are < 4 GiB; high word unused
      const blockStart = centralDirOffset - 8 - blockSize
      if (blockStart >= 0) {
        const headerSize = readU32le(apkBytes, blockStart)
        v2Found = headerSize === blockSize
        v2Detail = v2Found ? `${blockSize + 8} bytes @ ${blockStart}` : `size mismatch header=${headerSize} footer=${blockSize}`
      }
    }
  }
  push('v2sig', 'APK Signing Block (v2)', v2Found, v2Detail)

  // 9. v1 signature files reference every non-META-INF entry
  const manifestMf = byName.get('META-INF/MANIFEST.MF')
  if (manifestMf) {
    const text = new TextDecoder().decode(manifestMf.data)
    const missing = entries
      .filter((entry) => !entry.name.startsWith('META-INF/'))
      .filter((entry) => !text.includes(`Name: ${entry.name}`))
    push('v1sig', 'v1 manifest covers all entries', missing.length === 0, missing.length === 0 ? 'all entries digested' : `missing: ${missing.map((m) => m.name).join(', ')}`)
  } else {
    push('v1sig', 'v1 manifest covers all entries', false, 'META-INF/MANIFEST.MF missing')
  }

  return { ok: checks.every((check) => check.ok), checks }
}
