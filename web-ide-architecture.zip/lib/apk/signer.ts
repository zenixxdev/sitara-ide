/**
 * SigningEngine — real APK signing.
 *
 * v1 (JAR): MANIFEST.MF / CERT.SF with SHA-256 digests + CERT.RSA PKCS#7
 *           detached signature (node-forge, SHA256withRSA).
 * v2 (APK Signature Scheme v2): chunked SHA-256 digests over the three zip
 *           sections, RSASSA-PKCS1-v1_5 signature via WebCrypto, and the
 *           "APK Sig Block 42" inserted before the central directory.
 *
 * The debug keypair (2048-bit RSA, self-signed cert, 30y validity) is
 * generated once and cached so repeat builds are fast and consistently keyed
 * (Android requires identical signatures across reinstalls).
 */

import forge from 'node-forge'
import { writeZip, type ZipEntrySpec } from '@/lib/apk/zip'

const KEY_STORAGE = 'sitara_debug_keystore_v1'

export interface DebugKeystore {
  privateKeyPem: string
  certPem: string
}

let cachedKeystore: DebugKeystore | null = null

/** Generates (or loads) the persistent debug keystore. */
export function getDebugKeystore(log?: (text: string) => void): DebugKeystore {
  if (cachedKeystore !== null) return cachedKeystore
  if (typeof localStorage !== 'undefined') {
    const raw = localStorage.getItem(KEY_STORAGE)
    if (raw !== null) {
      try {
        const parsed = JSON.parse(raw) as DebugKeystore
        forge.pki.privateKeyFromPem(parsed.privateKeyPem)
        forge.pki.certificateFromPem(parsed.certPem)
        cachedKeystore = parsed
        log?.('Loaded cached debug keystore (RSA-2048)')
        return parsed
      } catch {
        localStorage.removeItem(KEY_STORAGE)
      }
    }
  }

  log?.('Generating debug keystore: RSA-2048 self-signed certificate…')
  const keys = forge.pki.rsa.generateKeyPair({ bits: 2048, e: 0x10001 })
  const cert = forge.pki.createCertificate()
  cert.publicKey = keys.publicKey
  cert.serialNumber = `${Date.now()}`
  cert.validity.notBefore = new Date()
  cert.validity.notAfter = new Date(Date.now() + 30 * 365 * 24 * 3600 * 1000)
  const attrs = [
    { name: 'commonName', value: 'Sitara Debug' },
    { name: 'organizationName', value: 'Sitara Web IDE' },
    { shortName: 'OU', value: 'Debug' },
  ]
  cert.setSubject(attrs)
  cert.setIssuer(attrs)
  cert.sign(keys.privateKey, forge.md.sha256.create())

  const keystore: DebugKeystore = {
    privateKeyPem: forge.pki.privateKeyToPem(keys.privateKey),
    certPem: forge.pki.certificateToPem(cert),
  }
  cachedKeystore = keystore
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(KEY_STORAGE, JSON.stringify(keystore))
  }
  return keystore
}

/* --------------------------- helpers --------------------------- */

function bytesToForgeBuffer(bytes: Uint8Array): string {
  let out = ''
  for (let i = 0; i < bytes.length; i += 1) out += String.fromCharCode(bytes[i])
  return out
}

function forgeBufferToBytes(buffer: string): Uint8Array {
  const out = new Uint8Array(buffer.length)
  for (let i = 0; i < buffer.length; i += 1) out[i] = buffer.charCodeAt(i)
  return out
}

async function sha256(data: Uint8Array): Promise<Uint8Array> {
  const buf = new ArrayBuffer(data.length)
  new Uint8Array(buf).set(data)
  const digest = await globalThis.crypto.subtle.digest('SHA-256', buf)
  return new Uint8Array(digest)
}

function base64(bytes: Uint8Array): string {
  return forge.util.encode64(bytesToForgeBuffer(bytes))
}

const textEncoder = new TextEncoder()

/* --------------------------- v1 (JAR) --------------------------- */

interface V1Files {
  manifestMf: Uint8Array
  certSf: Uint8Array
  certRsa: Uint8Array
}

async function buildV1Files(entries: ZipEntrySpec[], keystore: DebugKeystore): Promise<V1Files> {
  const mfHeader = 'Manifest-Version: 1.0\r\nCreated-By: Sitara Web IDE (sitara-apk-signer 1.0)\r\n\r\n'
  const sections: string[] = []
  for (const entry of entries) {
    const digest = base64(await sha256(entry.data))
    sections.push(`Name: ${entry.name}\r\nSHA-256-Digest: ${digest}\r\n\r\n`)
  }
  const manifestText = mfHeader + sections.join('')
  const manifestMf = textEncoder.encode(manifestText)

  // CERT.SF: digest of whole manifest + digest of each manifest section.
  const mfDigest = base64(await sha256(manifestMf))
  let sfText =
    'Signature-Version: 1.0\r\n' +
    `SHA-256-Digest-Manifest: ${mfDigest}\r\n` +
    'Created-By: Sitara Web IDE (sitara-apk-signer 1.0)\r\nX-Android-APK-Signed: 2\r\n\r\n'
  for (let i = 0; i < entries.length; i += 1) {
    const sectionDigest = base64(await sha256(textEncoder.encode(sections[i])))
    sfText += `Name: ${entries[i].name}\r\nSHA-256-Digest: ${sectionDigest}\r\n\r\n`
  }
  const certSf = textEncoder.encode(sfText)

  // CERT.RSA: PKCS#7 detached signature over CERT.SF.
  const privateKey = forge.pki.privateKeyFromPem(keystore.privateKeyPem)
  const cert = forge.pki.certificateFromPem(keystore.certPem)
  const p7 = forge.pkcs7.createSignedData()
  p7.content = forge.util.createBuffer(bytesToForgeBuffer(certSf))
  p7.addCertificate(cert)
  p7.addSigner({
    key: privateKey,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha256,
  })
  p7.sign({ detached: true })
  const certRsa = forgeBufferToBytes(forge.asn1.toDer(p7.toAsn1()).getBytes())

  return { manifestMf, certSf, certRsa }
}

/* ----------------------- v2 (APK Sig Scheme) ----------------------- */

const V2_BLOCK_ID = 0x7109871a
const SIG_RSA_PKCS1_SHA256 = 0x0103
const CHUNK_SIZE = 1024 * 1024

function u32le(value: number): Uint8Array {
  const out = new Uint8Array(4)
  new DataView(out.buffer).setUint32(0, value, true)
  return out
}

function u64le(value: number): Uint8Array {
  const out = new Uint8Array(8)
  const view = new DataView(out.buffer)
  view.setUint32(0, value >>> 0, true)
  view.setUint32(4, Math.floor(value / 0x100000000), true)
  return out
}

function lenPrefixed(data: Uint8Array): Uint8Array {
  const out = new Uint8Array(4 + data.length)
  out.set(u32le(data.length), 0)
  out.set(data, 4)
  return out
}

function concat(parts: Uint8Array[]): Uint8Array {
  let total = 0
  for (const part of parts) total += part.length
  const out = new Uint8Array(total)
  let cursor = 0
  for (const part of parts) {
    out.set(part, cursor)
    cursor += part.length
  }
  return out
}

/** APK Sig Scheme v2 chunked digest: 0xa5-prefixed chunks, 0x5a-prefixed root. */
async function chunkedDigest(sections: Uint8Array[]): Promise<Uint8Array> {
  const chunkDigests: Uint8Array[] = []
  for (const section of sections) {
    for (let pos = 0; pos < section.length; pos += CHUNK_SIZE) {
      const chunk = section.subarray(pos, Math.min(pos + CHUNK_SIZE, section.length))
      const prefixed = new Uint8Array(5 + chunk.length)
      prefixed[0] = 0xa5
      prefixed.set(u32le(chunk.length), 1)
      prefixed.set(chunk, 5)
      chunkDigests.push(await sha256(prefixed))
    }
    if (section.length === 0) {
      const prefixed = new Uint8Array(5)
      prefixed[0] = 0xa5
      chunkDigests.push(await sha256(prefixed))
    }
  }
  const root = new Uint8Array(5 + chunkDigests.length * 32)
  root[0] = 0x5a
  root.set(u32le(chunkDigests.length), 1)
  chunkDigests.forEach((digest, i) => root.set(digest, 5 + i * 32))
  return sha256(root)
}

async function importSigningKey(keystore: DebugKeystore): Promise<CryptoKey> {
  const privateKey = forge.pki.privateKeyFromPem(keystore.privateKeyPem)
  const pkcs8Asn1 = forge.pki.wrapRsaPrivateKey(forge.pki.privateKeyToAsn1(privateKey))
  const pkcs8Der = forgeBufferToBytes(forge.asn1.toDer(pkcs8Asn1).getBytes())
  const buf = new ArrayBuffer(pkcs8Der.length)
  new Uint8Array(buf).set(pkcs8Der)
  return globalThis.crypto.subtle.importKey(
    'pkcs8',
    buf,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign'],
  )
}

function certDer(keystore: DebugKeystore): Uint8Array {
  const cert = forge.pki.certificateFromPem(keystore.certPem)
  return forgeBufferToBytes(forge.asn1.toDer(forge.pki.certificateToAsn1(cert)).getBytes())
}

function publicKeyDer(keystore: DebugKeystore): Uint8Array {
  const cert = forge.pki.certificateFromPem(keystore.certPem)
  return forgeBufferToBytes(forge.asn1.toDer(forge.pki.publicKeyToAsn1(cert.publicKey as forge.pki.rsa.PublicKey)).getBytes())
}

async function buildV2Block(
  contents: Uint8Array,
  centralDir: Uint8Array,
  eocdForDigest: Uint8Array,
  keystore: DebugKeystore,
): Promise<Uint8Array> {
  const apkDigest = await chunkedDigest([contents, centralDir, eocdForDigest])

  // signed data
  const digestRecord = lenPrefixed(concat([u32le(SIG_RSA_PKCS1_SHA256), lenPrefixed(apkDigest)]))
  const digestsSeq = lenPrefixed(digestRecord)
  const certsSeq = lenPrefixed(lenPrefixed(certDer(keystore)))
  const attrsSeq = lenPrefixed(new Uint8Array(0))
  const signedData = concat([digestsSeq, certsSeq, attrsSeq])

  // signature over signed data
  const key = await importSigningKey(keystore)
  const sdBuf = new ArrayBuffer(signedData.length)
  new Uint8Array(sdBuf).set(signedData)
  const sigRaw = new Uint8Array(await globalThis.crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, sdBuf))
  const signatureRecord = lenPrefixed(concat([u32le(SIG_RSA_PKCS1_SHA256), lenPrefixed(sigRaw)]))
  const signaturesSeq = lenPrefixed(signatureRecord)

  const signer = concat([lenPrefixed(signedData), signaturesSeq, lenPrefixed(publicKeyDer(keystore))])
  const signersSeq = lenPrefixed(lenPrefixed(signer))

  // signing block
  const pairValue = signersSeq
  const pairLen = 4 + pairValue.length // id + value
  const blockPayload = concat([u64le(pairLen), u32le(V2_BLOCK_ID), pairValue])
  const blockSize = blockPayload.length + 8 + 16 // payload + trailing size + magic
  const magic = textEncoder.encode('APK Sig Block 42')
  return concat([u64le(blockSize), blockPayload, u64le(blockSize), magic])
}

/* --------------------------- public API --------------------------- */

export interface SignedApk {
  bytes: Uint8Array
  certSha256: string
}

/**
 * Packages entries into an aligned zip and applies v1 + v2 signatures.
 * Returns the final installable APK bytes.
 */
export async function packageAndSign(
  entries: ZipEntrySpec[],
  keystore: DebugKeystore,
  log: (text: string) => void,
): Promise<SignedApk> {
  // --- v1: digest files + signature entries appended to the archive ---
  log(`v1: hashing ${entries.length} entries (SHA-256) for MANIFEST.MF`)
  const v1 = await buildV1Files(entries, keystore)
  const allEntries: ZipEntrySpec[] = [
    ...entries,
    { name: 'META-INF/MANIFEST.MF', data: v1.manifestMf },
    { name: 'META-INF/CERT.SF', data: v1.certSf },
    { name: 'META-INF/CERT.RSA', data: v1.certRsa },
  ]
  log('v1: CERT.SF + CERT.RSA (PKCS#7, SHA256withRSA) generated')

  // --- base zip ---
  const zip = writeZip(allEntries)
  const contents = zip.bytes.subarray(0, zip.centralDirOffset)
  const centralDir = zip.bytes.subarray(zip.centralDirOffset, zip.eocdOffset)
  const eocd = zip.bytes.subarray(zip.eocdOffset)

  // --- v2: EOCD copy with CD offset pointing at the signing block start ---
  const eocdForDigest = new Uint8Array(eocd)
  new DataView(eocdForDigest.buffer).setUint32(16, zip.centralDirOffset, true)
  log('v2: computing chunked SHA-256 digests over zip sections')
  const signingBlock = await buildV2Block(contents, centralDir, eocdForDigest, keystore)
  log(`v2: APK Signing Block ready (${signingBlock.length} bytes, RSASSA-PKCS1-v1_5)`)

  // --- final assembly: contents | signing block | central dir | patched EOCD ---
  const finalEocd = new Uint8Array(eocd)
  new DataView(finalEocd.buffer).setUint32(16, zip.centralDirOffset + signingBlock.length, true)
  const finalBytes = concat([contents, signingBlock, centralDir, finalEocd])

  const certFingerprint = await sha256(certDer(keystore))
  const certSha256 = Array.from(certFingerprint)
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join(':')
    .toUpperCase()

  return { bytes: finalBytes, certSha256 }
}
