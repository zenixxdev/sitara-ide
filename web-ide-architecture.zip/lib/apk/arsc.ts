/**
 * resources.arsc builder.
 *
 * Emits a real ResTable with one package (0x7f) and one type ("layout").
 * Every layout in the virtual project becomes an entry whose value is a
 * TYPE_STRING pointing at its compiled binary XML path inside the APK.
 *
 * Entry 0 of type 1 is ALWAYS res/layout/activity_main.xml, which yields
 * resource id 0x7f010000 — the exact constant compiled into the runtime dex
 * (see runtimeDex.ts), so setContentView() resolves at runtime.
 */

function utf16PoolChunk(strings: string[]): Uint8Array {
  const encoded: Uint8Array[] = []
  const offsets: number[] = []
  let dataLen = 0
  for (const value of strings) {
    offsets.push(dataLen)
    const bytes = new Uint8Array(4 + value.length * 2)
    const view = new DataView(bytes.buffer)
    view.setUint16(0, value.length, true)
    for (let i = 0; i < value.length; i += 1) view.setUint16(2 + i * 2, value.charCodeAt(i), true)
    encoded.push(bytes)
    dataLen += bytes.length
  }
  const padding = (4 - (dataLen % 4)) % 4
  dataLen += padding
  const headerSize = 28
  const offsetsSize = strings.length * 4
  const total = headerSize + offsetsSize + dataLen
  const out = new Uint8Array(total)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0001, true)
  view.setUint16(2, headerSize, true)
  view.setUint32(4, total, true)
  view.setUint32(8, strings.length, true)
  view.setUint32(12, 0, true)
  view.setUint32(16, 0, true) // UTF-16
  view.setUint32(20, headerSize + offsetsSize, true)
  view.setUint32(24, 0, true)
  for (let i = 0; i < offsets.length; i += 1) view.setUint32(headerSize + i * 4, offsets[i], true)
  let cursor = headerSize + offsetsSize
  for (const bytes of encoded) {
    out.set(bytes, cursor)
    cursor += bytes.length
  }
  return out
}

export interface ArscLayoutEntry {
  /** Entry key, e.g. "activity_main". */
  name: string
  /** APK path of the compiled binary XML, e.g. "res/layout/activity_main.xml". */
  apkPath: string
}

export interface ArscResult {
  bytes: Uint8Array
  /** Resource id assigned to each layout entry, keyed by entry name. */
  ids: Record<string, number>
}

/** Builds resources.arsc. `layouts[0]` MUST be activity_main. */
export function buildArsc(packageName: string, layouts: ArscLayoutEntry[]): ArscResult {
  if (layouts.length === 0 || layouts[0].name !== 'activity_main') {
    throw new Error('buildArsc: layouts[0] must be activity_main (runtime dex depends on id 0x7f010000)')
  }

  // Global value strings: the file paths referenced by layout entries.
  const globalStrings = layouts.map((layout) => layout.apkPath)
  const globalPool = utf16PoolChunk(globalStrings)
  const typePool = utf16PoolChunk(['layout'])
  const keyPool = utf16PoolChunk(layouts.map((layout) => layout.name))

  // --- TypeSpec chunk (type id 1 = layout) ---
  const typeSpec = new Uint8Array(16 + layouts.length * 4)
  {
    const view = new DataView(typeSpec.buffer)
    view.setUint16(0, 0x0202, true) // RES_TABLE_TYPE_SPEC_TYPE
    view.setUint16(2, 16, true)
    view.setUint32(4, typeSpec.length, true)
    view.setUint8(8, 1) // type id
    view.setUint8(9, 0)
    view.setUint16(10, 0, true)
    view.setUint32(12, layouts.length, true)
    // per-entry spec flags stay 0 (no config variants)
  }

  // --- Type chunk with default config ---
  const CONFIG_SIZE = 56
  const typeHeaderSize = 20 + CONFIG_SIZE
  const entrySize = 8 + 8 // ResTable_entry + Res_value
  const typeChunkLen = typeHeaderSize + layouts.length * 4 + layouts.length * entrySize
  const typeChunk = new Uint8Array(typeChunkLen)
  {
    const view = new DataView(typeChunk.buffer)
    view.setUint16(0, 0x0201, true) // RES_TABLE_TYPE_TYPE
    view.setUint16(2, typeHeaderSize, true)
    view.setUint32(4, typeChunkLen, true)
    view.setUint8(8, 1) // type id
    view.setUint8(9, 0) // flags
    view.setUint16(10, 0, true)
    view.setUint32(12, layouts.length, true)
    view.setUint32(16, typeHeaderSize + layouts.length * 4, true) // entriesStart
    view.setUint32(20, CONFIG_SIZE, true) // config.size (rest zeroed = default config)
    let cursor = typeHeaderSize
    for (let i = 0; i < layouts.length; i += 1) {
      view.setUint32(cursor, i * entrySize, true) // entry offset
      cursor += 4
    }
    for (let i = 0; i < layouts.length; i += 1) {
      view.setUint16(cursor, 8, true) // ResTable_entry.size
      view.setUint16(cursor + 2, 0, true) // flags
      view.setUint32(cursor + 4, i, true) // key index
      view.setUint16(cursor + 8, 8, true) // Res_value.size
      view.setUint8(cursor + 10, 0) // res0
      view.setUint8(cursor + 11, 0x03) // TYPE_STRING
      view.setUint32(cursor + 12, i, true) // global string pool index
      cursor += entrySize
    }
  }

  // --- Package chunk ---
  const pkgHeaderSize = 288
  const pkgBodyLen = typePool.length + keyPool.length + typeSpec.length + typeChunk.length
  const pkgChunk = new Uint8Array(pkgHeaderSize + pkgBodyLen)
  {
    const view = new DataView(pkgChunk.buffer)
    view.setUint16(0, 0x0200, true) // RES_TABLE_PACKAGE_TYPE
    view.setUint16(2, pkgHeaderSize, true)
    view.setUint32(4, pkgChunk.length, true)
    view.setUint32(8, 0x7f, true) // package id
    // Package name: UTF-16, max 128 chars, zero padded.
    for (let i = 0; i < Math.min(packageName.length, 127); i += 1) {
      view.setUint16(12 + i * 2, packageName.charCodeAt(i), true)
    }
    view.setUint32(268, pkgHeaderSize, true) // typeStrings offset
    view.setUint32(272, 1, true) // lastPublicType
    view.setUint32(276, pkgHeaderSize + typePool.length, true) // keyStrings offset
    view.setUint32(280, layouts.length, true) // lastPublicKey
    view.setUint32(284, 0, true) // typeIdOffset
    let cursor = pkgHeaderSize
    pkgChunk.set(typePool, cursor)
    cursor += typePool.length
    pkgChunk.set(keyPool, cursor)
    cursor += keyPool.length
    pkgChunk.set(typeSpec, cursor)
    cursor += typeSpec.length
    pkgChunk.set(typeChunk, cursor)
  }

  // --- Table header ---
  const total = 12 + globalPool.length + pkgChunk.length
  const out = new Uint8Array(total)
  const view = new DataView(out.buffer)
  view.setUint16(0, 0x0002, true) // RES_TABLE_TYPE
  view.setUint16(2, 12, true)
  view.setUint32(4, total, true)
  view.setUint32(8, 1, true) // packageCount
  out.set(globalPool, 12)
  out.set(pkgChunk, 12 + globalPool.length)

  const ids: Record<string, number> = {}
  layouts.forEach((layout, i) => {
    ids[layout.name] = (0x7f010000 + i) >>> 0
  })
  return { bytes: out, ids }
}
