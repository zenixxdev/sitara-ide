/**
 * Deterministic ZIP writer/reader for APK packaging.
 *
 * All entries are STORED (method 0) and 4-byte aligned via extra-field
 * padding — the same result zipalign produces. Storing uncompressed is a
 * requirement for resources.arsc on API 30+ and keeps v1 digests and the
 * v2 signing block layout fully deterministic.
 */

/* ------------------------------- CRC32 ------------------------------- */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = (c & 1) === 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c >>> 0
  }
  return table
})()

export function crc32(data: Uint8Array): number {
  let crc = 0xffffffff
  for (let i = 0; i < data.length; i += 1) {
    crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8)
  }
  return (crc ^ 0xffffffff) >>> 0
}

/* ------------------------------- Writer ------------------------------ */

export interface ZipEntrySpec {
  name: string
  data: Uint8Array
  /** Alignment for the entry's data payload (default 4). */
  align?: number
}

const textEncoder = new TextEncoder()

// Fixed DOS timestamp (2024-01-01 00:00:00) for reproducible builds.
const DOS_TIME = 0
const DOS_DATE = ((2024 - 1980) << 9) | (1 << 5) | 1

/**
 * Writes a zip with aligned stored entries.
 * Returns the archive plus section offsets needed by the v2 signer.
 */
export function writeZip(entries: ZipEntrySpec[]): {
  bytes: Uint8Array
  centralDirOffset: number
  centralDirLength: number
  eocdOffset: number
} {
  interface WrittenEntry {
    nameBytes: Uint8Array
    crc: number
    size: number
    localHeaderOffset: number
  }

  const localParts: Uint8Array[] = []
  const written: WrittenEntry[] = []
  let offset = 0

  for (const entry of entries) {
    const nameBytes = textEncoder.encode(entry.name)
    const align = entry.align ?? 4
    const baseHeaderLen = 30 + nameBytes.length
    const dataStart = offset + baseHeaderLen
    const padding = align > 0 ? (align - (dataStart % align)) % align : 0
    const header = new Uint8Array(baseHeaderLen + padding)
    const view = new DataView(header.buffer)
    const crc = crc32(entry.data)
    view.setUint32(0, 0x04034b50, true)
    view.setUint16(4, 20, true) // version needed
    view.setUint16(6, 0, true) // flags
    view.setUint16(8, 0, true) // method: STORED
    view.setUint16(10, DOS_TIME, true)
    view.setUint16(12, DOS_DATE, true)
    view.setUint32(14, crc, true)
    view.setUint32(18, entry.data.length, true)
    view.setUint32(22, entry.data.length, true)
    view.setUint16(26, nameBytes.length, true)
    view.setUint16(28, padding, true) // extra field length (pure zero padding)
    header.set(nameBytes, 30)
    written.push({ nameBytes, crc, size: entry.data.length, localHeaderOffset: offset })
    localParts.push(header, entry.data)
    offset += header.length + entry.data.length
  }

  const centralDirOffset = offset
  const centralParts: Uint8Array[] = []
  let centralLen = 0
  for (const entry of written) {
    const record = new Uint8Array(46 + entry.nameBytes.length)
    const view = new DataView(record.buffer)
    view.setUint32(0, 0x02014b50, true)
    view.setUint16(4, 20, true) // version made by
    view.setUint16(6, 20, true) // version needed
    view.setUint16(8, 0, true)
    view.setUint16(10, 0, true) // STORED
    view.setUint16(12, DOS_TIME, true)
    view.setUint16(14, DOS_DATE, true)
    view.setUint32(16, entry.crc, true)
    view.setUint32(20, entry.size, true)
    view.setUint32(24, entry.size, true)
    view.setUint16(28, entry.nameBytes.length, true)
    view.setUint16(30, 0, true) // extra len (central copy carries no padding)
    view.setUint16(32, 0, true) // comment len
    view.setUint16(34, 0, true) // disk
    view.setUint16(36, 0, true) // internal attrs
    view.setUint32(38, 0, true) // external attrs
    view.setUint32(42, entry.localHeaderOffset, true)
    record.set(entry.nameBytes, 46)
    centralParts.push(record)
    centralLen += record.length
  }

  const eocd = new Uint8Array(22)
  {
    const view = new DataView(eocd.buffer)
    view.setUint32(0, 0x06054b50, true)
    view.setUint16(4, 0, true)
    view.setUint16(6, 0, true)
    view.setUint16(8, written.length, true)
    view.setUint16(10, written.length, true)
    view.setUint32(12, centralLen, true)
    view.setUint32(16, centralDirOffset, true)
    view.setUint16(20, 0, true)
  }

  const total = offset + centralLen + 22
  const bytes = new Uint8Array(total)
  let cursor = 0
  for (const part of localParts) {
    bytes.set(part, cursor)
    cursor += part.length
  }
  for (const part of centralParts) {
    bytes.set(part, cursor)
    cursor += part.length
  }
  bytes.set(eocd, cursor)

  return { bytes, centralDirOffset, centralDirLength: centralLen, eocdOffset: offset + centralLen }
}

/* ------------------------------- Reader ------------------------------ */

export interface ZipReadEntry {
  name: string
  crc: number
  size: number
  method: number
  localHeaderOffset: number
  dataOffset: number
  data: Uint8Array
}

/** Parses a zip produced by writeZip (or any stored/deflated archive) via its central directory. */
export function readZip(bytes: Uint8Array): { entries: ZipReadEntry[]; centralDirOffset: number } {
  // Locate EOCD (scan backwards for signature; no comment in our archives but be lenient).
  let eocdPos = -1
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 22 - 65535); i -= 1) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + i, 4)
    if (view.getUint32(0, true) === 0x06054b50) {
      eocdPos = i
      break
    }
  }
  if (eocdPos === -1) throw new Error('ZIP: end of central directory not found')
  const eocdView = new DataView(bytes.buffer, bytes.byteOffset + eocdPos)
  const count = eocdView.getUint16(10, true)
  const cdOffset = eocdView.getUint32(16, true)

  const entries: ZipReadEntry[] = []
  let cursor = cdOffset
  const decoder = new TextDecoder()
  for (let i = 0; i < count; i += 1) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + cursor)
    if (view.getUint32(0, true) !== 0x02014b50) throw new Error('ZIP: bad central directory record')
    const method = view.getUint16(10, true)
    const crc = view.getUint32(16, true)
    const compressedSize = view.getUint32(20, true)
    const size = view.getUint32(24, true)
    const nameLen = view.getUint16(28, true)
    const extraLen = view.getUint16(30, true)
    const commentLen = view.getUint16(32, true)
    const localHeaderOffset = view.getUint32(42, true)
    const name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLen))

    const localView = new DataView(bytes.buffer, bytes.byteOffset + localHeaderOffset)
    if (localView.getUint32(0, true) !== 0x04034b50) throw new Error(`ZIP: bad local header for ${name}`)
    const localNameLen = localView.getUint16(26, true)
    const localExtraLen = localView.getUint16(28, true)
    const dataOffset = localHeaderOffset + 30 + localNameLen + localExtraLen
    const data = bytes.subarray(dataOffset, dataOffset + compressedSize)

    entries.push({ name, crc, size, method, localHeaderOffset, dataOffset, data })
    cursor += 46 + nameLen + extraLen + commentLen
  }
  return { entries, centralDirOffset: cdOffset }
}
