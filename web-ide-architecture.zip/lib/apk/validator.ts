/**
 * BuildValidator — strict pre-build sanity checks.
 *
 * Every check inspects the real virtual project. Any error here aborts the
 * pipeline before packaging starts.
 */

import type { ProblemEntry, ProjectConfig, VirtualFile } from '@/lib/types'
import { collectFiles, findNode } from '@/lib/vfs'
import { parseXml, XmlParseError, type XmlElement } from '@/lib/apk/xmlParse'

let problemSeq = 100000
function problem(severity: 'warning' | 'error', message: string, filePath: string, line: number): ProblemEntry {
  problemSeq += 1
  return { id: problemSeq, severity, message, filePath, line }
}

export interface ValidationResult {
  problems: ProblemEntry[]
  /** Layout files found under res/layout, keyed by entry name (no extension). */
  layouts: Array<{ name: string; path: string; content: string }>
  manifestSource: string | null
}

const PACKAGE_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/

export function validateProject(config: ProjectConfig, tree: VirtualFile[]): ValidationResult {
  const problems: ProblemEntry[] = []
  const files = collectFiles(tree)

  // 1. Package name format
  if (!PACKAGE_RE.test(config.packageName)) {
    problems.push(problem('error', `Invalid applicationId "${config.packageName}" (must be reverse-domain, lowercase)`, 'build.gradle', 1))
  }

  // 2. Manifest exists and is well-formed XML with application + activity
  const manifest = findNode(tree, 'app/src/main/AndroidManifest.xml')
  let manifestSource: string | null = null
  if (manifest === null || manifest.type !== 'file') {
    problems.push(problem('error', 'AndroidManifest.xml is missing', 'app/src/main/AndroidManifest.xml', 1))
  } else {
    manifestSource = manifest.content
    try {
      const root = parseXml(manifest.content)
      if (root.tag !== 'manifest') {
        problems.push(problem('error', `Manifest root element is <${root.tag}>, expected <manifest>`, manifest.path, root.line))
      }
      const application = root.children.find((child) => child.tag === 'application')
      if (application === undefined) {
        problems.push(problem('error', 'Manifest has no <application> element', manifest.path, root.line))
      } else {
        const activities = application.children.filter((child) => child.tag === 'activity')
        if (activities.length === 0) {
          problems.push(problem('error', 'Manifest declares no <activity>', manifest.path, application.line))
        } else {
          const hasLauncher = activities.some((activity) => hasLauncherIntent(activity))
          if (!hasLauncher) {
            problems.push(problem('error', 'No activity declares a MAIN/LAUNCHER intent filter', manifest.path, activities[0].line))
          }
        }
      }
      const declaredPackage = root.attrs.package
      if (declaredPackage !== undefined && declaredPackage !== config.packageName) {
        problems.push(problem('warning', `Manifest package "${declaredPackage}" differs from project applicationId "${config.packageName}" — applicationId wins`, manifest.path, root.line))
      }
    } catch (error) {
      if (error instanceof XmlParseError) {
        problems.push(problem('error', `Manifest XML parse error: ${error.message}`, manifest.path, error.line))
      } else {
        problems.push(problem('error', 'Manifest could not be parsed', manifest.path, 1))
      }
    }
  }

  // 3. Main activity source exists and package path matches package name
  const ext = config.language === 'kotlin' ? '.kt' : '.java'
  const packagePath = config.packageName.replace(/\./g, '/')
  const expectedDir = `app/src/main/java/${packagePath}`
  const mainActivity = files.find((file) => file.path === `${expectedDir}/MainActivity${ext}`)
  if (mainActivity === undefined) {
    const misplaced = files.find((file) => file.name === `MainActivity${ext}`)
    if (misplaced !== undefined) {
      problems.push(problem('error', `MainActivity${ext} found at ${misplaced.path} but package "${config.packageName}" requires ${expectedDir}/`, misplaced.path, 1))
    } else {
      problems.push(problem('error', `MainActivity${ext} not found under ${expectedDir}/`, expectedDir, 1))
    }
  } else {
    const packageLine = mainActivity.content.split('\n').findIndex((line) => line.trim().startsWith('package '))
    if (packageLine === -1) {
      problems.push(problem('error', 'MainActivity has no package declaration', mainActivity.path, 1))
    } else {
      const declaration = mainActivity.content.split('\n')[packageLine].trim()
      if (!declaration.includes(config.packageName)) {
        problems.push(problem('error', `Package declaration does not match "${config.packageName}"`, mainActivity.path, packageLine + 1))
      }
    }
    const badLine = findUnbalancedLine(mainActivity.content)
    if (badLine !== null) {
      problems.push(problem('error', 'Unbalanced braces/brackets in MainActivity', mainActivity.path, badLine))
    }
  }

  // 4. Other sources: brace balance (real static check)
  for (const source of files.filter((file) => file.name.endsWith(ext) && file !== mainActivity)) {
    const badLine = findUnbalancedLine(source.content)
    if (badLine !== null) {
      problems.push(problem('error', 'Unbalanced braces/brackets detected', source.path, badLine))
    }
  }

  // 5. Layouts: activity_main must exist; all layouts must parse as XML
  const layoutFiles = files.filter((file) => file.path.includes('/res/layout/') && file.name.endsWith('.xml'))
  const layouts: ValidationResult['layouts'] = []
  for (const layout of layoutFiles) {
    try {
      parseXml(layout.content)
      layouts.push({ name: layout.name.replace(/\.xml$/, ''), path: layout.path, content: layout.content })
    } catch (error) {
      if (error instanceof XmlParseError) {
        problems.push(problem('error', `Layout XML parse error: ${error.message}`, layout.path, error.line))
      } else {
        problems.push(problem('error', 'Layout could not be parsed', layout.path, 1))
      }
    }
  }
  if (!layouts.some((layout) => layout.name === 'activity_main')) {
    problems.push(problem('error', 'res/layout/activity_main.xml is missing (required by the launcher activity)', 'app/src/main/res/layout/activity_main.xml', 1))
  }

  // activity_main first — its resource id must be 0x7f010000 (runtime contract).
  layouts.sort((a, b) => (a.name === 'activity_main' ? -1 : b.name === 'activity_main' ? 1 : a.name.localeCompare(b.name)))

  return { problems, layouts, manifestSource }
}

function hasLauncherIntent(activity: XmlElement): boolean {
  return activity.children.some(
    (child) =>
      child.tag === 'intent-filter' &&
      child.children.some((item) => item.tag === 'action' && item.attrs['android:name'] === 'android.intent.action.MAIN') &&
      child.children.some((item) => item.tag === 'category' && item.attrs['android:name'] === 'android.intent.category.LAUNCHER'),
  )
}

/** Returns the first line where braces/brackets/parens stop balancing, or null. */
export function findUnbalancedLine(content: string): number | null {
  const stack: Array<{ char: string; line: number }> = []
  const pairs: Record<string, string> = { ')': '(', ']': '[', '}': '{' }
  const lines = content.split('\n')
  let inString = false
  let inBlockComment = false

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex]
    for (let i = 0; i < line.length; i += 1) {
      const char = line[i]
      const next = line[i + 1]
      if (inBlockComment) {
        if (char === '*' && next === '/') {
          inBlockComment = false
          i += 1
        }
        continue
      }
      if (inString) {
        if (char === '\\') i += 1
        else if (char === '"') inString = false
        continue
      }
      if (char === '/' && next === '/') break
      if (char === '/' && next === '*') {
        inBlockComment = true
        i += 1
        continue
      }
      if (char === '"') {
        inString = true
        continue
      }
      if (char === '(' || char === '[' || char === '{') {
        stack.push({ char, line: lineIndex + 1 })
      } else if (char === ')' || char === ']' || char === '}') {
        const top = stack.pop()
        if (top === undefined || top.char !== pairs[char]) return lineIndex + 1
      }
    }
    inString = false
  }
  return stack.length > 0 ? stack[stack.length - 1].line : null
}
