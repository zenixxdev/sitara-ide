import type { ProjectConfig, VirtualFile } from '@/lib/types'

/**
 * Deterministic boilerplate generation engine.
 * Maps a ProjectConfig into a fully-populated virtual Android project tree.
 * The same config always yields the same output, and the emitted tree is
 * template-aware: blank / empty_activity / bottom_nav / login_activity all
 * produce distinct source sets.
 */

/** Sanitizes a project name into a valid Java/Kotlin class-name-safe token. */
function sanitizeClassToken(name: string): string {
  const cleaned = name.replace(/[^A-Za-z0-9]/g, '')
  if (cleaned.length === 0) return 'App'
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1)
}

/** Splits a package name (e.g. "com.sitara.demo") into its directory segments. */
function packageSegments(packageName: string): string[] {
  return packageName
    .split('.')
    .map((segment) => segment.trim().toLowerCase())
    .filter((segment) => segment.length > 0)
}

// ---------------------------------------------------------------------------
// Manifest
// ---------------------------------------------------------------------------

function buildManifest(config: ProjectConfig): string {
  const theme = `@style/Theme.${sanitizeClassToken(config.name)}`

  if (config.template === 'blank') {
    return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${config.name}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="${theme}" />

</manifest>
`
  }

  const launcherActivity =
    config.template === 'login_activity' ? '.LoginActivity' : '.MainActivity'

  const secondaryActivity =
    config.template === 'login_activity'
      ? `        <activity
            android:name=".MainActivity"
            android:exported="false" />
`
      : ''

  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}">

${config.template === 'login_activity' ? '    <uses-permission android:name="android.permission.USE_BIOMETRIC" />\n\n' : ''}    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${config.name}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="${theme}">
        <activity
            android:name="${launcherActivity}"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
${secondaryActivity}    </application>

</manifest>
`
}

// ---------------------------------------------------------------------------
// Layout XML
// ---------------------------------------------------------------------------

function buildMainLayoutXml(config: ProjectConfig): string {
  if (config.template === 'bottom_nav') {
    return `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <androidx.fragment.app.FragmentContainerView
        android:id="@+id/nav_host_container"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        app:layout_constraintBottom_toTopOf="@id/bottom_navigation"
        app:layout_constraintTop_toTopOf="parent" />

    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id="@+id/bottom_navigation"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="?android:attr/windowBackground"
        app:layout_constraintBottom_toBottomOf="parent"
        app:menu="@menu/bottom_nav_menu" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
  }

  return `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/welcome_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Welcome to ${config.name}"
        android:textSize="20sp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
}

function buildLoginLayoutXml(config: ProjectConfig): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="24dp"
    tools:context=".LoginActivity">

    <TextView
        android:id="@+id/login_title"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Sign in to ${config.name}"
        android:textSize="24sp"
        android:textStyle="bold"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <com.google.android.material.textfield.TextInputLayout
        android:id="@+id/email_layout"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="32dp"
        android:hint="Email address"
        app:layout_constraintTop_toBottomOf="@id/login_title">

        <com.google.android.material.textfield.TextInputEditText
            android:id="@+id/email_input"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:inputType="textEmailAddress" />

    </com.google.android.material.textfield.TextInputLayout>

    <com.google.android.material.textfield.TextInputLayout
        android:id="@+id/password_layout"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:hint="Password"
        app:endIconMode="password_toggle"
        app:layout_constraintTop_toBottomOf="@id/email_layout">

        <com.google.android.material.textfield.TextInputEditText
            android:id="@+id/password_input"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:inputType="textPassword" />

    </com.google.android.material.textfield.TextInputLayout>

    <com.google.android.material.button.MaterialButton
        android:id="@+id/login_button"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:text="Sign In"
        app:layout_constraintTop_toBottomOf="@id/password_layout" />

    <com.google.android.material.button.MaterialButton
        android:id="@+id/biometric_button"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:text="Use Biometric Unlock"
        style="@style/Widget.Material3.Button.OutlinedButton"
        app:layout_constraintTop_toBottomOf="@id/login_button" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
}

function buildFragmentLayoutXml(label: string): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="${label}"
        android:textSize="20sp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
}

function buildBottomNavMenuXml(): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android">

    <item
        android:id="@+id/navigation_home"
        android:icon="@android:drawable/ic_menu_view"
        android:title="Home" />

    <item
        android:id="@+id/navigation_dashboard"
        android:icon="@android:drawable/ic_menu_sort_by_size"
        android:title="Dashboard" />

    <item
        android:id="@+id/navigation_profile"
        android:icon="@android:drawable/ic_menu_myplaces"
        android:title="Profile" />

</menu>
`
}

// ---------------------------------------------------------------------------
// Java sources
// ---------------------------------------------------------------------------

function buildJavaMainActivity(config: ProjectConfig): string {
  if (config.template === 'bottom_nav') {
    return `package ${config.packageName};

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

/**
 * MainActivity for ${config.name}.
 * Hosts the bottom-navigation fragment container.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull android.view.MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    swapFragment(new HomeFragment());
                    return true;
                } else if (itemId == R.id.navigation_dashboard) {
                    swapFragment(new DashboardFragment());
                    return true;
                } else if (itemId == R.id.navigation_profile) {
                    swapFragment(new ProfileFragment());
                    return true;
                }
                return false;
            }
        });

        if (savedInstanceState == null) {
            bottomNavigation.setSelectedItemId(R.id.navigation_home);
        }
    }

    private void swapFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.nav_host_container, fragment)
                .commit();
    }
}
`
  }

  return `package ${config.packageName};

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity for ${config.name}.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            // Activity is being re-created after a configuration change.
            // Restore transient UI state here if needed.
        }

        setContentView(R.layout.activity_main);
    }
}
`
}

function buildJavaLoginActivity(config: ProjectConfig): string {
  return `package ${config.packageName};

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * LoginActivity for ${config.name}.
 * Handles credential validation before entering MainActivity.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputLayout emailLayout;
    private TextInputLayout passwordLayout;
    private TextInputEditText emailInput;
    private TextInputEditText passwordInput;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailLayout = findViewById(R.id.email_layout);
        passwordLayout = findViewById(R.id.password_layout);
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);

        MaterialButton loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(view -> {
            if (validateCredentials()) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        });
    }

    private boolean validateCredentials() {
        boolean valid = true;

        CharSequence email = emailInput.getText();
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailLayout.setError("Enter a valid email address");
            valid = false;
        } else {
            emailLayout.setError(null);
        }

        CharSequence password = passwordInput.getText();
        if (TextUtils.isEmpty(password) || password.length() < 8) {
            passwordLayout.setError("Password must be at least 8 characters");
            valid = false;
        } else {
            passwordLayout.setError(null);
        }

        return valid;
    }
}
`
}

function buildJavaFragment(config: ProjectConfig, className: string, layoutName: string): string {
  return `package ${config.packageName};

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * ${className} for ${config.name}.
 * Generated by Sitara Web IDE.
 */
public class ${className} extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.${layoutName}, container, false);
    }
}
`
}

// ---------------------------------------------------------------------------
// Kotlin sources
// ---------------------------------------------------------------------------

function buildKotlinMainActivity(config: ProjectConfig): string {
  if (config.template === 'bottom_nav') {
    return `package ${config.packageName}

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * MainActivity for ${config.name}.
 * Hosts the bottom-navigation fragment container.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    swapFragment(HomeFragment())
                    true
                }
                R.id.navigation_dashboard -> {
                    swapFragment(DashboardFragment())
                    true
                }
                R.id.navigation_profile -> {
                    swapFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }

        if (savedInstanceState == null) {
            bottomNavigation.selectedItemId = R.id.navigation_home
        }
    }

    private fun swapFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.nav_host_container, fragment)
            .commit()
    }
}
`
  }

  return `package ${config.packageName}

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity for ${config.name}.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState != null) {
            // Activity is being re-created after a configuration change.
            // Restore transient UI state here if needed.
        }

        setContentView(R.layout.activity_main)
    }
}
`
}

function buildKotlinLoginActivity(config: ProjectConfig): string {
  return `package ${config.packageName}

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * LoginActivity for ${config.name}.
 * Handles credential validation before entering MainActivity.
 * Generated by Sitara Web IDE. Min SDK: ${config.minSdk}.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var emailLayout: TextInputLayout
    private lateinit var passwordLayout: TextInputLayout
    private lateinit var emailInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailLayout = findViewById(R.id.email_layout)
        passwordLayout = findViewById(R.id.password_layout)
        emailInput = findViewById(R.id.email_input)
        passwordInput = findViewById(R.id.password_input)

        findViewById<MaterialButton>(R.id.login_button).setOnClickListener {
            if (validateCredentials()) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }

    private fun validateCredentials(): Boolean {
        var valid = true

        val email = emailInput.text?.toString().orEmpty()
        if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailLayout.error = "Enter a valid email address"
            valid = false
        } else {
            emailLayout.error = null
        }

        val password = passwordInput.text?.toString().orEmpty()
        if (password.length < 8) {
            passwordLayout.error = "Password must be at least 8 characters"
            valid = false
        } else {
            passwordLayout.error = null
        }

        return valid
    }
}
`
}

function buildKotlinFragment(config: ProjectConfig, className: string, layoutName: string): string {
  return `package ${config.packageName}

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

/**
 * ${className} for ${config.name}.
 * Generated by Sitara Web IDE.
 */
class ${className} : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        return inflater.inflate(R.layout.${layoutName}, container, false)
    }
}
`
}

// ---------------------------------------------------------------------------
// Gradle
// ---------------------------------------------------------------------------

function buildRootGradle(config: ProjectConfig): string {
  const kotlinPlugin =
    config.language === 'kotlin'
      ? `\n    id 'org.jetbrains.kotlin.android' version '1.9.22' apply false`
      : ''
  return `// Top-level build file for ${config.name}.
// Generated by Sitara Web IDE.
plugins {
    id 'com.android.application' version '8.2.2' apply false${kotlinPlugin}
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`
}

function buildAppGradle(config: ProjectConfig): string {
  const kotlinPlugin =
    config.language === 'kotlin' ? `\n    id 'org.jetbrains.kotlin.android'` : ''

  const extraDeps: string[] = []
  if (config.language === 'kotlin') {
    extraDeps.push(`implementation 'androidx.core:core-ktx:1.12.0'`)
  }
  if (config.template === 'bottom_nav') {
    extraDeps.push(`implementation 'androidx.fragment:fragment:1.6.2'`)
  }
  if (config.template === 'login_activity') {
    extraDeps.push(`implementation 'androidx.biometric:biometric:1.1.0'`)
  }
  const extraDepsBlock = extraDeps.map((d) => `\n    ${d}`).join('')

  return `plugins {
    id 'com.android.application'${kotlinPlugin}
}

android {
    namespace '${config.packageName}'
    compileSdk 34

    defaultConfig {
        applicationId "${config.packageName}"
        minSdk ${config.minSdk}
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'${extraDepsBlock}
}
`
}

// ---------------------------------------------------------------------------
// Tree assembly
// ---------------------------------------------------------------------------

interface SourceUnit {
  fileName: string
  content: string
}

/** Builds every language source unit required by the selected template. */
function buildSourceUnits(config: ProjectConfig): SourceUnit[] {
  const ext = config.language === 'kotlin' ? 'kt' : 'java'
  const units: SourceUnit[] = []

  if (config.template !== 'blank') {
    units.push({
      fileName: `MainActivity.${ext}`,
      content:
        config.language === 'kotlin'
          ? buildKotlinMainActivity(config)
          : buildJavaMainActivity(config),
    })
  }

  if (config.template === 'login_activity') {
    units.push({
      fileName: `LoginActivity.${ext}`,
      content:
        config.language === 'kotlin'
          ? buildKotlinLoginActivity(config)
          : buildJavaLoginActivity(config),
    })
  }

  if (config.template === 'bottom_nav') {
    const fragments: Array<[string, string]> = [
      ['HomeFragment', 'fragment_home'],
      ['DashboardFragment', 'fragment_dashboard'],
      ['ProfileFragment', 'fragment_profile'],
    ]
    for (const [className, layoutName] of fragments) {
      units.push({
        fileName: `${className}.${ext}`,
        content:
          config.language === 'kotlin'
            ? buildKotlinFragment(config, className, layoutName)
            : buildJavaFragment(config, className, layoutName),
      })
    }
  }

  return units
}

/** Builds every res/ file required by the selected template. */
function buildResFolders(config: ProjectConfig): VirtualFile[] {
  const layoutChildren: VirtualFile[] = []

  if (config.template !== 'blank') {
    layoutChildren.push({
      name: 'activity_main.xml',
      path: 'app/src/main/res/layout/activity_main.xml',
      content: buildMainLayoutXml(config),
      type: 'file',
    })
  }

  if (config.template === 'login_activity') {
    layoutChildren.push({
      name: 'activity_login.xml',
      path: 'app/src/main/res/layout/activity_login.xml',
      content: buildLoginLayoutXml(config),
      type: 'file',
    })
  }

  if (config.template === 'bottom_nav') {
    const fragmentLayouts: Array<[string, string]> = [
      ['fragment_home.xml', 'Home'],
      ['fragment_dashboard.xml', 'Dashboard'],
      ['fragment_profile.xml', 'Profile'],
    ]
    for (const [fileName, label] of fragmentLayouts) {
      layoutChildren.push({
        name: fileName,
        path: `app/src/main/res/layout/${fileName}`,
        content: buildFragmentLayoutXml(label),
        type: 'file',
      })
    }
  }

  const resChildren: VirtualFile[] = []
  if (layoutChildren.length > 0) {
    resChildren.push({
      name: 'layout',
      path: 'app/src/main/res/layout',
      content: '',
      type: 'folder',
      children: layoutChildren,
    })
  }

  if (config.template === 'bottom_nav') {
    resChildren.push({
      name: 'menu',
      path: 'app/src/main/res/menu',
      content: '',
      type: 'folder',
      children: [
        {
          name: 'bottom_nav_menu.xml',
          path: 'app/src/main/res/menu/bottom_nav_menu.xml',
          content: buildBottomNavMenuXml(),
          type: 'file',
        },
      ],
    })
  }

  return resChildren
}

/**
 * Generates the complete virtual file tree for a new Android project.
 * The tree is deterministic: the same config always yields the same output.
 */
export function generateAndroidBoilerplate(config: ProjectConfig): VirtualFile[] {
  const segments = packageSegments(config.packageName)
  const sourceRoot = config.language === 'kotlin' ? 'kotlin' : 'java'
  const packageDirPath = `app/src/main/${sourceRoot}/${segments.join('/')}`

  const sourceFiles: VirtualFile[] = buildSourceUnits(config).map((unit) => ({
    name: unit.fileName,
    path: `${packageDirPath}/${unit.fileName}`,
    content: unit.content,
    type: 'file',
  }))

  // Build the nested package folder chain from the innermost files outward.
  // The blank template still ships the empty package directory skeleton.
  let packageChildren: VirtualFile[] = sourceFiles
  let packageTree: VirtualFile | null = null
  for (let i = segments.length - 1; i >= 0; i--) {
    const folderPath = `app/src/main/${sourceRoot}/${segments.slice(0, i + 1).join('/')}`
    packageTree = {
      name: segments[i],
      path: folderPath,
      content: '',
      type: 'folder',
      children: packageChildren,
    }
    packageChildren = [packageTree]
  }

  const manifestFile: VirtualFile = {
    name: 'AndroidManifest.xml',
    path: 'app/src/main/AndroidManifest.xml',
    content: buildManifest(config),
    type: 'file',
  }

  const mainChildren: VirtualFile[] = [
    manifestFile,
    {
      name: sourceRoot,
      path: `app/src/main/${sourceRoot}`,
      content: '',
      type: 'folder',
      children: packageTree ? [packageTree] : [],
    },
  ]

  const resFolders = buildResFolders(config)
  if (resFolders.length > 0) {
    mainChildren.push({
      name: 'res',
      path: 'app/src/main/res',
      content: '',
      type: 'folder',
      children: resFolders,
    })
  }

  return [
    {
      name: 'app',
      path: 'app',
      content: '',
      type: 'folder',
      children: [
        {
          name: 'src',
          path: 'app/src',
          content: '',
          type: 'folder',
          children: [
            {
              name: 'main',
              path: 'app/src/main',
              content: '',
              type: 'folder',
              children: mainChildren,
            },
          ],
        },
        {
          name: 'build.gradle',
          path: 'app/build.gradle',
          content: buildAppGradle(config),
          type: 'file',
        },
      ],
    },
    {
      name: 'build.gradle',
      path: 'build.gradle',
      content: buildRootGradle(config),
      type: 'file',
    },
  ]
}

/** Counts every file node (excluding folders) in a virtual tree. */
export function countFiles(tree: VirtualFile[]): number {
  return tree.reduce((total, node) => {
    if (node.type === 'file') return total + 1
    return total + countFiles(node.children ?? [])
  }, 0)
}
