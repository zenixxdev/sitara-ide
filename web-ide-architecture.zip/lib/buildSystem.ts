/**
 * Sitara APK build system.
 *
 * Architecture:
 *   BuildManager  — owns the queue and drives the pipeline
 *   BuildQueue    — FIFO of pending build requests (one active at a time)
 *   BuildLogger   — timestamped, leveled log sink (streams to the UI)
 *   BuildProgress — step/progress/ETA reporting sink
 *   Compiler      — pluggable compilation backend (see `Compiler` interface)
 *
 * The default `VirtualCompiler` performs real static analysis on the virtual
 * project (manifest checks, package verification, brace balancing, resource
 * scanning) and packages a downloadable artifact. Browsers cannot run javac,
 * d8, or apksigner, so a real compiler backend (e.g. a WASM toolchain or a
 * remote build service) can be plugged in by implementing `Compiler` — the
 * manager, queue, logger, progress, and notification layers are backend-agnostic.
 */

import type {
  BuildProgressState,
  BuildStepDefinition,
  BuildStepId,
  LogLevel,
  ProblemEntry,
  ProjectConfig,
  VirtualFile,
} from '@/lib/types'
import { collectFiles, findNode } from '@/lib/vfs'

/* ------------------------------------------------------------------ */
/* Pipeline definition                                                 */
/* ------------------------------------------------------------------ */

export const BUILD_STEPS: BuildStepDefinition[] = [
  { id: 'save', label: 'Saving project', estimateMs: 350 },
  { id: 'validate', label: 'Validating sources', estimateMs: 700 },
  { id: 'compile', label: 'Compiling virtual project', estimateMs: 1400 },
  { id: 'resources', label: 'Generating resources', estimateMs: 800 },
  { id: 'package', label: 'Packaging APK', estimateMs: 900 },
  { id: 'sign', label: 'Signing (debug keystore)', estimateMs: 600 },
  { id: 'export', label: 'Exporting artifact', estimateMs: 450 },
]

const TOTAL_ESTIMATE_MS = BUILD_STEPS.reduce((sum, step) => sum + step.estimateMs, 0)

/* ------------------------------------------------------------------ */
/* Sinks (implemented by the UI/store layer)                           */
/* ------------------------------------------------------------------ */

export interface BuildLogger {
  log: (level: LogLevel, text: string) => void
}

export interface BuildProgressSink {
  update: (state: Partial<BuildProgressState>) => void
}

export interface BuildNotificationSink {
  buildSucceeded: (projectName: string, artifactName: string) => void
  buildFailed: (projectName: string, reason: string) => void
  exportFinished: (artifactName: string) => void
}

export interface BuildRequest {
  config: ProjectConfig
  tree: VirtualFile[]
  /** 'build' assembles only; 'run' assembles then launches the virtual device. */
  mode: 'build' | 'run'
}

export interface BuildOutcome {
  success: boolean
  problems: ProblemEntry[]
  artifact: { fileName: string; blob: Blob } | null
}

/* ------------------------------------------------------------------ */
/* Compiler abstraction (plug-in point for a real toolchain)           */
/* ------------------------------------------------------------------ */

export interface CompileResult {
  problems: ProblemEntry[]
  /** Per-source compiled unit descriptors (dex-mapping placeholder for real backends). */
  compiledUnits: string[]
}

export interface Compiler {
  readonly name: string
  compile: (request: BuildRequest, logger: BuildLogger) => Promise<CompileResult>
  package: (request: BuildRequest, units: string[], logger: BuildLogger) => Promise<Blob>
}

let problemId = 0
function problem(severity: 'warning' | 'error', message: string, filePath: string, line: number): ProblemEntry {
  problemId += 1
  return { id: problemId, severity, message, filePath, line }
}

/** Checks that braces/brackets/parens balance in a source file. Returns the first offending line. */
function findUnbalancedLine(content: string): number | null {
  const stack: Array<{ char: string; line: number }> = []
  const pairs: Record<string, string> = { ')': '(', ']': '[', '}': '{' }
  const lines = content.split('\n')
  let inString = false
  let inBlockComment = false

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex]
    for (let i = 0; i < line.length; i += 1) {
      const char = line[i]
      const next = line[i + 1]
      if (inBlockComment) {
        if (char === '*' && next === '/') {
          inBlockComment = false
          i += 1
        }
        continue
      }
      if (inString) {
        if (char === '\\') i += 1
        else if (char === '"') inString = false
        continue
      }
      if (char === '/' && next === '/') break
      if (char === '/' && next === '*') {
        inBlockComment = true
        i += 1
        continue
      }
      if (char === '"') {
        inString = true
        continue
      }
      if (char === '(' || char === '[' || char === '{') {
        stack.push({ char, line: lineIndex + 1 })
      } else if (char === ')' || char === ']' || char === '}') {
        const top = stack.pop()
        if (top === undefined || top.char !== pairs[char]) return lineIndex + 1
      }
    }
    inString = false // strings don't span lines in Java/Kotlin sources
  }
  return stack.length > 0 ? stack[stack.length - 1].line : null
}

/**
 * Default browser-side compiler. Performs real static analysis and produces a
 * downloadable artifact. Swap this implementation to plug in a real toolchain.
 */
export class VirtualCompiler implements Compiler {
  readonly name = 'sitara-virtual-compiler/1.0'

  async compile(request: BuildRequest, logger: BuildLogger): Promise<CompileResult> {
    const { config, tree } = request
    const problems: ProblemEntry[] = []
    const ext = config.language === 'kotlin' ? '.kt' : '.java'
    const files = collectFiles(tree)

    // 1. Manifest checks
    const manifest = findNode(tree, 'app/src/main/AndroidManifest.xml')
    if (manifest === null || manifest.type !== 'file') {
      problems.push(problem('error', 'AndroidManifest.xml is missing', 'app/src/main/AndroidManifest.xml', 1))
    } else {
      if (!manifest.content.includes('<application')) {
        problems.push(problem('error', 'Manifest has no <application> element', manifest.path, 1))
      }
      if (!manifest.content.includes('<activity')) {
        problems.push(problem('warning', 'Manifest declares no activities', manifest.path, 1))
      }
    }

    // 2. Source compilation checks
    const sources = files.filter((file) => file.name.endsWith(ext))
    if (sources.length === 0) {
      problems.push(problem('error', `No ${config.language} sources found (*${ext})`, 'app/src/main', 1))
    }
    for (const source of sources) {
      logger.log('info', `${config.language === 'kotlin' ? 'kotlinc' : 'javac'} ${source.path}`)
      const packageLine = source.content.split('\n').find((line) => line.trim().startsWith('package '))
      if (packageLine === undefined) {
        problems.push(problem('error', 'Missing package declaration', source.path, 1))
      } else if (!packageLine.includes(config.packageName)) {
        problems.push(
          problem('warning', `Package declaration does not match "${config.packageName}"`, source.path, 1),
        )
      }
      const badLine = findUnbalancedLine(source.content)
      if (badLine !== null) {
        problems.push(problem('error', 'Unbalanced braces/brackets detected', source.path, badLine))
      }
      // Yield to the event loop so huge projects never block the UI thread.
      await new Promise<void>((resolve) => window.setTimeout(resolve, 0))
    }

    // 3. Layout resource checks
    const layouts = files.filter((file) => file.path.includes('/res/layout/') && file.name.endsWith('.xml'))
    for (const layout of layouts) {
      const opens = (layout.content.match(/<[A-Za-z]/g) ?? []).length
      const closes = (layout.content.match(/<\/[A-Za-z]|\/>/g) ?? []).length
      if (opens !== closes) {
        problems.push(problem('error', 'Unclosed XML element in layout', layout.path, 1))
      }
    }

    return {
      problems,
      compiledUnits: sources.map((source) => source.path.replace(ext, '.class')),
    }
  }

  async package(request: BuildRequest, units: string[], logger: BuildLogger): Promise<Blob> {
    const { config, tree } = request
    const files = collectFiles(tree)
    logger.log('info', `Merging ${units.length} compiled unit(s) into classes.dex (virtual)`)

    // Deterministic virtual APK payload: manifest of everything that would be packed.
    const payload = [
      `SITARA-VIRTUAL-APK/1.0`,
      `Package: ${config.packageName}`,
      `App: ${config.name}`,
      `MinSdk: ${config.minSdk}`,
      `Language: ${config.language}`,
      `Compiler: ${this.name}`,
      `Built-At: ${new Date().toISOString()}`,
      ``,
      `[classes.dex]`,
      ...units.map((unit) => `  ${unit}`),
      ``,
      `[assets]`,
      ...files.map((file) => `  ${file.path} (${file.content.length} bytes)`),
    ].join('\n')

    return new Blob([payload], { type: 'application/vnd.android.package-archive' })
  }
}

/* ------------------------------------------------------------------ */
/* BuildQueue + BuildManager                                           */
/* ------------------------------------------------------------------ */

export class BuildQueue {
  private items: BuildRequest[] = []

  enqueue(request: BuildRequest): number {
    this.items.push(request)
    return this.items.length
  }

  dequeue(): BuildRequest | undefined {
    return this.items.shift()
  }

  get size(): number {
    return this.items.length
  }

  clear(): void {
    this.items = []
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms))
}

export class BuildManager {
  private queue = new BuildQueue()
  private running = false
  private buildCounter = 0

  constructor(
    private compiler: Compiler,
    private logger: BuildLogger,
    private progress: BuildProgressSink,
    private notifications: BuildNotificationSink,
    private onOutcome: (outcome: BuildOutcome, request: BuildRequest) => void,
  ) {}

  /** Swap in a different compiler backend at runtime. */
  setCompiler(compiler: Compiler): void {
    this.compiler = compiler
  }

  get isRunning(): boolean {
    return this.running
  }

  /** Queues a build; starts immediately if idle. */
  request(build: BuildRequest): void {
    const position = this.queue.enqueue(build)
    if (this.running) {
      this.logger.log('info', `Build queued (position ${position - 1} in queue)`)
      this.progress.update({ status: 'queued' })
      return
    }
    void this.drain()
  }

  private async drain(): Promise<void> {
    this.running = true
    let next = this.queue.dequeue()
    while (next !== undefined) {
      await this.execute(next)
      next = this.queue.dequeue()
    }
    this.running = false
  }

  private async execute(request: BuildRequest): Promise<void> {
    this.buildCounter += 1
    const buildId = this.buildCounter
    const startedAt = Date.now()
    const problems: ProblemEntry[] = []
    let elapsed = 0
    let artifact: { fileName: string; blob: Blob } | null = null
    let compiledUnits: string[] = []

    this.progress.update({
      buildId,
      status: 'running',
      currentStep: null,
      progress: 0,
      etaMs: TOTAL_ESTIMATE_MS,
      startedAt,
      finishedAt: null,
    })
    this.logger.log('info', `Build #${buildId} started — ${this.compiler.name}`)
    this.logger.log('info', `> Configure project :app (package ${request.config.packageName}, minSdk ${request.config.minSdk})`)

    try {
      for (const step of BUILD_STEPS) {
        this.progress.update({
          currentStep: step.id,
          progress: elapsed / TOTAL_ESTIMATE_MS,
          etaMs: TOTAL_ESTIMATE_MS - elapsed,
        })
        this.logger.log('info', `> Task :app:${step.id === 'compile' ? (request.config.language === 'kotlin' ? 'compileDebugKotlin' : 'compileDebugJavaWithJavac') : step.id}`)

        const stepResult = await this.runStep(step.id, request, compiledUnits, problems)
        if (stepResult.units !== null) compiledUnits = stepResult.units
        if (stepResult.artifact !== null) artifact = stepResult.artifact

        const errors = problems.filter((entry) => entry.severity === 'error')
        if (errors.length > 0) {
          throw new BuildFailure(step.id, `${errors.length} error(s) in ${step.label.toLowerCase()}`)
        }

        await sleep(step.estimateMs)
        elapsed += step.estimateMs
        this.progress.update({ progress: elapsed / TOTAL_ESTIMATE_MS, etaMs: TOTAL_ESTIMATE_MS - elapsed })
      }

      const durationSec = ((Date.now() - startedAt) / 1000).toFixed(1)
      this.progress.update({ status: 'success', currentStep: null, progress: 1, etaMs: null, finishedAt: Date.now() })
      this.logger.log('success', `BUILD SUCCESSFUL in ${durationSec}s — ${BUILD_STEPS.length} actionable tasks executed`)
      if (artifact !== null) {
        this.logger.log('success', `Artifact ready: app/build/outputs/apk/debug/${artifact.fileName}`)
        this.notifications.buildSucceeded(request.config.name, artifact.fileName)
        this.notifications.exportFinished(artifact.fileName)
      }
      if (request.mode === 'run') {
        this.logger.log('info', 'Installing on virtual device sitara_emu_01…')
        await sleep(500)
        this.logger.log('success', `Launched ${request.config.packageName}/.MainActivity on sitara_emu_01`)
      }
      this.onOutcome({ success: true, problems, artifact }, request)
    } catch (error) {
      const reason = error instanceof BuildFailure ? error.message : 'Unexpected internal build error'
      const failedStep = error instanceof BuildFailure ? error.step : 'compile'
      this.progress.update({ status: 'failed', currentStep: failedStep, etaMs: null, finishedAt: Date.now() })
      this.logger.log('error', `BUILD FAILED — ${reason}`)
      for (const entry of problems.filter((item) => item.severity === 'error')) {
        this.logger.log('error', `  ${entry.filePath}:${entry.line} — ${entry.message}`)
      }
      this.notifications.buildFailed(request.config.name, reason)
      this.onOutcome({ success: false, problems, artifact: null }, request)
    }
  }

  private async runStep(
    stepId: BuildStepId,
    request: BuildRequest,
    units: string[],
    problems: ProblemEntry[],
  ): Promise<{ units: string[] | null; artifact: { fileName: string; blob: Blob } | null }> {
    switch (stepId) {
      case 'save':
        this.logger.log('info', `Persisted ${collectFiles(request.tree).length} file(s) to the virtual filesystem`)
        return { units: null, artifact: null }

      case 'validate':
      case 'compile': {
        if (stepId === 'validate') return { units: null, artifact: null }
        const result = await this.compiler.compile(request, this.logger)
        problems.push(...result.problems)
        for (const entry of result.problems) {
          this.logger.log(entry.severity === 'error' ? 'error' : 'warning', `${entry.filePath}:${entry.line} — ${entry.message}`)
        }
        return { units: result.compiledUnits, artifact: null }
      }

      case 'resources': {
        const layoutCount = collectFiles(request.tree).filter((file) => file.path.includes('/res/')).length
        this.logger.log('info', `aapt2: compiled ${layoutCount} resource file(s)`)
        return { units: null, artifact: null }
      }

      case 'package': {
        const blob = await this.compiler.package(request, units, this.logger)
        const fileName = `${request.config.name.toLowerCase().replace(/\s+/g, '-')}-debug.apk`
        return { units: null, artifact: { fileName, blob } }
      }

      case 'sign':
        this.logger.log('info', 'apksigner: signed with debug.keystore (SHA-256 virtual digest)')
        return { units: null, artifact: null }

      case 'export':
        return { units: null, artifact: null }

      default:
        return { units: null, artifact: null }
    }
  }
}

class BuildFailure extends Error {
  constructor(
    public step: BuildStepId,
    message: string,
  ) {
    super(message)
  }
}
