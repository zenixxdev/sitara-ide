/**
 * Global type definitions for the Sitara web Android IDE.
 */

export type Language = 'java' | 'kotlin'

export type TemplateType = 'blank' | 'empty_activity' | 'bottom_nav' | 'login_activity'

export interface ProjectConfig {
  id: string
  name: string
  packageName: string
  minSdk: string
  logoUrl: string | null
  language: Language
  template: TemplateType
  createdAt: string
}

export interface VirtualFile {
  name: string
  path: string
  content: string
  type: 'file' | 'folder'
  children?: VirtualFile[]
}

export type ExperienceLevel = 'beginner' | 'intermediate' | 'master'

export type ThemeChoice = 'neon_cyan' | 'cyber_gold' | 'deep_amethyst'

export interface OnboardingResult {
  experience: ExperienceLevel
  theme: ThemeChoice
  /** Real browser Notification API state at the end of onboarding. */
  notificationPermission: NotificationPermissionState
}

/** Mirror of the browser's NotificationPermission plus "unsupported". */
export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported'

export interface SdkOption {
  value: string
  label: string
  codename: string
}

export const SDK_OPTIONS: SdkOption[] = [
  { value: '21', label: 'API 21', codename: 'Lollipop' },
  { value: '24', label: 'API 24', codename: 'Nougat' },
  { value: '29', label: 'API 29', codename: 'Android 10' },
  { value: '33', label: 'API 33', codename: 'Android 13' },
  { value: '34', label: 'API 34', codename: 'Android 14' },
]

export const ONBOARDING_STORAGE_KEY = 'android_web_ide_onboarding_done'

/* ------------------------------------------------------------------ */
/* Phase 2: IDE workspace types                                        */
/* ------------------------------------------------------------------ */

/** A project as persisted in the virtual workspace, including its live file tree. */
export interface StoredProject {
  config: ProjectConfig
  tree: VirtualFile[]
  lastOpenedAt: string
  favorite: boolean
}

/** An open editor tab. Content lives in the VFS; tabs only track view state. */
export interface EditorTabState {
  path: string
  name: string
  pinned: boolean
  dirty: boolean
}

export type BottomPanelTab = 'build' | 'logs' | 'problems' | 'output' | 'terminal'

export type LogLevel = 'info' | 'warning' | 'error' | 'success'

export interface LogEntry {
  id: number
  level: LogLevel
  text: string
  timestamp: string
  source: 'build' | 'system' | 'output'
}

export interface ProblemEntry {
  id: number
  severity: 'warning' | 'error'
  message: string
  filePath: string
  line: number
}

/* ---- Build system ---- */

export type BuildStepId =
  | 'save'
  | 'validate'
  | 'compile'
  | 'resources'
  | 'package'
  | 'sign'
  | 'export'

export type BuildStatus = 'idle' | 'queued' | 'running' | 'success' | 'failed'

export interface BuildStepDefinition {
  id: BuildStepId
  label: string
  /** Baseline duration in ms used for progress estimation. */
  estimateMs: number
}

export interface BuildProgressState {
  status: BuildStatus
  currentStep: BuildStepId | null
  /** 0..1 across the whole pipeline. */
  progress: number
  /** Remaining time estimate in ms, null when idle/done. */
  etaMs: number | null
  startedAt: number | null
  finishedAt: number | null
  buildId: number
}

export interface BuildArtifact {
  fileName: string
  sizeBytes: number
  /** Object URL for download; revoked when replaced. */
  url: string
  createdAt: string
}

/* ---- Terminal ---- */

export interface TerminalLine {
  id: number
  kind: 'command' | 'output' | 'error'
  text: string
}

/* ---- Settings ---- */

export type AccentTheme = 'electric_blue' | 'neon_cyan' | 'cyber_gold' | 'deep_amethyst'

export type EditorFont = 'geist_mono' | 'system_mono'

export interface IdeSettings {
  accentTheme: AccentTheme
  fontSize: number
  editorFont: EditorFont
  tabSize: number
  wordWrap: boolean
  autoSave: boolean
  notificationsEnabled: boolean
  /** Build preference: verbose gradle-style logs. */
  verboseBuildLogs: boolean
  /** Build preference: automatically open the Build panel when a build starts. */
  autoOpenBuildPanel: boolean
}

export const DEFAULT_IDE_SETTINGS: IdeSettings = {
  accentTheme: 'electric_blue',
  fontSize: 13,
  editorFont: 'geist_mono',
  tabSize: 4,
  wordWrap: false,
  autoSave: false,
  notificationsEnabled: false,
  verboseBuildLogs: true,
  autoOpenBuildPanel: true,
}

/* ---- Search ---- */

export interface SearchMatch {
  filePath: string
  fileName: string
  line: number
  /** The full line text containing the match. */
  lineText: string
  /** Column of the match start within lineText. */
  column: number
}

export interface ProjectStatistics {
  totalFiles: number
  totalFolders: number
  totalLines: number
  totalBytes: number
  byExtension: Record<string, number>
}
